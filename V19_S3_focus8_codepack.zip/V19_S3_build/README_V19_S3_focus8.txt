V19_S3_focus8

当前主线：W140_20_20_H2_T16

8组实验：
1) BASE
2) CONFIRM
3) TREND
4) CONFIRM_TREND
5) RISK
6) COMBO
7) W120_BASE
8) W120_COMBO

本版仅保留新的S3入口，不包含旧S2入口。

输出目录：runs/V19_S3_focus8/
主入口：run_v19_s3_focus8.py

内存策略：
- 不保留prep_cache常驻内存
- 同一时刻最多只保留1份prepared dataset
- 每个实验结束后释放 data / feature_cols / 中间表
- 执行 gc.collect() / torch.cuda.empty_cache() / torch.cuda.ipc_collect()
