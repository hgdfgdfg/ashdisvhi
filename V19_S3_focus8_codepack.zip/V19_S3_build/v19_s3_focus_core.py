
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import yaml

import ashare_v14_fold as v14
from ashare_backtest import prepare_prediction_table_for_backtest
from experiment_common_v14_fold import log_time, cleanup_memory

CORE_DONE_FILES = [
    'done.json', 'fold_meta.json', 'summary_overall.csv',
    'top10_daily_predictions.csv', 'top10_hit_stats.csv', 'rank_hit_distribution.csv',
]


def is_fold_complete(fold_dir: Path) -> bool:
    return fold_dir.exists() and all((fold_dir / n).exists() for n in CORE_DONE_FILES)


def _safe_mean(df: pd.DataFrame, col: str) -> float:
    if df is None or df.empty or col not in df.columns:
        return float('nan')
    return float(pd.to_numeric(df[col], errors='coerce').mean())


def _zscore_by_day(df: pd.DataFrame, col: str) -> pd.Series:
    x = pd.to_numeric(df[col], errors='coerce')
    grp = df.groupby('date')[col]
    mean = grp.transform(lambda s: pd.to_numeric(s, errors='coerce').mean())
    std = grp.transform(lambda s: pd.to_numeric(s, errors='coerce').std(ddof=0))
    z = (x - mean) / std.replace(0, np.nan)
    return z.replace([np.inf, -np.inf], np.nan).fillna(0.0)


def _ensure_daily_pred_rank(df: pd.DataFrame, score_col: str = 'score') -> pd.DataFrame:
    out = df.copy()
    out['date'] = pd.to_datetime(out['date'])
    out = out.sort_values(['date', score_col, 'pred_ret', 'pred_prob_pos'], ascending=[True, False, False, False]).reset_index(drop=True)
    out['pred_rank'] = out.groupby('date').cumcount() + 1
    return out


def _add_t1_features(raw_df: pd.DataFrame) -> pd.DataFrame:
    d = raw_df.copy()
    d['date'] = pd.to_datetime(d['date'])
    d = d.sort_values(['symbol', 'date']).reset_index(drop=True)
    for c in ['open','high','low','close','amount']:
        if c in d.columns:
            d[c] = pd.to_numeric(d[c], errors='coerce')
    d['pre_ret_5d'] = d.groupby('symbol')['close'].pct_change(5)
    d['pre_ret_20d'] = d.groupby('symbol')['close'].pct_change(20)
    d['pre_ret_60d'] = d.groupby('symbol')['close'].pct_change(60)
    d['pre_ret_120d'] = d.groupby('symbol')['close'].pct_change(120)
    rng = (d['high'] - d['low']).replace(0, np.nan)
    d['t1_body_ret'] = d['close'] / d['open'] - 1.0
    d['t1_upper_shadow_ratio'] = (d['high'] - d[['open','close']].max(axis=1)) / rng
    d['t1_close_pos_in_range'] = (d['close'] - d['low']) / rng
    if 'amount' in d.columns:
        amt5 = d.groupby('symbol')['amount'].transform(lambda s: s.shift(1).rolling(5, min_periods=3).mean())
        d['t1_amount_ratio_5'] = d['amount'] / amt5.replace(0, np.nan)
    else:
        d['t1_amount_ratio_5'] = np.nan
    cols = ['symbol','code','date','pre_ret_5d','pre_ret_20d','pre_ret_60d','pre_ret_120d','t1_body_ret','t1_upper_shadow_ratio','t1_close_pos_in_range','t1_amount_ratio_5']
    cols = [c for c in cols if c in d.columns]
    return d[cols].copy()


def _apply_score_variant(merged: pd.DataFrame, cfg) -> pd.DataFrame:
    out = merged.copy()
    # normalize / fill
    for c in ['pred_ret','pred_prob_pos','pre_ret_5d','pre_ret_20d','pre_ret_60d','pre_ret_120d','t1_body_ret','t1_upper_shadow_ratio','t1_close_pos_in_range','t1_amount_ratio_5']:
        if c not in out.columns:
            out[c] = np.nan
    # clip raw features to avoid extreme effects
    out['t1_amount_ratio_5'] = pd.to_numeric(out['t1_amount_ratio_5'], errors='coerce').clip(0.5, 2.0)
    out['confirm_score'] = (
        0.40 * _zscore_by_day(out, 't1_body_ret')
        + 0.35 * _zscore_by_day(out, 't1_close_pos_in_range')
        - 0.25 * _zscore_by_day(out, 't1_upper_shadow_ratio')
        + 0.15 * _zscore_by_day(out, 't1_amount_ratio_5')
    )
    overheat = (pd.to_numeric(out['pre_ret_5d'], errors='coerce').fillna(0) - pd.to_numeric(out['pre_ret_60d'], errors='coerce').fillna(0)).clip(lower=0)
    out['trend_score'] = (
        0.55 * _zscore_by_day(out, 'pre_ret_60d')
        + 0.25 * _zscore_by_day(out, 'pre_ret_120d')
        + 0.20 * _zscore_by_day(out, 'pre_ret_20d')
        - 0.25 * ((overheat - overheat.groupby(out['date']).transform('mean')) / overheat.groupby(out['date']).transform('std').replace(0, np.nan)).replace([np.inf,-np.inf], np.nan).fillna(0.0)
    )
    weak_close = 1.0 - pd.to_numeric(out['t1_close_pos_in_range'], errors='coerce').fillna(0.5)
    out['risk_score'] = (
        0.45 * _zscore_by_day(out, 't1_upper_shadow_ratio')
        + 0.30 * ((weak_close - weak_close.groupby(out['date']).transform('mean')) / weak_close.groupby(out['date']).transform('std').replace(0, np.nan)).replace([np.inf,-np.inf], np.nan).fillna(0.0)
        + 0.25 * ((overheat - overheat.groupby(out['date']).transform('mean')) / overheat.groupby(out['date']).transform('std').replace(0, np.nan)).replace([np.inf,-np.inf], np.nan).fillna(0.0)
    )
    base_score = pd.to_numeric(out['pred_ret'], errors='coerce').fillna(0.0)
    variant = str(getattr(cfg, 'score_variant', 'base'))
    ca = float(getattr(cfg, 'confirm_alpha', 0.0))
    ta = float(getattr(cfg, 'trend_alpha', 0.0))
    ra = float(getattr(cfg, 'risk_alpha', 0.0))
    score = base_score.copy()
    if variant in ('confirm', 'confirm_trend', 'combo'):
        score = score + ca * out['confirm_score']
    if variant in ('trend', 'confirm_trend', 'combo'):
        score = score + ta * out['trend_score']
    if variant in ('risk', 'combo'):
        score = score - ra * out['risk_score']
    out['base_score'] = base_score
    out['score'] = score
    return out


def build_v19_eval_table(test_pred: pd.DataFrame, raw_df: pd.DataFrame, hold_days: int, effective_target_ret_thres: float, daily_target_ret_thres: float, cfg=None) -> pd.DataFrame:
    merged = prepare_prediction_table_for_backtest(pred_df=test_pred, raw_daily_df=raw_df, horizon=int(hold_days))
    if merged is None or merged.empty:
        return pd.DataFrame()
    feat = _add_t1_features(raw_df)
    join_cols = [c for c in ['symbol', 'code', 'date'] if c in merged.columns and c in feat.columns]
    merged = merged.merge(feat, on=join_cols, how='left')
    # output side filter: remove chinext only
    if getattr(cfg, 'exclude_chinext_in_output', True):
        sym = merged['symbol'].astype(str).str.zfill(6)
        merged = merged[~sym.str.startswith(('300', '301'))].copy()
    merged = _apply_score_variant(merged, cfg)
    merged = _ensure_daily_pred_rank(merged, score_col='score')
    merged['daily_target_ret_thres'] = float(daily_target_ret_thres)
    merged['effective_target_ret_thres'] = float(effective_target_ret_thres)
    merged['hit_target'] = (pd.to_numeric(merged['real_trade_ret'], errors='coerce') >= float(effective_target_ret_thres)).astype(int)
    return merged


def build_v19_s3_outputs(fold_dir: Path, test_pred: pd.DataFrame, raw_df: pd.DataFrame, hold_days: int, daily_target_ret_thres: float, effective_target_ret_thres: float, cfg) -> Dict:
    log_time(f'V19_S3 评估开始 | variant={getattr(cfg,"score_variant","base")} | hold_days={hold_days} | daily={daily_target_ret_thres:.4f} | effective={effective_target_ret_thres:.4f}')
    merged = build_v19_eval_table(test_pred=test_pred, raw_df=raw_df, hold_days=hold_days, effective_target_ret_thres=effective_target_ret_thres, daily_target_ret_thres=daily_target_ret_thres, cfg=cfg)
    if merged.empty:
        empty = pd.DataFrame()
        for name in ['summary_by_fold.csv', 'summary_overall.csv', 'top10_daily_predictions.csv', 'top10_hit_stats.csv', 'rank_hit_distribution.csv']:
            empty.to_csv(fold_dir / name, index=False, encoding='utf-8-sig')
        return {'summary': pd.DataFrame([{'sample_days': 0}])}

    top10 = merged[merged['pred_rank'] <= 10].copy()
    daily = top10.groupby('date', as_index=False).agg(
        top10_count=('symbol', 'count'),
        top10_hit_count=('hit_target', 'sum'),
        top10_hit_rate=('hit_target', 'mean'),
        top10_avg_ret=('real_trade_ret', 'mean'),
    )
    top10_sorted = top10.sort_values(['date', 'pred_rank']).copy()
    for k in [1, 3, 5]:
        sub = top10_sorted[top10_sorted['pred_rank'] <= k].groupby('date', as_index=False).agg(**{f'top{k}_avg_ret': ('real_trade_ret', 'mean')})
        daily = daily.merge(sub, on='date', how='left')
    rank_hit = top10.groupby('pred_rank', as_index=False).agg(
        count=('symbol', 'count'),
        hit_target_rate=('hit_target', 'mean'),
        avg_ret=('real_trade_ret', 'mean'),
        avg_score=('score', 'mean'),
        avg_pred_ret=('pred_ret', 'mean'),
        avg_pred_prob_pos=('pred_prob_pos', 'mean'),
    ).sort_values('pred_rank').reset_index(drop=True)
    cols = [c for c in ['date','symbol','code','pred_rank','score','base_score','confirm_score','trend_score','risk_score','pred_ret','pred_prob_pos','real_trade_ret','hit_target','entry_date','exit_date','entry_open','exit_open','daily_target_ret_thres','effective_target_ret_thres','t1_body_ret','t1_upper_shadow_ratio','t1_close_pos_in_range','pre_ret_20d','pre_ret_60d','pre_ret_120d'] if c in top10.columns]
    top10_daily = top10[cols].copy()
    top10_daily['date'] = pd.to_datetime(top10_daily['date']).dt.strftime('%Y-%m-%d')
    merged.to_csv(fold_dir / 'test_pred_v19_s3_full.csv', index=False, encoding='utf-8-sig')
    top10_daily.to_csv(fold_dir / 'top10_daily_predictions.csv', index=False, encoding='utf-8-sig')
    daily.to_csv(fold_dir / 'top10_hit_stats.csv', index=False, encoding='utf-8-sig')
    rank_hit.to_csv(fold_dir / 'rank_hit_distribution.csv', index=False, encoding='utf-8-sig')
    big_loss_rate_top1 = np.nan
    if len(top10_sorted[top10_sorted['pred_rank'] == 1]):
        r1 = top10_sorted[top10_sorted['pred_rank'] == 1].copy()
        big_loss_rate_top1 = float((pd.to_numeric(r1['real_trade_ret'], errors='coerce') / float(hold_days) <= -0.01).mean())
    summary = {
        'hold_days': int(hold_days),
        'daily_target_ret_thres': float(daily_target_ret_thres),
        'effective_target_ret_thres': float(effective_target_ret_thres),
        'score_variant': str(getattr(cfg, 'score_variant', 'base')),
        'sample_days': int(daily['date'].nunique()),
        'top10_hit_rate_mean': _safe_mean(daily, 'top10_hit_rate'),
        'top10_avg_ret_mean': _safe_mean(daily, 'top10_avg_ret'),
        'top5_avg_ret_mean': _safe_mean(daily, 'top5_avg_ret'),
        'top3_avg_ret_mean': _safe_mean(daily, 'top3_avg_ret'),
        'top1_avg_ret_mean': _safe_mean(daily, 'top1_avg_ret'),
        'top10_hit_count_mean': _safe_mean(daily, 'top10_hit_count'),
        'rank1_hit_rate': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'hit_target_rate'),
        'rank1_avg_ret': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'avg_ret'),
        'big_loss_rate_top1': big_loss_rate_top1,
        'test_positive_rate': float(pd.to_numeric(merged['hit_target'], errors='coerce').mean()),
    }
    pd.DataFrame([summary]).to_csv(fold_dir / 'summary_overall.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([summary]).to_csv(fold_dir / 'summary_by_fold.csv', index=False, encoding='utf-8-sig')
    return {'summary': pd.DataFrame([summary])}


def save_resolved_config(fold_dir: Path, cfg_obj) -> None:
    obj = {k: getattr(cfg_obj, k) for k in dir(cfg_obj) if not k.startswith('_') and not callable(getattr(cfg_obj, k))}
    with open(fold_dir / 'config_resolved.yaml', 'w', encoding='utf-8') as f:
        yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=True)


def run_one_fold_v19_s3(data: pd.DataFrame, feature_cols: List[str], cfg, fold_spec: Dict, fold_dir: Path) -> Dict:
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    train_df = data[data['date'].isin(fold_spec['train_dates'])].copy().sort_values(['symbol', 'date']).reset_index(drop=True)
    valid_df = v14._build_warmup_slice(data, fold_spec['valid_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['valid_dates'])].copy()
    test_df = v14._build_warmup_slice(data, fold_spec['test_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['test_dates'])].copy()
    fold_dir.mkdir(parents=True, exist_ok=True)
    save_resolved_config(fold_dir, cfg)
    fit_res = None
    try:
        log_time(f"V19_S3 fold={fold_spec['fold']} | variant={getattr(cfg,'score_variant','base')} | 开始训练与预测")
        fit_res = v14.fit_and_predict_one_fold_ashare_v14(
            train_df=train_df, valid_df=valid_df, test_df=test_df, feature_cols=feature_cols, cfg=cfg,
            valid_trade_dates=fold_spec['valid_dates'], test_trade_dates=fold_spec['test_dates'],
        )
        if fit_res.get('test_pred') is not None:
            fit_res['test_pred'].to_csv(fold_dir / 'test_pred.csv', index=False, encoding='utf-8-sig')
        if fit_res.get('epoch_records') is not None:
            fit_res['epoch_records'].to_csv(fold_dir / 'epoch_records.csv', index=False, encoding='utf-8-sig')
        res = build_v19_s3_outputs(
            fold_dir=fold_dir, test_pred=fit_res['test_pred'], raw_df=test_df,
            hold_days=int(cfg.horizon_candidates[0]),
            daily_target_ret_thres=float(getattr(cfg, 'daily_target_ret_threshold', cfg.target_ret_threshold / max(int(cfg.horizon_candidates[0]), 1))),
            effective_target_ret_thres=float(cfg.target_ret_threshold), cfg=cfg,
        )
        meta = {
            'fold': int(fold_spec['fold']),
            'fold_spec': {k: fold_spec[k] for k in ['train_start', 'train_end', 'valid_start', 'valid_end', 'test_start', 'test_end']},
            'n_train_samples': int(fit_res.get('n_train_samples', 0)),
            'n_valid_samples': int(fit_res.get('n_valid_samples', 0)),
            'n_test_samples': int(fit_res.get('n_test_samples', 0)),
            'study': 'V19_S3 focus8 candlestick rerank',
            'hold_days': int(cfg.horizon_candidates[0]),
            'daily_target_ret_threshold': float(getattr(cfg, 'daily_target_ret_threshold', cfg.target_ret_threshold / max(int(cfg.horizon_candidates[0]), 1))),
            'effective_target_ret_threshold': float(cfg.target_ret_threshold),
            'score_variant': str(getattr(cfg, 'score_variant', 'base')),
        }
        (fold_dir / 'fold_meta.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        (fold_dir / 'done.json').write_text(json.dumps({'ok': True, 'study': meta['study']}, ensure_ascii=False, indent=2), encoding='utf-8')
        row = {'fold': int(fold_spec['fold']), **meta['fold_spec']}
        if len(res['summary']):
            row.update(res['summary'].iloc[0].to_dict())
        return row
    finally:
        del train_df, valid_df, test_df
        if fit_res is not None:
            try:
                for k in list(fit_res.keys()):
                    try:
                        del fit_res[k]
                    except Exception:
                        pass
            except Exception:
                pass
        del fit_res
        cleanup_memory()
