from __future__ import annotations

import json
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import duckdb
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

try:
    import yaml
except ImportError:
    yaml = None

from ashare_features import build_features_for_all_stocks
from ashare_labels import (
    DEFAULT_HORIZONS,
    CANDIDATE_MODES,
    build_labels_for_all_stocks,
    finalize_training_labels,
)
from ashare_filters import (
    add_listing_days,
    apply_training_filters,
    summarize_filter_effect,
)
from ashare_backtest import (
    BacktestConfig,
    build_backtest_cache,
    simulate_top1_open_to_next_open_strategy,
    evaluate_topk_signal_quality,
)


# =========================================================
# Config
# =========================================================


@dataclass
class AshareV14FoldConfig:
    db_path: str
    table_name: str
    out_dir: str
    model_dir: str
    export_dir: str

    device: str = "cuda"
    seed: int = 42

    seq_len: int = 20
    warmup_days: int = 90
    min_list_days: int = 60

    train_days: int = 240
    valid_days: int = 60
    test_days: int = 60

    epochs: int = 12
    batch_size: int = 1024
    eval_batch_size: int = 4096
    lr: float = 1e-3
    weight_decay: float = 1e-4
    grad_clip: float = 1.0
    patience: int = 4

    topk_candidates: Tuple[int, ...] = (1,)
    threshold_candidates: Tuple[float, ...] = (0.55, 0.60, 0.65, 0.70, 0.75)
    horizon_candidates: Tuple[int, ...] = DEFAULT_HORIZONS

    only_mainboard: bool = True
    use_amount: bool = True

    # dual-head
    cls_loss_weight: float = 0.8
    reg_loss_weight: float = 1.0

    # filter
    max_calendar_gap_for_training: int = 10

    # breakout 3d signal configuration
    breakout_lookback: int = 20
    min_volume_ratio: float = 1.2
    max_signal_return: float = 0.095
    close_strength_min: float = 0.55
    min_breakout_buffer: float = -0.002
    breakout_success_threshold: float = 0.02
    breakout_candidate_weight: float = 2.0
    breakout_success_weight: float = 3.0
    positive_sample_weight: float = 0.30
    rank_weight_power: float = 1.5
    rank_weight_scale: float = 1.0
    high_score_loss_weight: float = 1.25
    high_score_temperature: float = 1.0
    score_blend_ret: float = 0.65
    score_blend_prob: float = 0.35
    max_positions: int = 3
    require_breakout_candidate: bool = True
    candidate_mode: str = "original"

    # backtest
    initial_cash: float = 100000.0
    board_lot: int = 100
    max_entry_price: float = 40.0

    # step2: stable policy search
    stable_threshold_min: float = 0.45
    stable_threshold_max: float = 0.65
    min_valid_trades: int = 3
    min_valid_days: int = 3
    search_drawdown_penalty: float = 1.5
    search_trade_penalty: float = 0.03
    search_days_penalty: float = 0.02

    # performance/runtime
    num_workers: int = 6
    prefetch_factor: int = 2
    pin_memory: bool = True
    persistent_workers: bool = True
    use_amp: bool = True
    torch_compile: bool = False
    compile_mode: str = "default"
    hidden_channels: Tuple[int, ...] = (64, 64, 64)
    dropout: float = 0.1
    log_interval: int = 50
    visible_tqdm: bool = True
    label_return_mode: str = "max_up"
    target_ret_threshold: float = 0.08
    memory_safe_mode: bool = True



def load_config_from_yaml(yaml_path: str | Path) -> AshareV14FoldConfig:
    if yaml is None:
        raise ImportError("请先安装 pyyaml：python -m pip install pyyaml")

    with open(yaml_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    thresholds = tuple(cfg.get("threshold_candidates", [0.55, 0.60, 0.65, 0.70, 0.75]))
    # 兼容之前的 legacy top1 阈值配置；如果还是 0.00x 级别，就自动切换到 breakout 阈值
    if len(thresholds) > 0 and max(thresholds) <= 0.05:
        thresholds = (0.55, 0.60, 0.65, 0.70, 0.75)

    cfg_obj = AshareV14FoldConfig(
        db_path=cfg["db_path"],
        table_name=cfg["table_name"],
        out_dir=cfg["out_dir"],
        model_dir=cfg["model_dir"],
        export_dir=cfg["export_dir"],
        device=cfg.get("device", "cuda"),
        seed=cfg.get("seed", 42),

        seq_len=cfg.get("seq_len", 20),
        warmup_days=cfg.get("warmup_days", 90),
        min_list_days=cfg.get("min_list_days", 60),

        train_days=cfg.get("train_days", 240),
        valid_days=cfg.get("valid_days", 60),
        test_days=cfg.get("test_days", 60),

        epochs=cfg.get("epochs", 12),
        batch_size=cfg.get("batch_size", 1024),
        eval_batch_size=cfg.get("eval_batch_size", 4096),
        lr=cfg.get("lr", 1e-3),
        weight_decay=cfg.get("weight_decay", 1e-4),
        grad_clip=cfg.get("grad_clip", 1.0),
        patience=cfg.get("patience", 4),

        topk_candidates=tuple(cfg.get("topk_candidates", [1])),
        threshold_candidates=thresholds,
        horizon_candidates=tuple(cfg.get("horizon_candidates", [cfg.get("holding_days", 3)])),

        only_mainboard=cfg.get("only_mainboard", True),
        use_amount=cfg.get("use_amount", True),

        cls_loss_weight=cfg.get("cls_loss_weight", 0.8),
        reg_loss_weight=cfg.get("reg_loss_weight", 1.0),

        max_calendar_gap_for_training=cfg.get("max_calendar_gap_for_training", 10),

        breakout_lookback=int(cfg.get("breakout_lookback", 20)),
        min_volume_ratio=float(cfg.get("min_volume_ratio", cfg.get("breakout_volume_ratio_min", 1.2))),
        max_signal_return=float(cfg.get("max_signal_return", cfg.get("breakout_max_daily_ret", 0.095))),
        close_strength_min=float(cfg.get("close_strength_min", cfg.get("breakout_close_strength_min", 0.55))),
        min_breakout_buffer=float(cfg.get("min_breakout_buffer", cfg.get("breakout_buffer_pct", -0.002))),
        breakout_success_threshold=float(cfg.get("breakout_success_threshold", cfg.get("breakout_success_ret_thres", 0.02))),
        breakout_candidate_weight=float(cfg.get("breakout_candidate_weight", 2.0)),
        breakout_success_weight=float(cfg.get("breakout_success_weight", 3.0)),
        positive_sample_weight=float(cfg.get("positive_sample_weight", 0.30)),
        rank_weight_power=float(cfg.get("rank_weight_power", 1.5)),
        rank_weight_scale=float(cfg.get("rank_weight_scale", 1.0)),
        high_score_loss_weight=float(cfg.get("high_score_loss_weight", 1.25)),
        high_score_temperature=float(cfg.get("high_score_temperature", 1.0)),
        score_blend_ret=float(cfg.get("score_blend_ret", cfg.get("score_blend_strong", 0.65))),
        score_blend_prob=float(cfg.get("score_blend_prob", cfg.get("score_blend_ret", 0.35))),
        max_positions=int(cfg.get("max_positions", 1 if not bool(cfg.get("allow_overlap_positions", False)) else 3)),
        require_breakout_candidate=bool(cfg.get("require_breakout_candidate", True)),
        candidate_mode=str(cfg.get("candidate_mode", cfg.get("candidate_variant", "original"))),

        initial_cash=cfg.get("initial_cash", 100000.0),
        board_lot=cfg.get("board_lot", 100),
        max_entry_price=float(cfg.get("max_entry_price", 40.0)),
        stable_threshold_min=float(cfg.get("stable_threshold_min", 0.45)),
        stable_threshold_max=float(cfg.get("stable_threshold_max", 0.65)),
        min_valid_trades=int(cfg.get("min_valid_trades", 3)),
        min_valid_days=int(cfg.get("min_valid_days", 3)),
        search_drawdown_penalty=float(cfg.get("search_drawdown_penalty", 1.5)),
        search_trade_penalty=float(cfg.get("search_trade_penalty", 0.03)),
        search_days_penalty=float(cfg.get("search_days_penalty", 0.02)),

        num_workers=int(cfg.get("num_workers", 6)),
        prefetch_factor=int(cfg.get("prefetch_factor", 2)),
        pin_memory=bool(cfg.get("pin_memory", True)),
        persistent_workers=bool(cfg.get("persistent_workers", True)),
        use_amp=bool(cfg.get("use_amp", True)),
        torch_compile=bool(cfg.get("torch_compile", False)),
        compile_mode=str(cfg.get("compile_mode", "default")),
        hidden_channels=tuple(cfg.get("hidden_channels", [64, 64, 64])),
        dropout=float(cfg.get("dropout", 0.1)),
        log_interval=int(cfg.get("log_interval", 50)),
        visible_tqdm=bool(cfg.get("visible_tqdm", True)),
        label_return_mode=str(cfg.get("label_return_mode", "max_up")),
        target_ret_threshold=float(cfg.get("target_ret_threshold", cfg.get("breakout_success_threshold", 0.08))),
        memory_safe_mode=bool(cfg.get("memory_safe_mode", True)),
    )
    if cfg_obj.candidate_mode not in CANDIDATE_MODES:
        print(f"[config] 未知 candidate_mode={cfg_obj.candidate_mode}，自动回退到 original")
        cfg_obj.candidate_mode = "original"
    cfg_obj.research_fixed_cash_per_trade = float(cfg.get("research_fixed_cash_per_trade", 100000.0))
    return cfg_obj


def configure_torch_runtime(cfg: AshareV14FoldConfig) -> AshareV14FoldConfig:
    if getattr(cfg, "device", "cpu") == "cuda" and not torch.cuda.is_available():
        print("[runtime] CUDA 不可用，自动切换到 CPU")
        cfg.device = "cpu"

    try:
        torch.backends.cudnn.benchmark = True
    except Exception:
        pass

    try:
        if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
            torch.backends.cuda.matmul.allow_tf32 = True
    except Exception:
        pass

    try:
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.allow_tf32 = True
    except Exception:
        pass

    try:
        if hasattr(torch, "set_float32_matmul_precision"):
            torch.set_float32_matmul_precision("high")
    except Exception:
        pass

    return cfg


def sanitize_feature_cols(df: pd.DataFrame, cols: List[str]) -> List[str]:
    banned = {"date", "symbol", "code", "market", "source_file", "target_ret", "target_cls", "sample_weight", "target_rank_pct", "target_excess_ret", "breakout_candidate", "target_breakout_success"}
    out: List[str] = []
    for c in cols:
        if c in df.columns and c not in banned and pd.api.types.is_numeric_dtype(df[c]):
            out.append(c)
    if len(out) == 0:
        raise RuntimeError("没有可用的数值特征列，请检查 feature_cols。")
    return out


def _clean_feature_block(df: pd.DataFrame, cols: Optional[List[str]] = None) -> pd.DataFrame:
    out = df.copy()
    use_cols = [c for c in (cols or list(out.columns)) if c in out.columns]
    for c in use_cols:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out[use_cols] = (
        out[use_cols]
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .astype(np.float32)
    )
    if "target_ret" in out.columns:
        out["target_ret"] = pd.to_numeric(out["target_ret"], errors="coerce").fillna(0.0).astype(np.float32)
    if "target_cls" in out.columns:
        out["target_cls"] = pd.to_numeric(out["target_cls"], errors="coerce").fillna(0).astype(np.int64)
    return out


# =========================================================
# Utils
# =========================================================

def seed_everything(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_json(path: Path, obj: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


# =========================================================
# Data Loading
# =========================================================

def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _safe_ident(schema_name: str | None, table_name: str) -> str:
    if schema_name:
        return f'{_quote_ident(schema_name)}.{_quote_ident(table_name)}'
    return _quote_ident(table_name)


def _list_duckdb_relations(con) -> pd.DataFrame:
    sql = """
    SELECT table_schema, table_name, table_type
    FROM information_schema.tables
    WHERE lower(table_schema) NOT IN ('information_schema', 'pg_catalog')
    ORDER BY
        CASE WHEN lower(table_schema) IN ('main', 'memory', 'temp') THEN 0 ELSE 1 END,
        table_schema,
        table_name
    """
    return con.execute(sql).fetchdf()


def _candidate_name_score(name: str, wanted: str) -> int:
    low = str(name).lower()
    wanted_low = str(wanted).lower()
    score = 0
    if low == wanted_low:
        score += 100
    if wanted_low and wanted_low in low:
        score += 30
    for key, pts in [
        ('stock_daily_mainboard', 90),
        ('stock_daily', 70),
        ('daily_mainboard', 65),
        ('mainboard_daily', 65),
        ('daily', 20),
        ('stock', 15),
        ('mainboard', 15),
        ('kline', 10),
        ('quote', 10),
    ]:
        if key in low:
            score += pts
    return score


def _describe_columns(con, schema_name: str | None, table_name: str) -> dict:
    rel = _safe_ident(schema_name, table_name)
    cols_df = con.execute(f"DESCRIBE {rel}").fetchdf()
    return {str(x).lower(): str(x) for x in cols_df[cols_df.columns[0]].tolist()}


def _find_alias(cols: dict, aliases: list[str]) -> str | None:
    for alias in aliases:
        if alias.lower() in cols:
            return cols[alias.lower()]
    return None


def _build_market_expr(cols: dict) -> str:
    market_col = _find_alias(cols, ['market', 'exchange', 'market_code', 'mkt', 'board_market'])
    if market_col is not None:
        return f"CAST({_quote_ident(market_col)} AS VARCHAR) AS market"
    symbol_col = _find_alias(cols, ['symbol', 'ts_code', 'ticker', 'stock_code', 'sec_code', 'code'])
    code_col = _find_alias(cols, ['code', 'stock_code', 'sec_code', 'ticker', 'ts_code', 'symbol'])
    src = symbol_col or code_col
    if src is None:
        return "'UNKNOWN' AS market"
    q = _quote_ident(src)
    return (
        "CASE "
        f"WHEN CAST({q} AS VARCHAR) LIKE 'sh%' THEN 'SH' "
        f"WHEN CAST({q} AS VARCHAR) LIKE 'sz%' THEN 'SZ' "
        f"WHEN CAST({q} AS VARCHAR) LIKE 'bj%' THEN 'BJ' "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^6') THEN 'SH' "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^(0|3)') THEN 'SZ' "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^8') THEN 'BJ' "
        "ELSE 'UNKNOWN' END AS market"
    )


def _build_symbol_expr(cols: dict) -> str:
    symbol_col = _find_alias(cols, ['symbol', 'ts_code', 'ticker', 'stock_code', 'sec_code'])
    code_col = _find_alias(cols, ['code', 'stock_code', 'sec_code', 'ticker', 'ts_code', 'symbol'])
    if symbol_col is not None:
        return f"CAST({_quote_ident(symbol_col)} AS VARCHAR) AS symbol"
    if code_col is None:
        raise RuntimeError('缺少 symbol/code 相关字段')
    q = _quote_ident(code_col)
    return (
        "CASE "
        f"WHEN CAST({q} AS VARCHAR) LIKE 'sh%' OR CAST({q} AS VARCHAR) LIKE 'sz%' OR CAST({q} AS VARCHAR) LIKE 'bj%' THEN CAST({q} AS VARCHAR) "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^6') THEN 'sh' || lpad(regexp_replace(CAST({q} AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^(0|3)') THEN 'sz' || lpad(regexp_replace(CAST({q} AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') "
        f"WHEN regexp_matches(CAST({q} AS VARCHAR), '^(4|8)') THEN 'bj' || lpad(regexp_replace(CAST({q} AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') "
        f"ELSE lpad(regexp_replace(CAST({q} AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') END AS symbol"
    )


def _build_code_expr(cols: dict) -> str:
    code_col = _find_alias(cols, ['code', 'stock_code', 'sec_code', 'ticker', 'ts_code', 'symbol'])
    if code_col is None:
        raise RuntimeError('缺少 code 相关字段')
    q = _quote_ident(code_col)
    return f"lpad(regexp_replace(CAST({q} AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') AS code"


def _build_required_exprs(cols: dict) -> dict:
    def pick_any(name: str, aliases: list[str], cast_type: str | None = None, default_sql: str | None = None) -> str:
        col = _find_alias(cols, aliases)
        if col is not None:
            q = _quote_ident(col)
            if cast_type:
                return f"CAST({q} AS {cast_type}) AS {name}"
            return f"{q} AS {name}"
        if default_sql is None:
            raise RuntimeError(f'缺少字段 {name}，可接受别名={aliases}')
        return f"{default_sql} AS {name}"

    return {
        'symbol': _build_symbol_expr(cols),
        'code': _build_code_expr(cols),
        'market': _build_market_expr(cols),
        'date': pick_any('date', ['date', 'trade_date', 'ds'], 'TIMESTAMP'),
        'open': pick_any('open', ['open', 'open_price', 'adj_open'], 'DOUBLE'),
        'high': pick_any('high', ['high', 'high_price', 'adj_high'], 'DOUBLE'),
        'low': pick_any('low', ['low', 'low_price', 'adj_low'], 'DOUBLE'),
        'close': pick_any('close', ['close', 'close_price', 'adj_close'], 'DOUBLE'),
        'volume': pick_any('volume', ['volume', 'vol', 'total_volume', 'turnover_volume'], 'DOUBLE'),
        'amount': pick_any('amount', ['amount', 'turnover', 'turnover_value', 'value', 'total_amount'], 'DOUBLE', '0.0'),
        'source_file': pick_any('source_file', ['source_file', 'source', 'file_name', 'filename'], 'VARCHAR', 'NULL'),
    }


def _choose_best_relation(con, cfg: AshareV14FoldConfig) -> tuple[str | None, str, dict]:
    rels = _list_duckdb_relations(con)
    if rels.empty:
        raise RuntimeError(f'DuckDB 中没有可用表或视图。db_path={cfg.db_path}')

    wanted = str(cfg.table_name)
    ranked = []
    for _, row in rels.iterrows():
        schema_name = str(row.get('table_schema') or '') or None
        table_name = str(row['table_name'])
        try:
            cols = _describe_columns(con, schema_name, table_name)
            exprs = _build_required_exprs(cols)
            coverage = len(exprs)
            score = _candidate_name_score(table_name, wanted) + coverage * 20
            ranked.append((score, schema_name, table_name, cols))
        except Exception:
            continue

    if not ranked:
        names = ', '.join(str(x) for x in rels['table_name'].tolist()[:20])
        raise RuntimeError('DuckDB 中找不到可用于日线训练的表。可见对象: ' + names)

    ranked.sort(key=lambda x: x[0], reverse=True)
    _, schema_name, table_name, cols = ranked[0]
    return schema_name, table_name, cols


def load_stock_daily_mainboard(cfg: AshareV14FoldConfig) -> pd.DataFrame:
    con = duckdb.connect(cfg.db_path)
    try:
        schema_name, target, cols = _choose_best_relation(con, cfg)
        rel = _safe_ident(schema_name, target)
        if str(cfg.table_name) != str(target):
            prefix = f"{schema_name}." if schema_name else ''
            print(f"[prepare] 配置表 {cfg.table_name} 不存在或不兼容，自动改用 {prefix}{target}")

        exprs = _build_required_exprs(cols)
        sql = f"""
            SELECT
                {exprs['symbol']},
                {exprs['code']},
                {exprs['market']},
                {exprs['date']},
                {exprs['open']},
                {exprs['high']},
                {exprs['low']},
                {exprs['close']},
                {exprs['volume']},
                {exprs['amount']},
                {exprs['source_file']}
            FROM {rel}
            ORDER BY 1, 4
        """
        df = con.execute(sql).fetchdf()
    finally:
        con.close()

    df["date"] = pd.to_datetime(df["date"])
    df["symbol"] = df["symbol"].astype(str)
    df["code"] = df["code"].astype(str).str.extract(r'(\d+)', expand=False).fillna(df["code"].astype(str)).str.zfill(6)
    df["market"] = df["market"].astype(str)
    for col in ["open", "high", "low", "close", "volume", "amount"]:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.dropna(subset=["symbol", "date", "open", "high", "low", "close", "volume"]).copy()
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)
    return df


# =========================================================
# Full Data Preparation
# =========================================================

def prepare_full_dataset(cfg: AshareV14FoldConfig) -> Tuple[pd.DataFrame, List[str], Dict]:
    """
    完整数据准备流程：
    1. 读取主板表
    2. 构建特征
    3. 构建标签
    4. 加上市天数
    5. 应用过滤
    6. 最终训练表整理
    """
    print("[prepare] loading daily table from DuckDB ...")
    df_daily = load_stock_daily_mainboard(cfg)
    print(f"[prepare] raw rows={len(df_daily)} symbols={df_daily['symbol'].nunique()}")

    print("[prepare] building features ...")
    df_feat, feature_cols = build_features_for_all_stocks(
        df_daily=df_daily,
        use_amount=cfg.use_amount,
        shift_features=True,
        show_progress=True,
    )
    print(f"[prepare] feature rows={len(df_feat)} feature_count={len(feature_cols)}")

    print("[prepare] building labels ...")
    df_lab = build_labels_for_all_stocks(
        df_feat,
        cls_pos_threshold=0.0,
        horizons=cfg.horizon_candidates,
        breakout_lookback=cfg.breakout_lookback,
        min_volume_ratio=cfg.min_volume_ratio,
        max_signal_return=cfg.max_signal_return,
        close_strength_min=cfg.close_strength_min,
        min_breakout_buffer=cfg.min_breakout_buffer,
        candidate_mode=cfg.candidate_mode,
    )

    print("[prepare] adding listing days ...")
    df_lab = add_listing_days(df_lab)

    print("[prepare] applying training filters ...")
    before_df = df_lab.copy()
    df_filtered = apply_training_filters(
        df_lab,
        min_list_days=cfg.min_list_days,
        max_calendar_gap_for_training=cfg.max_calendar_gap_for_training,
    )
    filter_summary = summarize_filter_effect(before_df, df_filtered)
    print("[prepare] filter summary:")
    print(json.dumps(filter_summary, ensure_ascii=False, indent=2))

    print("[prepare] finalizing training labels ...")
    df_final = finalize_training_labels(
        df=df_filtered,
        feature_cols=feature_cols,
        min_list_days=cfg.min_list_days,
        default_horizon=int(cfg.horizon_candidates[0]),
        breakout_success_threshold=cfg.breakout_success_threshold,
        breakout_candidate_weight=cfg.breakout_candidate_weight,
        breakout_success_weight=cfg.breakout_success_weight,
        positive_sample_weight=cfg.positive_sample_weight,
        rank_weight_power=cfg.rank_weight_power,
        rank_weight_scale=cfg.rank_weight_scale,
        label_return_mode=getattr(cfg, "label_return_mode", "max_up"),
        target_ret_threshold=float(getattr(cfg, "target_ret_threshold", getattr(cfg, "breakout_success_threshold", 0.08))),
    )

    print(f"[prepare] final rows={len(df_final)} symbols={df_final['symbol'].nunique()}")
    print(f"[prepare] final date range: {df_final['date'].min()} -> {df_final['date'].max()}")

    prep_meta = {
        "raw_rows": int(len(df_daily)),
        "raw_symbols": int(df_daily["symbol"].nunique()),
        "feature_rows": int(len(df_feat)),
        "final_rows": int(len(df_final)),
        "final_symbols": int(df_final["symbol"].nunique()),
        "feature_count": int(len(feature_cols)),
        "filter_summary": filter_summary,
        "horizon_candidates": list(cfg.horizon_candidates),
        "candidate_mode": cfg.candidate_mode,
    }
    return df_final, feature_cols, prep_meta


# =========================================================
# Fold Split
# =========================================================

def get_trade_dates(data: pd.DataFrame) -> List[pd.Timestamp]:
    return sorted(pd.to_datetime(data["date"]).drop_duplicates().tolist())


def _build_warmup_slice(
    data: pd.DataFrame,
    target_dates: List[pd.Timestamp],
    all_dates: List[pd.Timestamp],
    warmup_days: int,
) -> pd.DataFrame:
    if len(target_dates) == 0:
        return data.iloc[0:0].copy()

    first_dt = pd.Timestamp(min(target_dates))
    first_idx = all_dates.index(first_dt)
    start_idx = max(0, first_idx - int(warmup_days))
    use_dates = all_dates[start_idx:first_idx] + list(target_dates)

    out = data[data["date"].isin(use_dates)].copy()
    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)
    return out


def split_one_recent_fold_by_dates(data: pd.DataFrame, cfg: AshareV14FoldConfig):
    dates = get_trade_dates(data)
    need = cfg.train_days + cfg.valid_days + cfg.test_days

    if len(dates) < need:
        raise RuntimeError(f"交易日不足：{len(dates)} < {need}")

    fold_dates = dates[-need:]
    train_dates = fold_dates[:cfg.train_days]
    valid_dates = fold_dates[cfg.train_days: cfg.train_days + cfg.valid_days]
    test_dates = fold_dates[cfg.train_days + cfg.valid_days:]

    train_df = data[data["date"].isin(train_dates)].copy()
    train_df = train_df.sort_values(["symbol", "date"]).reset_index(drop=True)

    valid_df = _build_warmup_slice(data=data, target_dates=valid_dates, all_dates=dates, warmup_days=cfg.warmup_days)
    test_df = _build_warmup_slice(data=data, target_dates=test_dates, all_dates=dates, warmup_days=cfg.warmup_days)

    meta = {
        "train_start": str(min(train_dates)),
        "train_end": str(max(train_dates)),
        "valid_start": str(min(valid_dates)),
        "valid_end": str(max(valid_dates)),
        "test_start": str(min(test_dates)),
        "test_end": str(max(test_dates)),
        "train_days": len(train_dates),
        "valid_days": len(valid_dates),
        "test_days": len(test_dates),
        "warmup_days": int(cfg.warmup_days),
        "valid_input_start": str(valid_df["date"].min()) if len(valid_df) else None,
        "test_input_start": str(test_df["date"].min()) if len(test_df) else None,
    }

    return train_df, valid_df, test_df, valid_dates, test_dates, meta


# =========================================================
# Scaler
# =========================================================


class StandardScalerLite:
    def __init__(self):
        self.mean_: Optional[pd.Series] = None
        self.std_: Optional[pd.Series] = None
        self.cols_: Optional[List[str]] = None

    def fit(self, df: pd.DataFrame, cols: List[str]):
        self.cols_ = sanitize_feature_cols(df, cols)

        print("[fit][1/4] cleaning feature block ...")
        t0 = time.perf_counter()
        num_df = _clean_feature_block(df[self.cols_].copy(), self.cols_)
        print(f"[fit][1/4] done in {time.perf_counter() - t0:.2f}s, shape={num_df.shape}")

        print("[fit][2/4] computing mean ...")
        t1 = time.perf_counter()
        self.mean_ = num_df[self.cols_].mean()
        print(f"[fit][2/4] done in {time.perf_counter() - t1:.2f}s")

        print("[fit][3/4] computing std ...")
        t2 = time.perf_counter()
        self.std_ = num_df[self.cols_].std(ddof=0).replace(0, 1.0).fillna(1.0)
        print(f"[fit][3/4] done in {time.perf_counter() - t2:.2f}s")

        print("[fit][4/4] scaler ready")
        return self

    def transform(self, df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
        use_cols = self.cols_ if self.cols_ is not None else sanitize_feature_cols(df, cols)
        out = df.copy()
        out[use_cols] = _clean_feature_block(out[use_cols].copy(), use_cols)[use_cols]
        out[use_cols] = (
            ((out[use_cols] - self.mean_) / self.std_)
            .replace([np.inf, -np.inf], 0.0)
            .fillna(0.0)
            .astype(np.float32)
        )
        return out

    def state_dict(self):
        return {
            "mean": self.mean_.to_dict() if self.mean_ is not None else {},
            "std": self.std_.to_dict() if self.std_ is not None else {},
            "cols": self.cols_ or [],
        }



# =========================================================
# Sequence Dataset
# =========================================================


class AshareSequenceDataset(Dataset):
    def __init__(self, df: pd.DataFrame, feature_cols: List[str], seq_len: int, show_progress: bool = True):
        self.feature_cols = sanitize_feature_cols(df, feature_cols)
        self.seq_len = int(seq_len)
        self.symbol_cache: Dict[str, Dict[str, np.ndarray]] = {}
        self.index_map: List[Tuple[str, int]] = []

        grouped = df.groupby("symbol", sort=True)
        total = int(df["symbol"].nunique())
        iterator = tqdm(
            grouped,
            total=total,
            desc="Building sequence index",
            leave=True,
            dynamic_ncols=True,
        ) if show_progress else grouped

        for symbol, g in iterator:
            g = g.sort_values("date").reset_index(drop=True)
            if len(g) <= self.seq_len:
                continue

            x = g[self.feature_cols].to_numpy(dtype=np.float32, copy=True)
            y_reg = pd.to_numeric(g["target_ret"], errors="coerce").fillna(0.0).to_numpy(dtype=np.float32, copy=True)
            y_cls = pd.to_numeric(g["target_cls"], errors="coerce").fillna(0).to_numpy(dtype=np.int64, copy=True)
            sample_weight = pd.to_numeric(g.get("sample_weight", 1.0), errors="coerce").fillna(1.0).to_numpy(dtype=np.float32, copy=True)
            target_rank_pct = pd.to_numeric(g.get("target_rank_pct", 0.0), errors="coerce").fillna(0.0).to_numpy(dtype=np.float32, copy=True)
            breakout_candidate = pd.to_numeric(g.get("breakout_candidate", 0), errors="coerce").fillna(0).to_numpy(dtype=np.int64, copy=True)
            target_breakout_success = pd.to_numeric(g.get("target_breakout_success", 0), errors="coerce").fillna(0).to_numpy(dtype=np.int64, copy=True)
            codes = g["code"].astype(str).to_numpy(copy=True) if "code" in g.columns else g["symbol"].astype(str).to_numpy(copy=True)
            dates = g["date"].astype(str).to_numpy(copy=True)

            self.symbol_cache[str(symbol)] = {
                "x": x,
                "y_reg": y_reg,
                "y_cls": y_cls,
                "sample_weight": sample_weight,
                "target_rank_pct": target_rank_pct,
                "breakout_candidate": breakout_candidate,
                "target_breakout_success": target_breakout_success,
                "codes": codes,
                "dates": dates,
            }
            for end_idx in range(self.seq_len, len(g)):
                self.index_map.append((str(symbol), int(end_idx)))

    def __len__(self):
        return len(self.index_map)

    def __getitem__(self, idx):
        symbol, end_idx = self.index_map[idx]
        pack = self.symbol_cache[symbol]
        x = pack["x"][end_idx - self.seq_len:end_idx]
        return (
            torch.from_numpy(x),
            torch.tensor(pack["y_reg"][end_idx], dtype=torch.float32),
            torch.tensor(pack["y_cls"][end_idx], dtype=torch.long),
            torch.tensor(pack["sample_weight"][end_idx], dtype=torch.float32),
            torch.tensor(pack["target_rank_pct"][end_idx], dtype=torch.float32),
            torch.tensor(pack["breakout_candidate"][end_idx], dtype=torch.long),
            torch.tensor(pack["target_breakout_success"][end_idx], dtype=torch.long),
            symbol,
            pack["codes"][end_idx],
            pack["dates"][end_idx],
        )




def _build_loader(ds, batch_size: int, shuffle: bool, cfg: AshareV14FoldConfig):
    kwargs = {
        "dataset": ds,
        "batch_size": int(batch_size),
        "shuffle": bool(shuffle),
        "drop_last": bool(shuffle and len(ds) >= int(batch_size)),
        "num_workers": int(max(0, getattr(cfg, "num_workers", 0))),
        "pin_memory": bool(getattr(cfg, "pin_memory", False)) and str(cfg.device).startswith("cuda"),
    }
    if kwargs["num_workers"] > 0:
        kwargs["persistent_workers"] = bool(getattr(cfg, "persistent_workers", True))
        kwargs["prefetch_factor"] = int(max(1, getattr(cfg, "prefetch_factor", 2)))
    return DataLoader(**kwargs)



# =========================================================
# Model
# =========================================================

class ResidualTCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=3, dilation=1, dropout=0.1):
        super().__init__()
        pad = (kernel_size - 1) * dilation

        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size=kernel_size, dilation=dilation, padding=pad)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size=kernel_size, dilation=dilation, padding=pad)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.downsample = nn.Conv1d(in_ch, out_ch, kernel_size=1) if in_ch != out_ch else nn.Identity()

    def forward(self, x):
        out = self.conv1(x)
        out = out[..., :x.size(-1)]
        out = self.relu(out)
        out = self.dropout(out)

        out = self.conv2(out)
        out = out[..., :x.size(-1)]
        out = self.relu(out)
        out = self.dropout(out)

        return out + self.downsample(x)


class DualHeadTCN(nn.Module):
    def __init__(self, n_features: int, channels=(64, 64, 64), dropout=0.1):
        super().__init__()
        blocks = []
        in_ch = n_features
        for i, ch in enumerate(channels):
            blocks.append(ResidualTCNBlock(in_ch, ch, kernel_size=3, dilation=2 ** i, dropout=dropout))
            in_ch = ch

        self.tcn = nn.Sequential(*blocks)

        self.shared_head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(in_ch, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        self.reg_head = nn.Linear(64, 1)
        self.cls_head = nn.Linear(64, 2)

    def forward(self, x):
        # x: [B, T, F] -> [B, F, T]
        x = x.transpose(1, 2)
        h = self.tcn(x)
        z = self.shared_head(h)

        reg = self.reg_head(z).squeeze(-1)
        cls_logits = self.cls_head(z)
        return reg, cls_logits


# =========================================================
# Metrics
# =========================================================

def calc_regression_metrics(pred: pd.Series, true: pd.Series) -> Dict:
    diff = pred - true
    mse = float(np.mean(diff ** 2))
    mae = float(np.mean(np.abs(diff)))

    if len(pred) > 1 and pred.std() > 0 and true.std() > 0:
        corr = float(np.corrcoef(pred, true)[0, 1])
    else:
        corr = 0.0

    return {
        "mse": mse,
        "mae": mae,
        "pearson_corr": corr,
    }


def calc_classification_metrics(prob_pos: pd.Series, true_cls: pd.Series) -> Dict:
    pred_cls = (prob_pos >= 0.5).astype(int)
    acc = float((pred_cls == true_cls).mean()) if len(true_cls) else 0.0
    return {
        "cls_acc": acc,
    }


def calc_daily_ic(pred_df: pd.DataFrame) -> Dict:
    df = pred_df.copy()
    df["date"] = pd.to_datetime(df["date"])

    ic_list = []
    rankic_list = []

    for dt, g in df.groupby("date"):
        if len(g) < 2:
            continue
        if g["pred_ret"].std() == 0 or g["true_ret"].std() == 0:
            continue

        ic = g["pred_ret"].corr(g["true_ret"], method="pearson")
        rankic = g["pred_ret"].corr(g["true_ret"], method="spearman")

        if pd.notna(ic):
            ic_list.append(ic)
        if pd.notna(rankic):
            rankic_list.append(rankic)

    return {
        "mean_ic": float(np.mean(ic_list)) if ic_list else 0.0,
        "mean_rankic": float(np.mean(rankic_list)) if rankic_list else 0.0,
        "n_ic_days": int(len(ic_list)),
        "n_rankic_days": int(len(rankic_list)),
    }


def build_breakout_score(
    pred_df: pd.DataFrame,
    score_blend_ret: float = 0.65,
    score_blend_prob: float = 0.35,
) -> pd.DataFrame:
    df = pred_df.copy()
    df["date"] = pd.to_datetime(df["date"])
    if "pred_ret_raw" not in df.columns:
        df["pred_ret_raw"] = df["pred_ret"].astype(float)
    if "pred_prob_breakout" not in df.columns:
        df["pred_prob_breakout"] = df.get("pred_prob_pos", 0.0)
    df["pred_ret_rank"] = df.groupby("date")["pred_ret_raw"].rank(method="average", pct=True)
    df["pred_breakout_rank"] = df.groupby("date")["pred_prob_breakout"].rank(method="average", pct=True)
    base_score = (
        float(score_blend_ret) * df["pred_ret_rank"].astype(float) +
        float(score_blend_prob) * df["pred_breakout_rank"].astype(float)
    )
    if "breakout_candidate" in df.columns:
        candidate_bonus = 0.10 * df["breakout_candidate"].astype(float)
    else:
        candidate_bonus = 0.0
    df["pred_ret"] = (base_score + candidate_bonus).astype(float)
    return df


def calc_breakout_signal_metrics(
    pred_df: pd.DataFrame,
    score_col: str = "pred_ret",
    threshold: float = 0.60,
    topk: int = 1,
) -> Dict:
    df = pred_df.copy()
    if len(df) == 0:
        return {
            "signal_days": 0,
            "signal_count": 0,
            "signal_avg_true_ret": 0.0,
            "signal_win_rate": 0.0,
            "signal_hit_rate": 0.0,
            "signal_avg_excess_ret": 0.0,
        }
    df["date"] = pd.to_datetime(df["date"])
    if "breakout_candidate" in df.columns:
        df = df[df["breakout_candidate"].fillna(0).astype(int) == 1].copy()
    df = df[df[score_col] > float(threshold)].copy()
    picks = []
    for _, g in df.groupby("date"):
        picks.append(g.sort_values(score_col, ascending=False).head(int(topk)))
    if not picks:
        return {
            "signal_days": 0,
            "signal_count": 0,
            "signal_avg_true_ret": 0.0,
            "signal_win_rate": 0.0,
            "signal_hit_rate": 0.0,
            "signal_avg_excess_ret": 0.0,
        }
    out = pd.concat(picks, axis=0, ignore_index=True)
    day_mean = pred_df.groupby(pd.to_datetime(pred_df["date"]))["true_ret"].mean().rename("day_mean_true_ret")
    out = out.merge(day_mean, left_on=pd.to_datetime(out["date"]), right_index=True, how="left")
    return {
        "signal_days": int(out["date"].nunique()),
        "signal_count": int(len(out)),
        "signal_avg_true_ret": float(out["true_ret"].mean()),
        "signal_win_rate": float((out["true_ret"] > 0).mean()),
        "signal_hit_rate": float(out["true_cls"].mean()) if "true_cls" in out.columns else 0.0,
        "signal_avg_excess_ret": float((out["true_ret"] - out["day_mean_true_ret"]).mean()),
    }


# =========================================================
# Train / Predict
# =========================================================


def run_train_epoch(
    model,
    loader,
    optimizer,
    device,
    epoch_idx=1,
    total_epochs=1,
    grad_clip=1.0,
    reg_loss_weight=1.0,
    cls_loss_weight=0.8,
    use_amp: bool = False,
    log_interval: int = 50,
    visible_tqdm: bool = True,
    high_score_loss_weight: float = 1.25,
    high_score_temperature: float = 1.0,
):
    model.train()
    ce_loss_fn = nn.CrossEntropyLoss(reduction="none")
    scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and str(device).startswith("cuda")))

    total_loss = 0.0
    total_reg = 0.0
    total_cls = 0.0
    total_n = 0

    iterator = tqdm(
        loader,
        desc=f"Train {epoch_idx}/{total_epochs}",
        leave=True,
        dynamic_ncols=True,
    ) if visible_tqdm else loader

    for step, (x, y_reg, y_cls, sample_weight, _, breakout_candidate, _, _, _, _) in enumerate(iterator, start=1):
        x = x.to(device, non_blocking=True)
        y_reg = y_reg.to(device, non_blocking=True)
        y_cls = y_cls.to(device, non_blocking=True)
        sample_weight = sample_weight.to(device, non_blocking=True)
        breakout_candidate = breakout_candidate.to(device, non_blocking=True).float()

        optimizer.zero_grad(set_to_none=True)

        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=(use_amp and str(device).startswith("cuda"))):
            pred_reg, pred_cls_logits = model(x)

            pred_center = pred_reg.detach().median()
            pred_scale = pred_reg.detach().std().clamp_min(1e-6)
            high_score_factor = 1.0 + float(high_score_loss_weight) * torch.sigmoid(
                (pred_reg.detach() - pred_center) / (pred_scale * float(high_score_temperature))
            )
            joint_weight = sample_weight * high_score_factor

            reg_loss_vec = (pred_reg - y_reg) ** 2
            reg_loss = (reg_loss_vec * joint_weight).sum() / joint_weight.sum().clamp_min(1e-6)

            cls_loss_vec = ce_loss_fn(pred_cls_logits, y_cls)
            cls_weight = sample_weight * (1.0 + 0.50 * breakout_candidate)
            cls_loss = (cls_loss_vec * cls_weight).sum() / cls_weight.sum().clamp_min(1e-6)

            loss = reg_loss_weight * reg_loss + cls_loss_weight * cls_loss

        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        scaler.step(optimizer)
        scaler.update()

        bs = len(x)
        total_loss += float(loss.item()) * bs
        total_reg += float(reg_loss.item()) * bs
        total_cls += float(cls_loss.item()) * bs
        total_n += bs

        if visible_tqdm:
            iterator.set_postfix(loss=f"{loss.item():.6f}", reg=f"{reg_loss.item():.6f}", cls=f"{cls_loss.item():.6f}")
        elif step % max(1, int(log_interval)) == 0:
            print(f"[train] epoch={epoch_idx}/{total_epochs} step={step}/{len(loader)} loss={loss.item():.6f} reg={reg_loss.item():.6f} cls={cls_loss.item():.6f}")

    return {
        "loss": total_loss / max(total_n, 1),
        "reg_loss": total_reg / max(total_n, 1),
        "cls_loss": total_cls / max(total_n, 1),
    }


@torch.no_grad()
def predict_dataset(model, loader, device, visible_tqdm: bool = True, cfg: Optional[AshareV14FoldConfig] = None) -> pd.DataFrame:
    model.eval()
    chunks = []

    iterator = tqdm(loader, desc="Predict", leave=True, dynamic_ncols=True) if visible_tqdm else loader
    with torch.inference_mode():
        for x, y_reg, y_cls, sample_weight, target_rank_pct, breakout_candidate, target_breakout_success, symbol, code, dt in iterator:
            x = x.to(device, non_blocking=True)
            pred_reg, pred_cls_logits = model(x)

            chunk = pd.DataFrame({
                "symbol": [str(s) for s in symbol],
                "code": [str(c) for c in code],
                "date": [str(d) for d in dt],
                "pred_ret_raw": pred_reg.detach().cpu().numpy().astype(float),
                "pred_prob_breakout": torch.softmax(pred_cls_logits, dim=1)[:, 1].detach().cpu().numpy().astype(float),
                "true_ret": y_reg.numpy().astype(float),
                "true_cls": y_cls.numpy().astype(int),
                "sample_weight": sample_weight.numpy().astype(float),
                "true_rank_pct": target_rank_pct.numpy().astype(float),
                "breakout_candidate": breakout_candidate.numpy().astype(int),
                "target_breakout_success": target_breakout_success.numpy().astype(int),
            })
            chunk["pred_prob_pos"] = chunk["pred_prob_breakout"]
            chunks.append(chunk)

    pred_df = pd.concat(chunks, axis=0, ignore_index=True) if chunks else pd.DataFrame()
    if cfg is not None and len(pred_df):
        pred_df = build_breakout_score(
            pred_df,
            score_blend_ret=cfg.score_blend_ret,
            score_blend_prob=cfg.score_blend_prob,
        )
    elif len(pred_df):
        pred_df["pred_ret"] = pred_df["pred_ret_raw"].astype(float)
    return pred_df


def fit_and_predict_one_fold_ashare_v14(
    train_df: pd.DataFrame,
    valid_df: pd.DataFrame,
    test_df: pd.DataFrame,
    feature_cols: List[str],
    cfg: AshareV14FoldConfig,
    valid_trade_dates: Optional[List[pd.Timestamp]] = None,
    test_trade_dates: Optional[List[pd.Timestamp]] = None,
):
    cfg = configure_torch_runtime(cfg)
    feature_cols = sanitize_feature_cols(train_df, feature_cols)

    print("[fit] fitting scaler on train ...")
    scaler = StandardScalerLite().fit(train_df, feature_cols)

    print("[fit] scaling train/valid/test tables ...")
    t_scale = time.perf_counter()
    train_df_scaled = scaler.transform(train_df, feature_cols)
    valid_df_scaled = scaler.transform(valid_df, feature_cols)
    test_df_scaled = scaler.transform(test_df, feature_cols)
    print(f"[fit] scaling done in {time.perf_counter() - t_scale:.2f}s")

    print("[fit] building train/valid/test sequence datasets ...")
    t_ds = time.perf_counter()
    ds_train = AshareSequenceDataset(train_df_scaled, feature_cols, cfg.seq_len, show_progress=cfg.visible_tqdm)
    ds_valid = AshareSequenceDataset(valid_df_scaled, feature_cols, cfg.seq_len, show_progress=cfg.visible_tqdm)
    ds_test = AshareSequenceDataset(test_df_scaled, feature_cols, cfg.seq_len, show_progress=cfg.visible_tqdm)
    print(f"[fit] dataset build done in {time.perf_counter() - t_ds:.2f}s")

    dl_train = _build_loader(ds_train, cfg.batch_size, True, cfg)
    dl_valid = _build_loader(ds_valid, cfg.eval_batch_size, False, cfg)
    dl_test = _build_loader(ds_test, cfg.eval_batch_size, False, cfg)

    print(f"[fit] n_train_samples={len(ds_train)}")
    print(f"[fit] n_valid_samples={len(ds_valid)}")
    print(f"[fit] n_test_samples={len(ds_test)}")
    print(json.dumps({
        "device": cfg.device,
        "num_workers": cfg.num_workers,
        "pin_memory": cfg.pin_memory,
        "prefetch_factor": cfg.prefetch_factor if cfg.num_workers > 0 else None,
        "persistent_workers": cfg.persistent_workers if cfg.num_workers > 0 else None,
        "use_amp": cfg.use_amp,
        "batch_size": cfg.batch_size,
        "eval_batch_size": cfg.eval_batch_size,
        "feature_count": len(feature_cols),
    }, ensure_ascii=False, indent=2))

    model = DualHeadTCN(n_features=len(feature_cols), channels=cfg.hidden_channels, dropout=cfg.dropout).to(cfg.device)
    if cfg.torch_compile and hasattr(torch, "compile"):
        try:
            model = torch.compile(model, mode=cfg.compile_mode)
            print(f"[fit] torch.compile enabled, mode={cfg.compile_mode}")
        except Exception as e:
            print(f"[fit] torch.compile failed, skip: {e}")

    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    best_valid_score = -1e18
    best_state = None
    wait = 0
    epoch_records = []

    for epoch in range(cfg.epochs):
        print(f"\\n========== Epoch {epoch + 1}/{cfg.epochs} ==========")

        train_stat = run_train_epoch(
            model=model,
            loader=dl_train,
            optimizer=optimizer,
            device=cfg.device,
            epoch_idx=epoch + 1,
            total_epochs=cfg.epochs,
            grad_clip=cfg.grad_clip,
            reg_loss_weight=cfg.reg_loss_weight,
            cls_loss_weight=cfg.cls_loss_weight,
            use_amp=cfg.use_amp,
            log_interval=cfg.log_interval,
            visible_tqdm=cfg.visible_tqdm,
            high_score_loss_weight=cfg.high_score_loss_weight,
            high_score_temperature=cfg.high_score_temperature,
        )

        valid_pred = predict_dataset(model, dl_valid, cfg.device, visible_tqdm=cfg.visible_tqdm, cfg=cfg)

        reg_metrics = calc_regression_metrics(valid_pred["pred_ret_raw"], valid_pred["true_ret"])
        cls_metrics = calc_classification_metrics(valid_pred["pred_prob_breakout"], valid_pred["true_cls"])
        ic_metrics = calc_daily_ic(valid_pred)
        signal_metrics = calc_breakout_signal_metrics(
            valid_pred,
            score_col="pred_ret",
            threshold=min(cfg.threshold_candidates),
            topk=max(cfg.topk_candidates),
        )

        valid_score = (
            signal_metrics["signal_avg_true_ret"] * 35.0 +
            signal_metrics["signal_win_rate"] * 12.0 +
            signal_metrics["signal_hit_rate"] * 12.0 +
            signal_metrics["signal_avg_excess_ret"] * 10.0 +
            ic_metrics["mean_rankic"] * 2.0
        )

        epoch_rec = {
            "epoch": epoch + 1,
            **train_stat,
            **reg_metrics,
            **cls_metrics,
            **ic_metrics,
            **signal_metrics,
            "valid_score": float(valid_score),
        }
        epoch_records.append(epoch_rec)

        print(json.dumps(epoch_rec, ensure_ascii=False, indent=2))

        if valid_score > best_valid_score:
            best_valid_score = valid_score
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            wait = 0
            print(f"[fit] best model updated. valid_score={best_valid_score:.6f}")
        else:
            wait += 1
            print(f"[fit] no improvement. patience={wait}/{cfg.patience}")
            if wait >= cfg.patience:
                print("[fit] early stopping triggered.")
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    print("[fit] predicting valid/test with best model ...")
    valid_pred = predict_dataset(model, dl_valid, cfg.device, visible_tqdm=cfg.visible_tqdm, cfg=cfg)
    test_pred = predict_dataset(model, dl_test, cfg.device, visible_tqdm=cfg.visible_tqdm, cfg=cfg)

    if valid_trade_dates is not None and len(valid_pred):
        valid_trade_dates = set(pd.to_datetime(valid_trade_dates))
        valid_pred = valid_pred[pd.to_datetime(valid_pred["date"]).isin(valid_trade_dates)].copy()
    if test_trade_dates is not None and len(test_pred):
        test_trade_dates = set(pd.to_datetime(test_trade_dates))
        test_pred = test_pred[pd.to_datetime(test_pred["date"]).isin(test_trade_dates)].copy()

    valid_pred = valid_pred.sort_values(["date", "symbol"]).reset_index(drop=True)
    test_pred = test_pred.sort_values(["date", "symbol"]).reset_index(drop=True)

    return {
        "model": model,
        "scaler": scaler,
        "valid_pred": valid_pred,
        "test_pred": test_pred,
        "n_train_samples": len(ds_train),
        "n_valid_samples": len(ds_valid),
        "n_test_samples": len(ds_test),
        "epoch_records": pd.DataFrame(epoch_records),
        "feature_cols": feature_cols,
    }



# =========================================================
# Policy Search
# =========================================================

def search_best_policy_ashare_v14(
    valid_pred: pd.DataFrame,
    valid_raw_df: pd.DataFrame,
    cfg: AshareV14FoldConfig,
    horizon: int = 1,
):
    rows = []
    best = None

    raw_thresholds = [float(x) for x in cfg.threshold_candidates]
    use_thresholds = [x for x in raw_thresholds if float(cfg.stable_threshold_min) <= x <= float(cfg.stable_threshold_max)]
    if not use_thresholds:
        use_thresholds = raw_thresholds

    total_trials = len(cfg.topk_candidates) * len(use_thresholds)
    pbar = tqdm(total=total_trials, desc="Searching valid policy")

    cache_cfg = BacktestConfig(
        initial_cash=cfg.initial_cash,
        board_lot=cfg.board_lot,
        max_entry_price=cfg.max_entry_price,
        topk=max(cfg.topk_candidates),
        threshold=min(use_thresholds),
        full_position=True,
        horizon=int(horizon),
        max_positions=cfg.max_positions,
        require_breakout_candidate=cfg.require_breakout_candidate,
    )
    prepared_cache = build_backtest_cache(
        pred_df=valid_pred,
        raw_daily_df=valid_raw_df,
        backtest_cfg=cache_cfg,
    )

    for topk in cfg.topk_candidates:
        for threshold in use_thresholds:
            signal_stat = evaluate_topk_signal_quality(
                valid_pred,
                topk=topk,
                threshold=threshold,
            )

            bt_cfg = BacktestConfig(
                initial_cash=cfg.initial_cash,
                board_lot=cfg.board_lot,
                max_entry_price=cfg.max_entry_price,
                topk=topk,
                threshold=threshold,
                full_position=True,
                horizon=int(horizon),
                max_positions=cfg.max_positions,
                require_breakout_candidate=cfg.require_breakout_candidate,
            )
            _, _, bt_stat = simulate_top1_open_to_next_open_strategy(
                pred_df=valid_pred,
                raw_daily_df=valid_raw_df,
                backtest_cfg=bt_cfg,
                show_progress=False,
                prepared_cache=prepared_cache,
            )

            rec = {
                "topk": int(topk),
                "threshold": float(threshold),
                "signal_avg_true_ret": signal_stat["avg_true_ret"],
                "signal_win_rate": signal_stat["win_rate"],
                "signal_sum_true_ret": signal_stat["sum_true_ret"],
                "signal_hit_rate": signal_stat["hit_rate"],
                "signal_n_days": signal_stat["n_days"],
                "signal_n_picks": signal_stat["n_picks"],
                "bt_final_equity": bt_stat["final_equity"],
                "bt_total_return": bt_stat["total_return"],
                "bt_max_drawdown": bt_stat["max_drawdown"],
                "bt_win_rate": bt_stat["win_rate"],
                "bt_avg_trade_ret": bt_stat["avg_trade_ret"],
                "bt_n_trades": bt_stat["n_trades"],
                "horizon": int(horizon),
            }

            trade_shortfall = max(0, int(cfg.min_valid_trades) - int(rec["bt_n_trades"]))
            day_shortfall = max(0, int(cfg.min_valid_days) - int(rec["signal_n_days"]))
            feasible = (trade_shortfall == 0 and day_shortfall == 0)
            rec["is_feasible"] = int(feasible)
            rec["trade_shortfall"] = trade_shortfall
            rec["day_shortfall"] = day_shortfall

            rec["score"] = (
                rec["bt_total_return"] * 6.0 +
                rec["bt_win_rate"] * 1.5 +
                rec["signal_avg_true_ret"] * 25.0 +
                rec["signal_hit_rate"] * 10.0 +
                rec["bt_max_drawdown"] * float(cfg.search_drawdown_penalty) -
                trade_shortfall * float(cfg.search_trade_penalty) -
                day_shortfall * float(cfg.search_days_penalty)
            )
            rec["stable_score"] = rec["score"]

            rows.append(rec)
            if best is None:
                best = rec
            else:
                cand_key = (rec["is_feasible"], rec["stable_score"], rec["bt_total_return"], -abs(rec["threshold"] - 0.55))
                best_key = (best["is_feasible"], best["stable_score"], best["bt_total_return"], -abs(best["threshold"] - 0.55))
                if cand_key > best_key:
                    best = rec
            pbar.update(1)

    pbar.close()

    grid_df = pd.DataFrame(rows).sort_values(["is_feasible", "stable_score", "bt_total_return"], ascending=False).reset_index(drop=True)
    return {
        "best": best,
        "grid_df": grid_df,
    }


# =========================================================
# Test Backtest
# =========================================================

def run_test_backtest_with_policy(
    test_pred: pd.DataFrame,
    test_raw_df: pd.DataFrame,
    policy: Dict,
    cfg: AshareV14FoldConfig,
):
    bt_cfg = BacktestConfig(
        initial_cash=cfg.initial_cash,
        board_lot=cfg.board_lot,
        max_entry_price=cfg.max_entry_price,
        topk=int(policy["topk"]),
        threshold=float(policy["threshold"]),
        full_position=True,
        horizon=int(policy.get("horizon", 3)),
        max_positions=cfg.max_positions,
        require_breakout_candidate=cfg.require_breakout_candidate,
    )

    equity_df, trades_df, bt_stat = simulate_top1_open_to_next_open_strategy(
        pred_df=test_pred,
        raw_daily_df=test_raw_df,
        backtest_cfg=bt_cfg,
        show_progress=True,
    )

    return {
        "equity_df": equity_df,
        "trades_df": trades_df,
        "bt_stat": bt_stat,
    }


# =========================================================
# Export
# =========================================================

def export_live_model_artifacts(model, scaler, feature_cols, selected_policy, export_dir: Path):
    export_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), export_dir / "model.pt")
    save_json(export_dir / "scaler.json", scaler.state_dict())
    save_json(export_dir / "feature_cols.json", {"feature_cols": feature_cols})
    save_json(export_dir / "selected_policy.json", selected_policy)


def export_one_fold_outputs(
    cfg: AshareV14FoldConfig,
    prep_meta: Dict,
    fold_meta: Dict,
    fit_res: Dict,
    valid_policy_res: Dict,
    test_backtest_res: Dict,
):
    run_dir = ensure_dir(Path(cfg.out_dir) / "one_fold_run")
    model_dir = ensure_dir(cfg.model_dir)
    export_dir = ensure_dir(cfg.export_dir)

    # csv
    fit_res["valid_pred"].to_csv(run_dir / "valid_pred.csv", index=False, encoding="utf-8-sig")
    fit_res["test_pred"].to_csv(run_dir / "test_pred.csv", index=False, encoding="utf-8-sig")
    fit_res["epoch_records"].to_csv(run_dir / "epoch_records.csv", index=False, encoding="utf-8-sig")
    valid_policy_res["grid_df"].to_csv(run_dir / "valid_policy_grid.csv", index=False, encoding="utf-8-sig")

    test_backtest_res["equity_df"].to_csv(run_dir / "test_equity_curve.csv", index=False, encoding="utf-8-sig")
    test_backtest_res["trades_df"].to_csv(run_dir / "test_trade_log.csv", index=False, encoding="utf-8-sig")

    # json
    meta = {
        "prep_meta": prep_meta,
        "fold_meta": fold_meta,
        "n_train_samples": fit_res["n_train_samples"],
        "n_valid_samples": fit_res["n_valid_samples"],
        "n_test_samples": fit_res["n_test_samples"],
        "best_policy": valid_policy_res["best"],
        "test_backtest_stat": test_backtest_res["bt_stat"],
    }
    save_json(run_dir / "one_fold_meta.json", meta)

    export_live_model_artifacts(
        model=fit_res["model"],
        scaler=fit_res["scaler"],
        feature_cols=json.loads(json.dumps(fit_res["valid_pred"].columns.tolist(), ensure_ascii=False)),  # 占位，下面会被正确覆盖
        selected_policy=valid_policy_res["best"],
        export_dir=model_dir,
    )


def export_model_artifacts_correct(
    model,
    scaler,
    feature_cols,
    selected_policy,
    model_dir: str | Path,
):
    model_dir = ensure_dir(model_dir)
    torch.save(model.state_dict(), Path(model_dir) / "model.pt")
    save_json(Path(model_dir) / "scaler.json", scaler.state_dict())
    save_json(Path(model_dir) / "feature_cols.json", {"feature_cols": feature_cols})
    save_json(Path(model_dir) / "selected_policy.json", selected_policy)

# Hotfix: 兼容 experiment_common / 旧调用链对 ashare_v14.prepare_prediction_table_for_backtest 的引用
def prepare_prediction_table_for_backtest(pred_df, raw_daily_df, horizon=3):
    from ashare_backtest import prepare_prediction_table_for_backtest as _impl
    return _impl(pred_df=pred_df, raw_daily_df=raw_daily_df, horizon=horizon)


# backward-compatible alias
AshareV14Config = AshareV14FoldConfig
