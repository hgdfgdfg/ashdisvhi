from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List
import numpy as np
import pandas as pd
import duckdb

import ashare_v14_fold as v14
from ashare_backtest import prepare_prediction_table_for_backtest
from experiment_common_v14_fold import (
    log_time,
    cleanup_memory,
    _add_v15_future_stats,
    _add_pretrade_features,
    build_close5_prob_metrics,
    _ensure_daily_pred_rank,
    load_benchmark_daily_from_duckdb,
    attach_benchmark_features,
    build_independent_market_features,
    build_v15_4_reward_addon,
    build_v15_4_reward_score_within_topn,
    _build_kline_windows,
)

def _to_num(s):
    return pd.to_numeric(s, errors='coerce')

def _clip01(x):
    return np.clip(pd.to_numeric(x, errors='coerce').astype(float), 0.0, 1.0)

def _safe_mean(df: pd.DataFrame, col: str):
    if df is None or df.empty or col not in df.columns:
        return np.nan
    return float(pd.to_numeric(df[col], errors='coerce').mean())

def _minmax_norm_series(s: pd.Series) -> pd.Series:
    x = pd.to_numeric(s, errors='coerce')
    lo = x.min()
    hi = x.max()
    if pd.isna(lo) or pd.isna(hi) or hi - lo <= 1e-12:
        return pd.Series(0.5, index=s.index, dtype=float)
    return ((x - lo) / (hi - lo)).clip(0.0, 1.0)

def _build_long_history_features(day_df: pd.DataFrame, raw_df: pd.DataFrame) -> pd.DataFrame:
    out = day_df.copy()
    raw = raw_df.copy()
    raw['date'] = pd.to_datetime(raw['date'])
    raw = raw.sort_values(['symbol','date']).reset_index(drop=True)
    cal = {str(sym): g.reset_index(drop=True) for sym, g in raw.groupby('symbol', sort=False)}
    rows = []
    for r in out.itertuples(index=False):
        sym = str(r.symbol)
        ent = pd.Timestamp(r.entry_date)
        g = cal.get(sym)
        feat = {'symbol': sym, 'date': pd.Timestamp(getattr(r, 'date'))}
        if g is None or g.empty or pd.isna(ent):
            rows.append(feat); continue
        idxs = g.index[g['date'] == ent].tolist()
        if not idxs:
            rows.append(feat); continue
        i0 = idxs[0]
        prev = g.iloc[max(0, i0-180):i0].copy()
        if prev.empty:
            rows.append(feat); continue
        c = pd.to_numeric(prev['close'], errors='coerce')
        cur = float(c.iloc[-1]) if len(c) else np.nan
        def runup(n):
            if len(c) >= n:
                base = float(c.iloc[-n])
                return cur/base - 1.0 if np.isfinite(base) and base > 0 and np.isfinite(cur) else np.nan
            return np.nan
        feat.update({
            'hist_runup_5d_close': runup(5),
            'hist_runup_10d_close': runup(10),
            'hist_runup_20d_close': runup(20),
            'hist_runup_60d_close': runup(60),
            'hist_runup_120d_close': runup(120),
            'hist_180d_pos': (cur/float(c.max()) if len(c) and np.isfinite(cur) and float(c.max()) > 0 else np.nan),
            'hist_days_since_high': (int((len(c)-1)-int(np.argmax(c.values))) if len(c) else np.nan),
            'dd_from_60d_high': (cur/float(c.tail(60).max()) - 1.0 if len(c)>=60 and float(c.tail(60).max()) > 0 and np.isfinite(cur) else np.nan),
        })
        rows.append(feat)
    fdf = pd.DataFrame(rows)
    return out.merge(fdf, on=['symbol','date'], how='left')


def _normalize_symbol_local(x) -> str:
    s = str(x)
    m = ''.join(ch for ch in s if ch.isdigit())
    return m.zfill(6) if m else s.strip()

def _load_candidate_history_from_duckdb(day_df: pd.DataFrame, cfg, lookback_days: int = 180, extra_buffer_days: int = 40) -> pd.DataFrame:
    if day_df is None or day_df.empty:
        return pd.DataFrame(columns=['symbol','date','open','high','low','close','volume','amount'])

    syms = sorted({_normalize_symbol_local(s) for s in day_df['symbol'].astype(str).tolist()})

    # fix3: entry_date 可能有 NaT，优先用有效 entry_date；若缺失则回退到 signal date。
    dt_src = None
    if 'entry_date' in day_df.columns:
        dt_src = pd.to_datetime(day_df['entry_date'], errors='coerce')
    else:
        dt_src = pd.Series(pd.NaT, index=day_df.index)
    if ('date' in day_df.columns):
        signal_dt = pd.to_datetime(day_df['date'], errors='coerce')
        dt_src = dt_src.fillna(signal_dt)

    valid_dt = dt_src.dropna()
    if valid_dt.empty:
        return pd.DataFrame(columns=['symbol','date','open','high','low','close','volume','amount'])

    min_dt = valid_dt.min()
    max_dt = valid_dt.max()
    start_dt = (pd.Timestamp(min_dt) - pd.Timedelta(days=int(lookback_days + extra_buffer_days))).date()
    end_dt = pd.Timestamp(max_dt).date()

    con = duckdb.connect(cfg.db_path)
    try:
        # fix4: 固定使用 stock_daily_mainboard，避免自动选表造成行集不稳定。
        rel = 'stock_daily_mainboard'
        sym_list = ",".join([f"'{s}'" for s in syms]) if syms else "''"
        sql = f"""
            SELECT
                date,
                open,
                high,
                low,
                close,
                volume,
                amount,
                symbol AS raw_symbol,
                market AS raw_market
            FROM {rel}
            WHERE CAST(date AS DATE) BETWEEN DATE '{start_dt}' AND DATE '{end_dt}'
              AND lpad(regexp_replace(CAST(symbol AS VARCHAR), '[^0-9]', '', 'g'), 6, '0') IN ({sym_list})
            ORDER BY 1
        """
        hist = con.execute(sql).fetchdf()
    finally:
        con.close()

    if hist is None or hist.empty:
        return pd.DataFrame(columns=['symbol','date','open','high','low','close','volume','amount'])

    hist['date'] = pd.to_datetime(hist['date'])
    hist['symbol'] = hist['raw_symbol'].astype(str).map(_normalize_symbol_local)
    hist = hist[hist['symbol'].isin(syms)].copy()
    for c in ['open','high','low','close','volume']:
        if c in hist.columns:
            hist[c] = pd.to_numeric(hist[c], errors='coerce')
        else:
            hist[c] = np.nan
    if 'amount' not in hist.columns:
        hist['amount'] = np.nan
    keep = ['symbol','date','open','high','low','close','volume','amount']
    return hist[keep].sort_values(['symbol','date']).reset_index(drop=True)

def _build_long_history_features_from_duckdb(day_df: pd.DataFrame, cfg, lookback_days: int = 180) -> pd.DataFrame:
    out = day_df.copy()
    hist = _load_candidate_history_from_duckdb(out, cfg, lookback_days=lookback_days)
    if hist.empty:
        # safe empty columns
        for c in ['hist_runup_5d_close','hist_runup_10d_close','hist_runup_20d_close','hist_runup_60d_close','hist_runup_120d_close','hist_180d_pos','hist_days_since_high','dd_from_60d_high']:
            if c not in out.columns:
                out[c] = np.nan
        return out

    hist['date'] = pd.to_datetime(hist['date'])
    cal = {str(sym): g.reset_index(drop=True) for sym, g in hist.groupby('symbol', sort=False)}
    rows = []
    for r in out.itertuples(index=False):
        sym = _normalize_symbol_local(r.symbol)
        ent_raw = getattr(r, 'entry_date', pd.NaT)
        ent = pd.to_datetime(ent_raw, errors='coerce')
        if pd.isna(ent):
            ent = pd.to_datetime(getattr(r, 'date', pd.NaT), errors='coerce')
        g = cal.get(sym)
        feat = {'symbol': r.symbol, 'date': pd.Timestamp(getattr(r, 'date'))}
        if g is None or g.empty or pd.isna(ent):
            rows.append(feat); continue
        # use history strictly before entry_date
        prev = g[g['date'] < ent].copy().tail(lookback_days)
        if prev.empty:
            rows.append(feat); continue
        c = pd.to_numeric(prev['close'], errors='coerce').dropna()
        if c.empty:
            rows.append(feat); continue
        cur = float(c.iloc[-1])
        def runup(n):
            if len(c) >= n:
                base = float(c.iloc[-n])
                return cur / base - 1.0 if np.isfinite(base) and base > 0 and np.isfinite(cur) else np.nan
            return np.nan
        feat.update({
            'hist_runup_5d_close': runup(5),
            'hist_runup_10d_close': runup(10),
            'hist_runup_20d_close': runup(20),
            'hist_runup_60d_close': runup(60),
            'hist_runup_120d_close': runup(120),
            'hist_180d_pos': (cur / float(c.max()) if np.isfinite(cur) and float(c.max()) > 0 else np.nan),
            'hist_days_since_high': (int((len(c)-1) - int(np.argmax(c.values))) if len(c) else np.nan),
            'dd_from_60d_high': (cur / float(c.tail(60).max()) - 1.0 if len(c) >= 60 and float(c.tail(60).max()) > 0 else np.nan),
        })
        rows.append(feat)
    fdf = pd.DataFrame(rows)
    return out.merge(fdf, on=['symbol','date'], how='left')


def apply_v154a_close_quality_filter(day_df: pd.DataFrame, cfg) -> pd.DataFrame:
    out = day_df.copy().sort_values(['reward_score','pred_rank'], ascending=[False, True]).copy()

    # fix1: 历史长周期特征必须在外层基于 raw_df 统一构建。
    # 这里不再错误地用 out 自身重算 180 日特征。
    hist_cols = [
        'hist_runup_5d_close',
        'hist_runup_10d_close',
        'hist_runup_20d_close',
        'hist_runup_60d_close',
        'hist_runup_120d_close',
        'hist_180d_pos',
        'hist_days_since_high',
        'dd_from_60d_high',
    ]
    for c in hist_cols:
        if c not in out.columns:
            out[c] = np.nan

    # hard filter flags
    cond = (
        (_to_num(out['pre_5d_ret']) >= float(getattr(cfg, 'v154a_min_pre_5d_ret', 0.06))) &
        (_to_num(out['excess_ret_5d']) >= float(getattr(cfg, 'v154a_min_excess_ret_5d', 0.04))) &
        (_to_num(out['hist_runup_60d_close']) >= float(getattr(cfg, 'v154a_min_hist_runup_60d_close', 0.50))) &
        (_to_num(out['hist_180d_pos']) >= float(getattr(cfg, 'v154a_min_hist_180d_pos', 0.85))) &
        (_to_num(out['dd_from_60d_high']) >= float(getattr(cfg, 'v154a_min_dd_from_60d_high', -0.12))) &
        (_to_num(out['hist_days_since_high']) <= float(getattr(cfg, 'v154a_max_hist_days_since_high', 25)))
    )
    out['v154a_filter_pass'] = cond.astype(int)

    # score components only within day top10
    strength_short = (
        float(getattr(cfg,'v154a_f_pre5',0.45))*_minmax_norm_series(out['pre_5d_ret']) +
        float(getattr(cfg,'v154a_f_pre10',0.25))*_minmax_norm_series(out['pre_10d_ret']) +
        float(getattr(cfg,'v154a_f_excess5',0.30))*_minmax_norm_series(out['excess_ret_5d'])
    )
    trend_quality = (
        float(getattr(cfg,'v154a_f_runup60',0.40))*_minmax_norm_series(out['hist_runup_60d_close']) +
        float(getattr(cfg,'v154a_f_runup120',0.35))*_minmax_norm_series(out['hist_runup_120d_close']) +
        float(getattr(cfg,'v154a_f_pos180',0.25))*_minmax_norm_series(out['hist_180d_pos'])
    )
    high_zone_health = (
        float(getattr(cfg,'v154a_f_dd60',0.55))*_minmax_norm_series(-_to_num(out['dd_from_60d_high'])) +
        float(getattr(cfg,'v154a_f_days_since_high',0.45))*_minmax_norm_series(-_to_num(out['hist_days_since_high']))
    )
    pen_pre5 = ((_to_num(out['pre_5d_ret']) - float(getattr(cfg,'v154a_overheat_pre_5d_ret',0.22))) / max(0.10, float(getattr(cfg,'v154a_overheat_pre_5d_ret',0.22)))).clip(lower=0.0)
    pen_pre10 = ((_to_num(out['pre_10d_ret']) - float(getattr(cfg,'v154a_overheat_pre_10d_ret',0.40))) / max(0.15, float(getattr(cfg,'v154a_overheat_pre_10d_ret',0.40)))).clip(lower=0.0)
    overheat_penalty = (0.5*pen_pre5 + 0.5*pen_pre10).clip(0.0, 1.0)

    out['v154a_strength_short'] = strength_short
    out['v154a_trend_quality'] = trend_quality
    out['v154a_high_zone_health'] = high_zone_health
    out['v154a_overheat_penalty'] = overheat_penalty

    out['v154a_close_quality_score'] = (
        float(getattr(cfg,'v154a_w_strength_short',0.38))*out['v154a_strength_short'] +
        float(getattr(cfg,'v154a_w_trend_quality',0.34))*out['v154a_trend_quality'] +
        float(getattr(cfg,'v154a_w_high_zone_health',0.20))*out['v154a_high_zone_health'] -
        float(getattr(cfg,'v154a_w_overheat_penalty',0.08))*out['v154a_overheat_penalty']
    )
    # fallback to reward top1 if no pass candidates
    if out['v154a_filter_pass'].sum() > 0:
        sub = out[out['v154a_filter_pass'] == 1].copy()
        sub['v154a_final_score'] = pd.to_numeric(sub['reward_score'], errors='coerce').fillna(0.0) + sub['v154a_close_quality_score']
        rest = out[out['v154a_filter_pass'] == 0].copy()
        rest['v154a_final_score'] = pd.to_numeric(rest['reward_score'], errors='coerce').fillna(0.0) - 999.0
        out = pd.concat([sub, rest], ignore_index=False)
    else:
        out['v154a_final_score'] = pd.to_numeric(out['reward_score'], errors='coerce').fillna(0.0)
    out['v154a_rank'] = out['v154a_final_score'].rank(method='first', ascending=False)
    out['v154a_selected'] = (out['v154a_rank'] == 1).astype(int)
    return out.sort_values(['v154a_rank','reward_rank','pred_rank'])

def _extract_pick_metrics(rec: pd.Series, prefix: str) -> dict:
    return {
        f'{prefix}_symbol': rec.get('symbol'),
        f'{prefix}_code': rec.get('code'),
        f'{prefix}_pred_rank': rec.get('pred_rank'),
        f'{prefix}_pred_ret': rec.get('pred_ret'),
        f'{prefix}_pred_prob_pos': rec.get('pred_prob_pos'),
        f'{prefix}_baseline_score': rec.get('baseline_score'),
        f'{prefix}_reward_addon': rec.get('reward_addon'),
        f'{prefix}_reward_score': rec.get('reward_score'),
        f'{prefix}_true_max_up_5': rec.get('true_max_up_5'),
        f'{prefix}_hit8_5': rec.get('hit_8_5'),
        f'{prefix}_hit10_5': rec.get('hit_10_5'),
        f'{prefix}_post_day1_ret': rec.get('post_day1_ret'),
        f'{prefix}_post_day2_ret': rec.get('post_day2_ret'),
        f'{prefix}_post_day3_ret': rec.get('post_day3_ret'),
        f'{prefix}_ret_close5_vs_open_t': rec.get('ret_close5_vs_open_t'),
        f'{prefix}_hit_close5_open_t_8': rec.get('hit_close5_open_t_8'),
        f'{prefix}_hit_close5_open_t_10': rec.get('hit_close5_open_t_10'),
    }

def _extract_pick_metrics_v154a(rec: pd.Series, prefix: str) -> dict:
    d = _extract_pick_metrics(rec, prefix)
    d.update({
        f'{prefix}_pre_5d_ret': rec.get('pre_5d_ret'),
        f'{prefix}_pre_10d_ret': rec.get('pre_10d_ret'),
        f'{prefix}_excess_ret_5d': rec.get('excess_ret_5d'),
        f'{prefix}_hist_runup_60d_close': rec.get('hist_runup_60d_close'),
        f'{prefix}_hist_runup_120d_close': rec.get('hist_runup_120d_close'),
        f'{prefix}_hist_180d_pos': rec.get('hist_180d_pos'),
        f'{prefix}_dd_from_60d_high': rec.get('dd_from_60d_high'),
        f'{prefix}_hist_days_since_high': rec.get('hist_days_since_high'),
        f'{prefix}_v154a_filter_pass': rec.get('v154a_filter_pass'),
        f'{prefix}_v154a_close_quality_score': rec.get('v154a_close_quality_score'),
        f'{prefix}_v154a_final_score': rec.get('v154a_final_score'),
    })
    return d

def summarize_v154a_daily_compare(daily_df: pd.DataFrame) -> pd.DataFrame:
    if daily_df is None or daily_df.empty:
        return pd.DataFrame()
    def m(c): return _safe_mean(daily_df, c)
    s = {
        'baseline_top1_avg_true_max_up_5': m('baseline_top1_true_max_up_5'),
        'baseline_top1_hit8_rate_5': m('baseline_top1_hit8_5'),
        'baseline_top1_hit10_rate_5': m('baseline_top1_hit10_5'),
        'baseline_top1_close5_open_t_hit8': m('baseline_top1_hit_close5_open_t_8'),
        'baseline_top1_close5_open_t_hit10': m('baseline_top1_hit_close5_open_t_10'),
        'v15_4_reward_top1_avg_true_max_up_5': m('v15_4_reward_top1_true_max_up_5'),
        'v15_4_reward_top1_hit8_rate_5': m('v15_4_reward_top1_hit8_5'),
        'v15_4_reward_top1_hit10_rate_5': m('v15_4_reward_top1_hit10_5'),
        'v15_4_reward_top1_close5_open_t_hit8': m('v15_4_reward_top1_hit_close5_open_t_8'),
        'v15_4_reward_top1_close5_open_t_hit10': m('v15_4_reward_top1_hit_close5_open_t_10'),
        'v15_4A_top1_avg_true_max_up_5': m('v15_4A_top1_true_max_up_5'),
        'v15_4A_top1_hit8_rate_5': m('v15_4A_top1_hit8_5'),
        'v15_4A_top1_hit10_rate_5': m('v15_4A_top1_hit10_5'),
        'v15_4A_top1_close5_open_t_hit8': m('v15_4A_top1_hit_close5_open_t_8'),
        'v15_4A_top1_close5_open_t_hit10': m('v15_4A_top1_hit_close5_open_t_10'),
        'same_pick_rate_v154': m('same_pick_rate_v154'),
        'same_pick_rate_v154A': m('same_pick_rate_v154A'),
        'v154_vs_v154A_same_pick_rate': m('v154_vs_v154A_same_pick_rate'),
        'sample_days': int(len(daily_df)),
    }
    return pd.DataFrame([s])

def _build_top10_rank_stats_v154a(top10: pd.DataFrame) -> pd.DataFrame:
    if top10 is None or top10.empty:
        return pd.DataFrame()
    rank_df = top10.groupby('v154a_rank', as_index=False).agg(
        count=('symbol', 'count'),
        avg_true_max_up_3=('true_max_up_3', 'mean'),
        avg_true_max_up_5=('true_max_up_5', 'mean'),
        avg_true_max_up_10=('true_max_up_10', 'mean'),
        hit8_rate_5=('hit_8_5', 'mean'),
        hit10_rate_5=('hit_10_5', 'mean'),
        close5_open_t_hit8=('hit_close5_open_t_8', 'mean'),
        close5_open_t_hit10=('hit_close5_open_t_10', 'mean'),
        avg_post_day1_ret=('post_day1_ret', 'mean'),
        avg_post_day2_ret=('post_day2_ret', 'mean'),
        avg_post_day3_ret=('post_day3_ret', 'mean'),
    )
    return rank_df.sort_values('v154a_rank').reset_index(drop=True)

def run_v154a_outputs(fold_dir: Path, valid_pred: pd.DataFrame, test_pred: pd.DataFrame, raw_df: pd.DataFrame, cfg, horizon: int = 5):
    eval_h = tuple(sorted(set([3, int(horizon), 10])))
    log_time('V15.4A 评估开始 | 合并回测字段')
    test_merged = prepare_prediction_table_for_backtest(test_pred, raw_df, horizon=horizon)
    if len(test_merged):
        test_merged = _add_v15_future_stats(test_merged, raw_df, horizons=eval_h, early_days=(1,2,3))
        test_merged = _add_pretrade_features(test_merged, raw_df)
        test_merged = build_close5_prob_metrics(test_merged)
        test_merged['baseline_score'] = pd.to_numeric(test_merged['pred_ret'], errors='coerce')
        test_merged = _ensure_daily_pred_rank(test_merged)
        benchmark_df = load_benchmark_daily_from_duckdb(cfg)
        test_merged = attach_benchmark_features(test_merged, benchmark_df)
        test_merged = build_independent_market_features(test_merged, cfg)
        test_merged = build_v15_4_reward_addon(test_merged, cfg)
        del benchmark_df
        cleanup_memory()

    topn = int(getattr(cfg, 'v154a_filter_topn', 10))
    top10 = test_merged[test_merged['pred_rank'] <= topn].copy() if len(test_merged) else pd.DataFrame()

    daily_rows=[]; top_candidates=[]; role_map={}; hist_diag_rows=[]
    if len(top10):
        iterator = top10.groupby('date', sort=True)
        try:
            from tqdm import tqdm
            if getattr(cfg,'visible_tqdm',True):
                iterator = tqdm(list(iterator), desc='V15.4A baseline vs v154 vs v154A', leave=False)
        except Exception:
            pass
        for dt, g in iterator:
            g = g.sort_values(['pred_rank','baseline_score'], ascending=[True,False]).copy()
            g = build_v15_4_reward_score_within_topn(g, cfg)
            g = _build_long_history_features_from_duckdb(g, cfg, lookback_days=180)
            hist_diag = {
                'date': str(pd.Timestamp(dt).date()),
                'rows': int(len(g)),
                'history_source': 'duckdb_180d_mainboard_fixed',
                'entry_date_nat_count': int(pd.to_datetime(g.get('entry_date'), errors='coerce').isna().sum()) if 'entry_date' in g.columns else 0,
                'nonnull_hist_runup_60d_close': int(pd.to_numeric(g.get('hist_runup_60d_close'), errors='coerce').notna().sum()) if 'hist_runup_60d_close' in g.columns else 0,
                'nonnull_hist_runup_120d_close': int(pd.to_numeric(g.get('hist_runup_120d_close'), errors='coerce').notna().sum()) if 'hist_runup_120d_close' in g.columns else 0,
                'nonnull_hist_180d_pos': int(pd.to_numeric(g.get('hist_180d_pos'), errors='coerce').notna().sum()) if 'hist_180d_pos' in g.columns else 0,
                'nonnull_dd_from_60d_high': int(pd.to_numeric(g.get('dd_from_60d_high'), errors='coerce').notna().sum()) if 'dd_from_60d_high' in g.columns else 0,
                'nonnull_hist_days_since_high': int(pd.to_numeric(g.get('hist_days_since_high'), errors='coerce').notna().sum()) if 'hist_days_since_high' in g.columns else 0,
            }
            g = apply_v154a_close_quality_filter(g, cfg)

            baseline_pick = g.sort_values(['baseline_score','pred_rank'], ascending=[False,True]).iloc[0]
            v154_pick = g.sort_values(['reward_score','pred_rank'], ascending=[False,True]).iloc[0]
            v154a_pick = g.sort_values(['v154a_final_score','pred_rank'], ascending=[False,True]).iloc[0]
            best_pick = g.sort_values(['true_max_up_5','pred_rank'], ascending=[False,True]).iloc[0]

            row = {
                'date': str(pd.Timestamp(dt).date()),
                'pool_size': int(len(g)),
                'same_pick_rate_v154': int(str(baseline_pick.get('symbol')) == str(v154_pick.get('symbol'))),
                'same_pick_rate_v154A': int(str(baseline_pick.get('symbol')) == str(v154a_pick.get('symbol'))),
                'v154_vs_v154A_same_pick_rate': int(str(v154_pick.get('symbol')) == str(v154a_pick.get('symbol'))),
            }
            row.update(_extract_pick_metrics(baseline_pick,'baseline_top1'))
            row.update(_extract_pick_metrics(v154_pick,'v15_4_reward_top1'))
            row.update(_extract_pick_metrics_v154a(v154a_pick,'v15_4A_top1'))
            row.update(_extract_pick_metrics(best_pick,'best_top_pool'))
            daily_rows.append(row)
            hist_diag_rows.append(hist_diag)

            role_map[(str(pd.Timestamp(dt).date()), str(baseline_pick['symbol']))] = 'baseline_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(v154_pick['symbol']))] = 'v15_4_reward_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(v154a_pick['symbol']))] = 'v15_4A_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(best_pick['symbol']))] = 'best_top_pool'

            top_candidates.append(g.copy())
        cleanup_memory()

    daily_df = pd.DataFrame(daily_rows)
    top_candidates_df = pd.concat(top_candidates, ignore_index=True) if top_candidates else pd.DataFrame()
    rank_df = _build_top10_rank_stats_v154a(top_candidates_df)
    summary_df = summarize_v154a_daily_compare(daily_df)
    hist_diag_df = pd.DataFrame(hist_diag_rows)
    kline_df = _build_kline_windows(top_candidates_df, raw_df, pre_days=int(getattr(cfg,'kline_pre_days',10)), post_days=int(getattr(cfg,'kline_post_days',10)), horizon=max(eval_h), role_map=role_map)

    test_merged.to_csv(fold_dir/'test_pred_v15_4A_full.csv', index=False, encoding='utf-8-sig')
    top10.to_csv(fold_dir/'top_candidates_v15_4A_basepool.csv', index=False, encoding='utf-8-sig')
    top_candidates_df.to_csv(fold_dir/'top_candidates_v15_4A_compare.csv', index=False, encoding='utf-8-sig')
    daily_df.to_csv(fold_dir/'top1_baseline_vs_v15_4_v15_4A_daily.csv', index=False, encoding='utf-8-sig')
    rank_df.to_csv(fold_dir/'top10_rank_stats_v15_4A.csv', index=False, encoding='utf-8-sig')
    kline_df.to_csv(fold_dir/'candidate_kline_windows_v15_4A.csv', index=False, encoding='utf-8-sig')
    summary_df.to_csv(fold_dir/'v15_4A_eval_summary.csv', index=False, encoding='utf-8-sig')
    hist_diag_df.to_csv(fold_dir/'v15_4A_hist_feature_diag.csv', index=False, encoding='utf-8-sig')
    (fold_dir/'v15_4A_hist_feature_diag.json').write_text(hist_diag_df.to_json(orient='records', force_ascii=False, indent=2), encoding='utf-8')
    return {'summary': summary_df}

def run_one_fold_v154a(data: pd.DataFrame, feature_cols: List[str], cfg, fold_spec: Dict, fold_dir: Path, horizon: int):
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    train_df = data[data['date'].isin(fold_spec['train_dates'])].copy().sort_values(['symbol','date']).reset_index(drop=True)
    valid_df = v14._build_warmup_slice(data, fold_spec['valid_dates'], all_dates, cfg.warmup_days) if hasattr(v14,'_build_warmup_slice') else data[data['date'].isin(fold_spec['valid_dates'])].copy()
    test_df = v14._build_warmup_slice(data, fold_spec['test_dates'], all_dates, cfg.warmup_days) if hasattr(v14,'_build_warmup_slice') else data[data['date'].isin(fold_spec['test_dates'])].copy()
    fold_dir.mkdir(parents=True, exist_ok=True)
    try:
        log_time(f"fold={fold_spec['fold']} | 开始训练与预测")
        fit_res = v14.fit_and_predict_one_fold_ashare_v14(
            train_df=train_df, valid_df=valid_df, test_df=test_df,
            feature_cols=feature_cols, cfg=cfg,
            valid_trade_dates=fold_spec['valid_dates'],
            test_trade_dates=fold_spec['test_dates'],
        )
        fit_res['test_pred'].to_csv(fold_dir/'test_pred.csv', index=False, encoding='utf-8-sig')
        fit_res['epoch_records'].to_csv(fold_dir/'epoch_records.csv', index=False, encoding='utf-8-sig')
        res = run_v154a_outputs(fold_dir=fold_dir, valid_pred=fit_res['valid_pred'], test_pred=fit_res['test_pred'], raw_df=test_df, cfg=cfg, horizon=int(horizon))
        meta = {
            'fold': fold_spec['fold'],
            'fold_spec': {k: fold_spec[k] for k in ['train_start','train_end','valid_start','valid_end','test_start','test_end']},
            'n_train_samples': fit_res['n_train_samples'],
            'n_valid_samples': fit_res['n_valid_samples'],
            'n_test_samples': fit_res['n_test_samples'],
            'study': 'V15.4A reward top10 close-quality filter',
        }
        (fold_dir/'fold_meta.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        (fold_dir/'done.json').write_text(json.dumps({'ok': True, 'study': 'V15.4A reward top10 close-quality filter'}, ensure_ascii=False, indent=2), encoding='utf-8')
        s = res['summary'].iloc[0].to_dict() if len(res['summary']) else {}
        row = {'fold': fold_spec['fold'], 'horizon': int(horizon), **meta['fold_spec'], 'candidate_mode':'v15_4A_close_quality_filter'}
        row.update(s)
        return row
    finally:
        cleanup_memory()
