@echo off
python run_v19_s3_focus8.py
