@echo off
python run_v17_close_quality_recent5fold.py
pause
