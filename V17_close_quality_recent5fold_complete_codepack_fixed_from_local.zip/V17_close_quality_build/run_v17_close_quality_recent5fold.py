from __future__ import annotations

import copy
import json
from pathlib import Path

import pandas as pd
import yaml

import ashare_v14_fold as v14
from experiment_common_v14_fold import build_rolling_fold_specs, log_time, cleanup_memory
from v17_close_quality_core import run_one_fold_v17

CORE_DONE_FILES = ['done.json','fold_meta.json','v17_eval_summary.csv','top10_rank_stats_v17.csv','top1_baseline_vs_v15_4_v17_daily.csv','candidate_kline_windows_v17.csv','test_pred_v17_top10_seed.csv','top_candidates_v17_compare.csv','top1_with_benchmark_context.csv','heavy_loss_with_benchmark_context.csv','v17_scope_diag.json']

def load_yaml(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def is_fold_complete(fold_dir: Path) -> bool:
    return fold_dir.exists() and all((fold_dir / name).exists() for name in CORE_DONE_FILES)

def load_fold_row(fold_dir: Path, cycle_name: str, horizon: int) -> dict | None:
    meta_fp = fold_dir/'fold_meta.json'; eval_fp = fold_dir/'v17_eval_summary.csv'
    if not meta_fp.exists() or not eval_fp.exists():
        return None
    meta = json.loads(meta_fp.read_text(encoding='utf-8'))
    eval_df = pd.read_csv(eval_fp)
    if eval_df.empty: return None
    s = eval_df.iloc[0].to_dict(); spec = meta.get('fold_spec', {})
    row = {'fold': int(meta.get('fold', int(fold_dir.name.split('_')[-1]))),'horizon': int(horizon),'cycle_name': cycle_name,'train_start': spec.get('train_start'),'train_end': spec.get('train_end'),'valid_start': spec.get('valid_start'),'valid_end': spec.get('valid_end'),'test_start': spec.get('test_start'),'test_end': spec.get('test_end'),'candidate_mode': 'v17_close_quality_from_v154_top10'}
    for k in ['baseline_top1_avg_true_max_up_5','baseline_top1_hit8_rate_5','baseline_top1_hit10_rate_5','baseline_top1_close5_open_t_hit8','baseline_top1_close5_open_t_hit10','v15_4_reward_top1_avg_true_max_up_5','v15_4_reward_top1_hit8_rate_5','v15_4_reward_top1_hit10_rate_5','v15_4_reward_top1_close5_open_t_hit8','v15_4_reward_top1_close5_open_t_hit10','v17_reward_top1_avg_true_max_up_5','v17_reward_top1_hit8_rate_5','v17_reward_top1_hit10_rate_5','v17_reward_top1_close5_open_t_hit8','v17_reward_top1_close5_open_t_hit10','same_pick_rate_v154','same_pick_rate_v17','v154_vs_v17_same_pick_rate','v15_4_reward_better_maxup5_rate','v17_reward_better_maxup5_rate','sample_days']:
        row[k] = s.get(k)
    return row

def write_cycle_summary(exp_dir: Path, rows: list[dict], build_large_files: bool = False) -> None:
    summary_df = pd.DataFrame(rows).sort_values(['horizon','cycle_name','fold']).reset_index(drop=True) if rows else pd.DataFrame()
    summary_df.to_csv(exp_dir/'all_fold_results.csv', index=False, encoding='utf-8-sig')
    if len(summary_df):
        agg_map = {
            'avg_baseline_top1_maxup5': 'baseline_top1_avg_true_max_up_5',
            'avg_baseline_top1_hit8': 'baseline_top1_hit8_rate_5',
            'avg_baseline_top1_hit10': 'baseline_top1_hit10_rate_5',
            'avg_baseline_close5_open_t_hit8': 'baseline_top1_close5_open_t_hit8',
            'avg_baseline_close5_open_t_hit10': 'baseline_top1_close5_open_t_hit10',
            'avg_v15_4_reward_top1_maxup5': 'v15_4_reward_top1_avg_true_max_up_5',
            'avg_v15_4_reward_top1_hit8': 'v15_4_reward_top1_hit8_rate_5',
            'avg_v15_4_reward_top1_hit10': 'v15_4_reward_top1_hit10_rate_5',
            'avg_v15_4_reward_close5_open_t_hit8': 'v15_4_reward_top1_close5_open_t_hit8',
            'avg_v15_4_reward_close5_open_t_hit10': 'v15_4_reward_top1_close5_open_t_hit10',
            'avg_v17_reward_top1_maxup5': 'v17_reward_top1_avg_true_max_up_5',
            'avg_v17_reward_top1_hit8': 'v17_reward_top1_hit8_rate_5',
            'avg_v17_reward_top1_hit10': 'v17_reward_top1_hit10_rate_5',
            'avg_v17_reward_close5_open_t_hit8': 'v17_reward_top1_close5_open_t_hit8',
            'avg_v17_reward_close5_open_t_hit10': 'v17_reward_top1_close5_open_t_hit10',
            'avg_same_pick_rate_v154': 'same_pick_rate_v154',
            'avg_same_pick_rate_v17': 'same_pick_rate_v17',
            'avg_v154_vs_v17_same_pick_rate': 'v154_vs_v17_same_pick_rate',
            'avg_sample_days': 'sample_days',
        }
        use_map = {k:v for k,v in agg_map.items() if v in summary_df.columns}
        agg = summary_df.groupby(['cycle_name','horizon'], as_index=False).agg(**{k:(v,'mean') for k,v in use_map.items()}, folds=('fold','count'))
        agg['delta_v17_vs_v154_close5_open_t_hit8'] = agg.get('avg_v17_reward_close5_open_t_hit8',0) - agg.get('avg_v15_4_reward_close5_open_t_hit8',0)
        agg['delta_v17_vs_v154_close5_open_t_hit10'] = agg.get('avg_v17_reward_close5_open_t_hit10',0) - agg.get('avg_v15_4_reward_close5_open_t_hit10',0)
        agg['delta_v17_vs_v154_hit8_rate_5'] = agg.get('avg_v17_reward_top1_hit8',0) - agg.get('avg_v15_4_reward_top1_hit8',0)
        agg['delta_v17_vs_v154_hit10_rate_5'] = agg.get('avg_v17_reward_top1_hit10',0) - agg.get('avg_v15_4_reward_top1_hit10',0)
    else:
        agg = pd.DataFrame()
    agg.to_csv(exp_dir/'v17_cycle_horizon_summary.csv', index=False, encoding='utf-8-sig')
    (exp_dir/'overview.json').write_text(json.dumps(agg.to_dict(orient='records'), ensure_ascii=False, indent=2), encoding='utf-8')

    daily_rows=[]; cand_rows=[]; rank_rows=[]; bench_rows=[]; heavy_rows=[]; kline_rows=[]
    for hz_dir in sorted(exp_dir.glob('horizon_*')):
        for cycle_dir in sorted(hz_dir.iterdir()):
            if not cycle_dir.is_dir(): continue
            for fold_dir in sorted(cycle_dir.glob('fold_*')):
                fold_no = int(fold_dir.name.split('_')[-1])
                for name, bucket in [('top1_baseline_vs_v15_4_v17_daily.csv', daily_rows),('top_candidates_v17_compare.csv', cand_rows),('top10_rank_stats_v17.csv', rank_rows),('top1_with_benchmark_context.csv', bench_rows),('heavy_loss_with_benchmark_context.csv', heavy_rows)]:
                    fp = fold_dir/name
                    if fp.exists():
                        df = pd.read_csv(fp); df.insert(0,'fold',fold_no); df.insert(0,'cycle_name',cycle_dir.name); df.insert(0,'horizon',int(hz_dir.name.split('_')[-1])); bucket.append(df)
                if build_large_files:
                    fp = fold_dir/'candidate_kline_windows_v17.csv'
                    if fp.exists():
                        df = pd.read_csv(fp); df.insert(0,'fold',fold_no); df.insert(0,'cycle_name',cycle_dir.name); df.insert(0,'horizon',int(hz_dir.name.split('_')[-1])); kline_rows.append(df)
    if daily_rows: pd.concat(daily_rows, ignore_index=True).to_csv(exp_dir/'top1_baseline_vs_v15_4_v17_daily_all.csv', index=False, encoding='utf-8-sig')
    if cand_rows: pd.concat(cand_rows, ignore_index=True).to_csv(exp_dir/'top_candidates_v17_compare_all.csv', index=False, encoding='utf-8-sig')
    if rank_rows: pd.concat(rank_rows, ignore_index=True).to_csv(exp_dir/'top10_rank_stats_v17_all.csv', index=False, encoding='utf-8-sig')
    if bench_rows: pd.concat(bench_rows, ignore_index=True).to_csv(exp_dir/'top1_with_benchmark_context_all.csv', index=False, encoding='utf-8-sig')
    if heavy_rows: pd.concat(heavy_rows, ignore_index=True).to_csv(exp_dir/'heavy_loss_with_benchmark_context_all.csv', index=False, encoding='utf-8-sig')
    if build_large_files and kline_rows: pd.concat(kline_rows, ignore_index=True).to_csv(exp_dir/'candidate_kline_windows_v17_all.csv', index=False, encoding='utf-8-sig')
    cleanup_memory()

def main() -> None:
    yaml_path = 'conf/ashare_v17_close_quality_recent5fold.yaml'
    raw_cfg = load_yaml(yaml_path)
    cfg = v14.load_config_from_yaml(yaml_path)
    cfg = v14.configure_torch_runtime(cfg)
    cfg.reward_weights = raw_cfg.get('reward_weights', {})
    cfg.reward_rerank_topn = int(raw_cfg.get('reward_rerank_topn', 10))
    cfg.benchmark_symbol = str(raw_cfg.get('benchmark_symbol', 'sh000001'))
    cfg.benchmark_name = str(raw_cfg.get('benchmark_name', '上证指数'))
    cfg.index_down_th = float(raw_cfg.get('index_down_th', -0.005))
    cfg.stock_up_th = float(raw_cfg.get('stock_up_th', 0.01))
    cfg.relative_strength_cap_1d = float(raw_cfg.get('relative_strength_cap_1d', 0.05))
    cfg.relative_strength_cap_5d = float(raw_cfg.get('relative_strength_cap_5d', 0.10))
    cfg.enable_close5_prob_metrics = bool(raw_cfg.get('enable_close5_prob_metrics', True))
    cfg.maxup_eval_horizons = raw_cfg.get('maxup_eval_horizons', [3, 5, 10])
    cfg.kline_pre_days = int(raw_cfg.get('kline_pre_days', 10))
    cfg.kline_post_days = int(raw_cfg.get('kline_post_days', 10))
    cfg.auto_drop_benchmark_from_training = bool(raw_cfg.get('auto_drop_benchmark_from_training', True))
    v14.seed_everything(cfg.seed)

    cycle_presets = raw_cfg.get('cycle_presets', [])
    experiment_horizons = raw_cfg.get('experiment_horizons', list(getattr(cfg, 'horizon_candidates', [5]))) or [5]
    num_folds = int(raw_cfg.get('num_folds', 10))
    out_root = Path(cfg.out_dir) / 'V17_close_quality_recent5fold_experiments'
    out_root.mkdir(parents=True, exist_ok=True)
    rows=[]
    for horizon in experiment_horizons:
        cfg_h = copy.deepcopy(cfg)
        cfg_h.horizon_candidates=(int(horizon),)
        log_time(f'V17 | 准备数据 | horizon={horizon}')
        data, feature_cols, prep_meta = v14.prepare_full_dataset(cfg_h)
        if getattr(cfg_h, 'auto_drop_benchmark_from_training', True):
            bench = str(getattr(cfg_h, 'benchmark_symbol', 'sh000001')).zfill(6)
            before = len(data)
            data = data[data['symbol'].astype(str).str.zfill(6) != bench].copy()
            log_time(f'V17 | 剔除 benchmark={bench} 训练样本 | rows {before} -> {len(data)}')
        hz_dir = out_root/f'horizon_{int(horizon):02d}'; hz_dir.mkdir(parents=True, exist_ok=True)
        (hz_dir/'prep_meta.json').write_text(json.dumps(prep_meta, ensure_ascii=False, indent=2), encoding='utf-8')

        for preset in cycle_presets:
            cycle_name = str(preset['name'])
            cfg_c = copy.deepcopy(cfg_h)
            cfg_c.train_days = int(preset['train_days']); cfg_c.valid_days = int(preset['valid_days']); cfg_c.test_days = int(preset['test_days']); cfg_c.warmup_days = int(preset['warmup_days'])
            cycle_dir = hz_dir/cycle_name; cycle_dir.mkdir(parents=True, exist_ok=True)
            fold_specs = build_rolling_fold_specs(data=data, cfg=cfg_c, num_folds=num_folds, fold_stride_days=cfg_c.test_days)
            fold_specs = sorted(fold_specs, key=lambda x: int(x.get('fold',0)))[-5:]
            print(f"[recent5] 仅运行最近5个fold: {[int(s.get('fold',0)) for s in fold_specs]}")
            for spec in fold_specs:
                fold_dir = cycle_dir/f"fold_{spec['fold']:02d}"
                if is_fold_complete(fold_dir):
                    print(f"[resume] 跳过已完成 fold={spec['fold']} | {cycle_name} | horizon={horizon}")
                    row = load_fold_row(fold_dir, cycle_name, int(horizon))
                    if row is not None:
                        rows = [r for r in rows if not (r['cycle_name']==cycle_name and r['horizon']==int(horizon) and r['fold']==row['fold'])]
                        rows.append(row)
                    continue
                print('\n' + '='*60)
                print(f"[V17] {cycle_name} | horizon={horizon} | Fold {spec['fold']}")
                print(json.dumps({'train_start': spec['train_start'], 'train_end': spec['train_end'], 'valid_start': spec['valid_start'], 'valid_end': spec['valid_end'], 'test_start': spec['test_start'], 'test_end': spec['test_end']}, ensure_ascii=False, indent=2))
                print('='*60)
                row = run_one_fold_v17(data=data, feature_cols=feature_cols, cfg=cfg_c, fold_spec=spec, fold_dir=fold_dir, horizon=int(horizon))
                row['cycle_name']=cycle_name; row['train_days']=int(cfg_c.train_days); row['valid_days']=int(cfg_c.valid_days); row['test_days']=int(cfg_c.test_days); row['warmup_days']=int(cfg_c.warmup_days)
                rows = [r for r in rows if not (r['cycle_name']==cycle_name and r['horizon']==int(horizon) and r['fold']==row['fold'])]
                rows.append(row)
                write_cycle_summary(out_root, rows, build_large_files=False)
                cleanup_memory()
            cleanup_memory()
        cleanup_memory()

    final_rows=[]
    for hz_dir in sorted(out_root.glob('horizon_*')):
        h = int(hz_dir.name.split('_')[-1])
        for cycle_dir in sorted(hz_dir.iterdir()):
            if not cycle_dir.is_dir(): continue
            cycle_name = cycle_dir.name
            for fold_dir in sorted(cycle_dir.glob('fold_*')):
                row = load_fold_row(fold_dir, cycle_name, h)
                if row is not None: final_rows.append(row)
    write_cycle_summary(out_root, final_rows, build_large_files=True)
    log_time(f'V17 close quality recent5fold 完成 | 结果目录: {out_root}')

if __name__ == '__main__':
    main()
