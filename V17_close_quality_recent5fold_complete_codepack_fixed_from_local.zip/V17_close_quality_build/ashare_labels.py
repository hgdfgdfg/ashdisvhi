from __future__ import annotations

from typing import Iterable, Tuple
import numpy as np
import pandas as pd

DEFAULT_HORIZONS: Tuple[int, ...] = (5,)
CANDIDATE_MODES: Tuple[str, ...] = ("original", "startday_clean", "pro_clean")
HIT_THRESHOLDS: Tuple[float, ...] = (0.05, 0.08, 0.10)


def _common_candidate_features(df: pd.DataFrame, breakout_lookback: int = 20) -> pd.DataFrame:
    out = df.sort_values(["symbol", "date"]).copy()
    grp = out.groupby("symbol", sort=False)
    prev_high = grp["high"].transform(lambda s: s.shift(1).rolling(breakout_lookback, min_periods=max(5, breakout_lookback // 2)).max())
    prev_close_high = grp["close"].transform(lambda s: s.shift(1).rolling(breakout_lookback, min_periods=max(5, breakout_lookback // 2)).max())
    vol_ma5 = grp["volume"].transform(lambda s: s.shift(1).rolling(5, min_periods=3).mean())
    close_ma5 = grp["close"].transform(lambda s: s.shift(1).rolling(5, min_periods=3).mean())
    close_ma10 = grp["close"].transform(lambda s: s.shift(1).rolling(10, min_periods=5).mean())
    close_ma20 = grp["close"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).mean())
    ret3 = grp["close"].transform(lambda s: s.pct_change(3))
    amp_mean10 = grp.apply(lambda g: ((g["high"] - g["low"]) / g["close"].replace(0, np.nan)).shift(1).rolling(10, min_periods=5).mean()).reset_index(level=0, drop=True)
    prior_upper_shadow = grp.apply(lambda g: ((g["high"].shift(1) - g[["open", "close"]].shift(1).max(axis=1)) / (g["high"].shift(1) - g["low"].shift(1)).replace(0, np.nan)).fillna(0.0)).reset_index(level=0, drop=True)
    signal_ret = out["close"] / out["open"].replace(0, np.nan) - 1.0
    range_width = (out["high"] - out["low"]).replace(0, np.nan)
    close_strength = ((out["close"] - out["low"]) / range_width).clip(0.0, 1.0)
    breakout_margin = out["close"] / prev_high.replace(0, np.nan) - 1.0
    volume_ratio = out["volume"] / vol_ma5.replace(0, np.nan)
    trend_ok_orig = (out["close"] >= close_ma10) & (close_ma10 >= close_ma20)
    trend_ok_fast = (out["close"] >= close_ma5.fillna(-np.inf)) & (close_ma5.fillna(-np.inf) >= close_ma10.fillna(-np.inf)) & (close_ma10.fillna(-np.inf) >= close_ma20.fillna(-np.inf))
    compression_ok = ((out["high"] - out["low"]) / out["close"].replace(0, np.nan) <= amp_mean10.fillna(np.inf) * 1.35)
    near_recent_high = (out["close"] >= prev_close_high.fillna(-np.inf) * 0.985)
    tradable_bar = (out["high"] > out["low"]) & out["open"].notna() & out["close"].notna()
    out["signal_ret_1d"] = signal_ret.astype(np.float32)
    out["breakout_margin"] = breakout_margin.replace([np.inf, -np.inf], np.nan).fillna(-1.0).astype(np.float32)
    out["volume_ratio_5"] = volume_ratio.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(np.float32)
    out["close_strength"] = close_strength.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(np.float32)
    out["ret3"] = ret3.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(np.float32)
    out["prior_upper_shadow"] = prior_upper_shadow.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(np.float32)
    out["prev_high_lookback"] = prev_high.astype(np.float32)
    out["prev_close_high_lookback"] = prev_close_high.astype(np.float32)
    out["_signal_ret"] = signal_ret
    out["_volume_ratio"] = volume_ratio
    out["_close_strength"] = close_strength
    out["_trend_ok_orig"] = trend_ok_orig.fillna(False)
    out["_trend_ok_fast"] = trend_ok_fast.fillna(False)
    out["_compression_ok"] = compression_ok.fillna(True)
    out["_near_recent_high"] = near_recent_high.fillna(False)
    out["_tradable_bar"] = tradable_bar.fillna(False)
    return out


def _compute_breakout_candidate_flags(df: pd.DataFrame, breakout_lookback: int = 20, min_volume_ratio: float = 1.2, max_signal_return: float = 0.095, close_strength_min: float = 0.55, min_breakout_buffer: float = -0.002, candidate_mode: str = "original") -> pd.DataFrame:
    out = _common_candidate_features(df, breakout_lookback=breakout_lookback)
    signal_ret = out["_signal_ret"]
    volume_ratio = out["_volume_ratio"]
    close_strength = out["_close_strength"]
    prev_high = out["prev_high_lookback"]
    prev_close_high = out["prev_close_high_lookback"]
    candidate_mode = str(candidate_mode or "original").lower()
    if candidate_mode == "original":
        candidate = (
            prev_high.notna()
            & (out["close"] >= prev_high * (1.0 + min_breakout_buffer))
            & (out["close"] >= prev_close_high.fillna(-np.inf))
            & (volume_ratio >= float(min_volume_ratio))
            & (signal_ret <= float(max_signal_return))
            & (signal_ret >= -0.03)
            & (close_strength >= float(close_strength_min))
            & out["_trend_ok_orig"]
            & out["_compression_ok"]
        )
    elif candidate_mode == "startday_clean":
        candidate = (
            out["_tradable_bar"]
            & (signal_ret >= 0.02) & (signal_ret <= min(float(max_signal_return), 0.06))
            & (close_strength >= max(float(close_strength_min), 0.65))
            & out["_near_recent_high"] & out["_trend_ok_fast"]
            & volume_ratio.fillna(0.0).between(max(float(min_volume_ratio), 1.30), 3.0)
            & (out["ret3"].fillna(0.0) < 0.10)
            & (out["prior_upper_shadow"].fillna(0.0) < 0.45)
        )
    else:
        candidate = (
            out["_tradable_bar"]
            & (signal_ret >= 0.02) & (signal_ret <= min(float(max_signal_return), 0.055))
            & (close_strength >= max(float(close_strength_min), 0.70))
            & out["_near_recent_high"] & out["_trend_ok_fast"]
            & volume_ratio.fillna(0.0).between(max(float(min_volume_ratio), 1.35), 2.5)
            & (out["ret3"].fillna(0.0) < 0.08)
            & (out["prior_upper_shadow"].fillna(0.0) < 0.35)
            & (out["breakout_margin"].fillna(-1.0) > -0.003)
        )
    out["breakout_candidate"] = candidate.astype(np.int64)
    return out.drop(columns=[c for c in out.columns if c.startswith("_")])


def build_labels_for_all_stocks(df_feat: pd.DataFrame, cls_pos_threshold: float = 0.0, horizons: Iterable[int] = DEFAULT_HORIZONS, breakout_lookback: int = 20, min_volume_ratio: float = 1.2, max_signal_return: float = 0.095, close_strength_min: float = 0.55, min_breakout_buffer: float = -0.002, candidate_mode: str = "original") -> pd.DataFrame:
    df = df_feat.sort_values(["symbol", "date"]).copy()
    horizons = tuple(int(h) for h in horizons)
    grp = df.groupby("symbol", sort=False)
    df = _compute_breakout_candidate_flags(df, breakout_lookback=breakout_lookback, min_volume_ratio=min_volume_ratio, max_signal_return=max_signal_return, close_strength_min=close_strength_min, min_breakout_buffer=min_breakout_buffer, candidate_mode=candidate_mode)
    for h in horizons:
        entry_open = grp["open"].shift(-1)
        future_max_high = pd.concat([grp["high"].shift(-i) for i in range(1, h + 1)], axis=1).max(axis=1)
        future_min_low = pd.concat([grp["low"].shift(-i) for i in range(1, h + 1)], axis=1).min(axis=1)
        future_exit_open = grp["open"].shift(-(1 + h))
        future_close_h = grp["close"].shift(-h)

        df[f"label_ret_oo_{h}"] = future_exit_open / entry_open - 1.0
        df[f"label_ret_close_open_{h}"] = future_close_h / entry_open - 1.0
        df[f"label_max_up_{h}"] = future_max_high / entry_open - 1.0
        df[f"label_max_down_{h}"] = future_min_low / entry_open - 1.0
        df[f"label_post_day1_ret_{h}"] = grp["open"].shift(-2) / entry_open - 1.0

        df[f"label_cls_oo_{h}"] = (df[f"label_ret_oo_{h}"] > cls_pos_threshold).astype(np.int64)
        for th in HIT_THRESHOLDS:
            key = str(int(round(th * 100)))
            df[f"label_hit_{key}_{h}"] = (df[f"label_max_up_{h}"] >= th).astype(np.int64)
            df[f"label_hit_close_{key}_{h}"] = (df[f"label_ret_close_open_{h}"] >= th).astype(np.int64)

        df[f"label_close_quality_strong_{h}"] = (
            (df[f"label_ret_close_open_{h}"] >= 0.08)
            & (df[f"label_max_down_{h}"] > -0.08)
            & (df[f"label_post_day1_ret_{h}"] > -0.04)
            & (df[f"label_max_up_{h}"] >= 0.10)
        ).astype(np.int64)

        df[f"label_close_failure_bad_{h}"] = (
            (df[f"label_ret_close_open_{h}"] <= -0.08)
            | (df[f"label_post_day1_ret_{h}"] <= -0.06)
            | (df[f"label_max_down_{h}"] <= -0.15)
        ).astype(np.int64)
    return df


def finalize_training_labels(df: pd.DataFrame, feature_cols: list[str], min_list_days: int = 60, default_horizon: int = 5, breakout_success_threshold: float = 0.08, breakout_candidate_weight: float = 2.0, breakout_success_weight: float = 3.0, positive_sample_weight: float = 0.3, rank_weight_power: float = 1.5, rank_weight_scale: float = 1.0) -> pd.DataFrame:
    out = df.copy()
    if "n_listed_days" not in out.columns:
        out["n_listed_days"] = out.groupby("symbol").cumcount() + 1
    out = out[out["n_listed_days"] >= min_list_days].copy()

    close_ret_col = f"label_ret_close_open_{default_horizon}"
    close_hit8_col = f"label_hit_close_8_{default_horizon}"
    quality_col = f"label_close_quality_strong_{default_horizon}"
    bad_col = f"label_close_failure_bad_{default_horizon}"

    out = out.dropna(subset=[close_ret_col]).copy()
    out = out.dropna(subset=feature_cols).copy()

    out["target_ret"] = pd.to_numeric(out[close_ret_col], errors="coerce").astype(np.float32)
    out["target_rank_pct"] = out.groupby("date")["target_ret"].rank(method="average", pct=True)
    out["target_excess_ret"] = out["target_ret"] - out.groupby("date")["target_ret"].transform("mean")

    out["breakout_candidate"] = pd.to_numeric(out.get("breakout_candidate", 0), errors="coerce").fillna(0).astype(np.int64)
    out["target_cls"] = pd.to_numeric(out.get(quality_col, 0), errors="coerce").fillna(0).astype(np.int64)
    out["target_breakout_success"] = pd.to_numeric(out.get(close_hit8_col, (out["target_ret"] >= 0.08).astype(int)), errors="coerce").fillna(0).astype(np.int64)
    out["_target_bad"] = pd.to_numeric(out.get(bad_col, 0), errors="coerce").fillna(0).astype(np.int64)

    rank_boost = 1.0 + float(rank_weight_scale) * np.power(np.clip(out["target_rank_pct"].astype(np.float32), 0.0, 1.0), float(rank_weight_power))
    candidate_boost = 1.0 + float(breakout_candidate_weight) * out["breakout_candidate"].astype(np.float32)
    success_boost = 1.0 + float(breakout_success_weight) * out["target_breakout_success"].astype(np.float32)
    quality_boost = 1.0 + 0.8 * out["target_cls"].astype(np.float32)
    bad_boost = 1.0 + 0.5 * out["_target_bad"].astype(np.float32)
    pos_boost = 1.0 + float(positive_sample_weight) * (out["target_ret"] > 0.05).astype(np.float32)
    out["sample_weight"] = (rank_boost * candidate_boost * success_boost * quality_boost * bad_boost * pos_boost).astype(np.float32)
    return out.sort_values(["date", "symbol"]).reset_index(drop=True)


def get_label_columns(horizon: int = 5) -> Tuple[str, str]:
    return f"label_ret_close_open_{horizon}", f"label_hit_close_8_{horizon}"
