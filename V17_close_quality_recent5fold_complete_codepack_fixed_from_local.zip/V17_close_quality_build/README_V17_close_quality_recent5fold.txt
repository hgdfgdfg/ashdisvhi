V17_close_quality_recent5fold 完整工程包（按用户本地真实 experiment_common_v14_fold.py 修正版）
================================================================================

特点
----
1. 直接使用用户本地真实 experiment_common_v14_fold.py
2. benchmark 读取 / 独立行情特征链路与本地真实版本对齐
3. V17 标签主线围绕 close5_open_t_hit8/10
4. 对比对象保留 baseline / V15.4 reward / V17
5. 输出 benchmark 对齐表与重亏诊断表

主入口
------
- run_v17_close_quality_recent5fold.py
- run_v17_close_quality_recent5fold.bat

结果目录
--------
runs/V17_close_quality_recent5fold_experiments/

每个 fold 输出
------------
- v17_eval_summary.csv
- top10_rank_stats_v17.csv
- top1_baseline_vs_v15_4_v17_daily.csv
- candidate_kline_windows_v17.csv
- test_pred_v17_top10_seed.csv
- top_candidates_v17_compare.csv
- top1_with_benchmark_context.csv
- heavy_loss_with_benchmark_context.csv
- benchmark_schema_diag.json
- stock_schema_diag.json
- v17_scope_diag.json
- v17_feature_availability.json
- v17_error.json（仅报错时）
