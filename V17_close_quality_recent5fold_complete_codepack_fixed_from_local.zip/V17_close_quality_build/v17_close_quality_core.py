from __future__ import annotations

import json
import traceback
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

import ashare_v14_fold as v14
from ashare_backtest import prepare_prediction_table_for_backtest
from experiment_common_v14_fold import (
    log_time, cleanup_memory, _add_v15_future_stats, _add_pretrade_features,
    build_close5_prob_metrics, _ensure_daily_pred_rank, load_benchmark_daily_from_duckdb,
    attach_benchmark_features, build_independent_market_features, build_v15_4_reward_addon,
    build_v15_4_reward_score_within_topn, _build_kline_windows,
)


def _to_num(s):
    return pd.to_numeric(s, errors='coerce')


def _safe_col(df: pd.DataFrame, name: str, default=0.0) -> pd.Series:
    if name in df.columns:
        return pd.to_numeric(df[name], errors='coerce').fillna(default)
    return pd.Series(default, index=df.index, dtype='float64')


def _clip01_series(x: pd.Series) -> pd.Series:
    return pd.Series(np.clip(pd.to_numeric(x, errors='coerce').fillna(0.0), 0.0, 1.0), index=x.index)


def _band_score4_series(x: pd.Series, low: float, mid_low: float, mid_high: float, high: float) -> pd.Series:
    x = pd.to_numeric(x, errors='coerce')
    out = pd.Series(0.0, index=x.index, dtype=float)
    m1 = (x > low) & (x < mid_low)
    out.loc[m1] = (x.loc[m1] - low) / max(mid_low - low, 1e-8)
    m2 = (x >= mid_low) & (x <= mid_high)
    out.loc[m2] = 1.0
    m3 = (x > mid_high) & (x < high)
    out.loc[m3] = (high - x.loc[m3]) / max(high - mid_high, 1e-8)
    return out.fillna(0.0).clip(lower=0.0, upper=1.0)


def _write_feature_availability(df: pd.DataFrame, fold_dir: Path):
    keys = ['pre_10d_ret','price_pos_120d','vol_ratio_5_20','accel_3_vs_10','days_since_high_60d','excess_ret_1d','excess_ret_5d','reward_score','reward_rank','pred_rank','close','open','high','low']
    out = {}
    for k in keys:
        if k in df.columns:
            s = pd.to_numeric(df[k], errors='coerce')
            out[k] = {'exists': True, 'nonnull_count': int(s.notna().sum()), 'nonnull_ratio': float(s.notna().mean())}
        else:
            out[k] = {'exists': False, 'nonnull_count': 0, 'nonnull_ratio': 0.0}
    (fold_dir/'v17_feature_availability.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')


def build_v17_scores_from_v154_top10(day_df: pd.DataFrame, cfg) -> pd.DataFrame:
    out = day_df.copy()
    out['runup_10'] = _safe_col(out, 'pre_10d_ret', 0.0)
    out['price_pos_120d'] = _safe_col(out, 'price_pos_120d', 0.0)
    out['vol_ratio_5_20'] = _safe_col(out, 'vol_ratio_5_20', 0.0)
    out['accel_3_vs_10'] = _safe_col(out, 'accel_3_vs_10', 0.0)
    out['days_since_high_60d'] = _safe_col(out, 'days_since_high_60d', 999.0)
    out['excess_ret_1d'] = _safe_col(out, 'excess_ret_1d', 0.0)
    out['excess_ret_5d'] = _safe_col(out, 'excess_ret_5d', 0.0)

    runup10_quality = _band_score4_series(out['runup_10'], float(getattr(cfg,'v17_runup10_low',-0.02)), float(getattr(cfg,'v17_runup10_mid_low',0.00)), float(getattr(cfg,'v17_runup10_mid_high',0.08)), float(getattr(cfg,'v17_runup10_high',0.16)))
    pos120_quality = _band_score4_series(out['price_pos_120d'], float(getattr(cfg,'v17_pos120_low',0.84)), float(getattr(cfg,'v17_pos120_mid_low',0.93)), float(getattr(cfg,'v17_pos120_mid_high',0.985)), float(getattr(cfg,'v17_pos120_high',1.01)))
    out['v17_combo_quality_score'] = (runup10_quality * pos120_quality).fillna(0.0)

    excess1_quality = _band_score4_series(out['excess_ret_1d'], float(getattr(cfg,'v17_excess1_low',-0.02)), float(getattr(cfg,'v17_excess1_mid_low',0.02)), float(getattr(cfg,'v17_excess1_mid_high',0.08)), float(getattr(cfg,'v17_excess1_high',0.18)))
    excess5_quality = _band_score4_series(out['excess_ret_5d'], float(getattr(cfg,'v17_excess5_low',-0.08)), float(getattr(cfg,'v17_excess5_mid_low',-0.01)), float(getattr(cfg,'v17_excess5_mid_high',0.08)), float(getattr(cfg,'v17_excess5_high',0.20)))
    out['v17_independent_quality_score'] = (excess1_quality * excess5_quality).fillna(0.0)

    pen_runup10 = _clip01_series((out['runup_10'] - float(getattr(cfg,'v17_pen_runup10_start',0.16))) / max(float(getattr(cfg,'v17_pen_runup10_end',0.30)) - float(getattr(cfg,'v17_pen_runup10_start',0.16)), 1e-8))
    pen_pos120 = _clip01_series((out['price_pos_120d'] - float(getattr(cfg,'v17_pen_pos120_start',0.985))) / max(float(getattr(cfg,'v17_pen_pos120_end',1.00)) - float(getattr(cfg,'v17_pen_pos120_start',0.985)), 1e-8))
    pen_vol = _clip01_series((out['vol_ratio_5_20'] - float(getattr(cfg,'v17_pen_vol_start',1.35))) / max(float(getattr(cfg,'v17_pen_vol_end',1.70)) - float(getattr(cfg,'v17_pen_vol_start',1.35)), 1e-8))
    pen_accel = _clip01_series((out['accel_3_vs_10'] - float(getattr(cfg,'v17_pen_accel_start',0.62))) / max(float(getattr(cfg,'v17_pen_accel_end',1.10)) - float(getattr(cfg,'v17_pen_accel_start',0.62)), 1e-8))
    pen_dsh = _clip01_series((float(getattr(cfg,'v17_pen_dsh_start',2.0)) - out['days_since_high_60d']) / max(float(getattr(cfg,'v17_pen_dsh_start',2.0)) - float(getattr(cfg,'v17_pen_dsh_end',0.0)), 1e-8))

    out['v17_top1_overheat_penalty'] = (
        float(getattr(cfg,'v17_w_pen_runup10',0.30))*pen_runup10
        + float(getattr(cfg,'v17_w_pen_pos120',0.22))*pen_pos120
        + float(getattr(cfg,'v17_w_pen_vol',0.16))*pen_vol
        + float(getattr(cfg,'v17_w_pen_accel',0.20))*pen_accel
        + float(getattr(cfg,'v17_w_pen_dsh',0.12))*pen_dsh
    ).fillna(0.0)

    out['v17_score'] = (
        _to_num(out['reward_score']).fillna(0.0)
        + float(getattr(cfg,'v17_combo_weight',0.018)) * out['v17_combo_quality_score']
        + float(getattr(cfg,'v17_independent_bonus_weight',0.008)) * out['v17_independent_quality_score']
        - float(getattr(cfg,'v17_overheat_penalty_weight',0.020)) * out['v17_top1_overheat_penalty']
    )
    out['v17_rank'] = out['v17_score'].rank(method='first', ascending=False)
    out['v17_selected'] = (out['v17_rank'] == 1).astype(int)
    return out.sort_values(['v17_rank','reward_rank','pred_rank'])


def _extract_pick_metrics(rec: pd.Series, prefix: str) -> dict:
    return {
        f'{prefix}_symbol': rec.get('symbol'),
        f'{prefix}_code': rec.get('code'),
        f'{prefix}_pred_rank': rec.get('pred_rank'),
        f'{prefix}_pred_ret': rec.get('pred_ret'),
        f'{prefix}_pred_prob_pos': rec.get('pred_prob_pos'),
        f'{prefix}_baseline_score': rec.get('baseline_score'),
        f'{prefix}_reward_addon': rec.get('reward_addon'),
        f'{prefix}_reward_score': rec.get('reward_score'),
        f'{prefix}_true_max_up_5': rec.get('true_max_up_5'),
        f'{prefix}_hit8_5': rec.get('hit_8_5'),
        f'{prefix}_hit10_5': rec.get('hit_10_5'),
        f'{prefix}_post_day1_ret': rec.get('post_day1_ret'),
        f'{prefix}_post_day2_ret': rec.get('post_day2_ret'),
        f'{prefix}_post_day3_ret': rec.get('post_day3_ret'),
        f'{prefix}_ret_close5_vs_open_t': rec.get('ret_close5_vs_open_t'),
        f'{prefix}_hit_close5_open_t_8': rec.get('hit_close5_open_t_8'),
        f'{prefix}_hit_close5_open_t_10': rec.get('hit_close5_open_t_10'),
        f'{prefix}_ret_close5_vs_open_t1': rec.get('ret_close5_vs_open_t1'),
        f'{prefix}_hit_close5_open_t1_8': rec.get('hit_close5_open_t1_8'),
        f'{prefix}_hit_close5_open_t1_10': rec.get('hit_close5_open_t1_10'),
        f'{prefix}_excess_ret_1d': rec.get('excess_ret_1d'),
        f'{prefix}_excess_ret_5d': rec.get('excess_ret_5d'),
        f'{prefix}_indep_up_vs_down': rec.get('indep_up_vs_down'),
    }


def _extract_pick_metrics_v17(rec: pd.Series, prefix: str) -> dict:
    d = _extract_pick_metrics(rec, prefix)
    d.update({
        f'{prefix}_runup_10': rec.get('runup_10'),
        f'{prefix}_price_pos_120d': rec.get('price_pos_120d'),
        f'{prefix}_vol_ratio_5_20': rec.get('vol_ratio_5_20'),
        f'{prefix}_accel_3_vs_10': rec.get('accel_3_vs_10'),
        f'{prefix}_days_since_high_60d': rec.get('days_since_high_60d'),
        f'{prefix}_v17_combo_quality_score': rec.get('v17_combo_quality_score'),
        f'{prefix}_v17_independent_quality_score': rec.get('v17_independent_quality_score'),
        f'{prefix}_v17_top1_overheat_penalty': rec.get('v17_top1_overheat_penalty'),
        f'{prefix}_v17_score': rec.get('v17_score'),
    })
    return d


def make_v17_compare_row(dt, baseline_pick: pd.Series, v154_pick: pd.Series, v17_pick: pd.Series, best_pick: pd.Series, bench_row: pd.Series | None) -> dict:
    row = {'date': str(pd.Timestamp(dt).date()), 'same_pick_rate_v154': int(str(baseline_pick.get('symbol')) == str(v154_pick.get('symbol'))), 'same_pick_rate_v17': int(str(baseline_pick.get('symbol')) == str(v17_pick.get('symbol'))), 'v154_vs_v17_same_pick_rate': int(str(v154_pick.get('symbol')) == str(v17_pick.get('symbol')))}
    row.update(_extract_pick_metrics(baseline_pick, 'baseline_top1'))
    row.update(_extract_pick_metrics(v154_pick, 'v15_4_reward_top1'))
    row.update(_extract_pick_metrics_v17(v17_pick, 'v17_top1'))
    row.update(_extract_pick_metrics(best_pick, 'best_top_pool'))
    row['v154_better_maxup5'] = int(_to_num(pd.Series([v154_pick.get('true_max_up_5')])).iloc[0] > _to_num(pd.Series([baseline_pick.get('true_max_up_5')])).iloc[0])
    row['v17_better_maxup5'] = int(_to_num(pd.Series([v17_pick.get('true_max_up_5')])).iloc[0] > _to_num(pd.Series([baseline_pick.get('true_max_up_5')])).iloc[0])
    if bench_row is not None:
        for c in ['benchmark_ret_1d','benchmark_ret_3d','benchmark_ret_5d','benchmark_is_down_day','benchmark_drawdown_3d','benchmark_drawdown_5d']:
            row[c] = bench_row.get(c)
        row['v17_stock_vs_benchmark_spread_1d'] = _to_num(pd.Series([v17_pick.get('excess_ret_1d')])).iloc[0]
        row['v17_stock_vs_benchmark_spread_5d'] = _to_num(pd.Series([v17_pick.get('excess_ret_5d')])).iloc[0]
    return row


def _safe_mean(df: pd.DataFrame, col: str):
    if df is None or df.empty or col not in df.columns:
        return np.nan
    return float(pd.to_numeric(df[col], errors='coerce').mean())


def summarize_v17_daily_compare(daily_df: pd.DataFrame) -> pd.DataFrame:
    if daily_df is None or daily_df.empty:
        return pd.DataFrame()
    def m(c): return _safe_mean(daily_df, c)
    return pd.DataFrame([{
        'baseline_top1_avg_true_max_up_5': m('baseline_top1_true_max_up_5'),
        'baseline_top1_hit8_rate_5': m('baseline_top1_hit8_5'),
        'baseline_top1_hit10_rate_5': m('baseline_top1_hit10_5'),
        'baseline_top1_close5_open_t_hit8': m('baseline_top1_hit_close5_open_t_8'),
        'baseline_top1_close5_open_t_hit10': m('baseline_top1_hit_close5_open_t_10'),
        'v15_4_reward_top1_avg_true_max_up_5': m('v15_4_reward_top1_true_max_up_5'),
        'v15_4_reward_top1_hit8_rate_5': m('v15_4_reward_top1_hit8_5'),
        'v15_4_reward_top1_hit10_rate_5': m('v15_4_reward_top1_hit10_5'),
        'v15_4_reward_top1_close5_open_t_hit8': m('v15_4_reward_top1_hit_close5_open_t_8'),
        'v15_4_reward_top1_close5_open_t_hit10': m('v15_4_reward_top1_hit_close5_open_t_10'),
        'v17_reward_top1_avg_true_max_up_5': m('v17_top1_true_max_up_5'),
        'v17_reward_top1_hit8_rate_5': m('v17_top1_hit8_5'),
        'v17_reward_top1_hit10_rate_5': m('v17_top1_hit10_5'),
        'v17_reward_top1_close5_open_t_hit8': m('v17_top1_hit_close5_open_t_8'),
        'v17_reward_top1_close5_open_t_hit10': m('v17_top1_hit_close5_open_t_10'),
        'same_pick_rate_v154': m('same_pick_rate_v154'),
        'same_pick_rate_v17': m('same_pick_rate_v17'),
        'v154_vs_v17_same_pick_rate': m('v154_vs_v17_same_pick_rate'),
        'v15_4_reward_better_maxup5_rate': m('v154_better_maxup5'),
        'v17_reward_better_maxup5_rate': m('v17_better_maxup5'),
        'sample_days': int(len(daily_df)),
    }])


def run_v17_compare_outputs(fold_dir: Path, valid_pred: pd.DataFrame, test_pred: pd.DataFrame, raw_df: pd.DataFrame, cfg, horizon: int = 5):
    eval_h = tuple(sorted(set([3, int(horizon), 10])))
    log_time('V17 评估开始 | 合并回测字段')
    valid_merged = prepare_prediction_table_for_backtest(valid_pred, raw_df, horizon=horizon)
    test_merged = prepare_prediction_table_for_backtest(test_pred, raw_df, horizon=horizon)
    if len(valid_merged):
        valid_merged = _add_v15_future_stats(valid_merged, raw_df, horizons=eval_h, early_days=(1, 2, 3))
        valid_merged = _add_pretrade_features(valid_merged, raw_df)
        valid_merged = build_close5_prob_metrics(valid_merged)
        valid_merged['baseline_score'] = pd.to_numeric(valid_merged['pred_ret'], errors='coerce')
        valid_merged = _ensure_daily_pred_rank(valid_merged)
    if len(test_merged):
        test_merged = _add_v15_future_stats(test_merged, raw_df, horizons=eval_h, early_days=(1, 2, 3))
        test_merged = _add_pretrade_features(test_merged, raw_df)
        test_merged = build_close5_prob_metrics(test_merged)
        test_merged['baseline_score'] = pd.to_numeric(test_merged['pred_ret'], errors='coerce')
        test_merged = _ensure_daily_pred_rank(test_merged)
        benchmark_df = load_benchmark_daily_from_duckdb(cfg)
        # schema diag from actual loader result
        bench_diag = {'columns': list(benchmark_df.columns), 'rows': int(len(benchmark_df))}
        (fold_dir/'benchmark_schema_diag.json').write_text(json.dumps(bench_diag, ensure_ascii=False, indent=2), encoding='utf-8')
        benchmark_df = benchmark_df.copy()
        benchmark_df['benchmark_is_down_day'] = (pd.to_numeric(benchmark_df['benchmark_ret_1d'], errors='coerce') < 0).astype(int)
        benchmark_df['benchmark_drawdown_3d'] = pd.to_numeric(benchmark_df['benchmark_close'], errors='coerce') / pd.to_numeric(benchmark_df['benchmark_close'], errors='coerce').rolling(3, min_periods=1).max() - 1.0
        benchmark_df['benchmark_drawdown_5d'] = pd.to_numeric(benchmark_df['benchmark_close'], errors='coerce') / pd.to_numeric(benchmark_df['benchmark_close'], errors='coerce').rolling(5, min_periods=1).max() - 1.0
        bench_context = benchmark_df[['date','benchmark_ret_1d','benchmark_ret_3d','benchmark_ret_5d','benchmark_is_down_day','benchmark_drawdown_3d','benchmark_drawdown_5d']].copy()

        test_merged = attach_benchmark_features(test_merged, benchmark_df)
        stock_diag = {'columns': list(test_merged.columns), 'rows': int(len(test_merged))}
        (fold_dir/'stock_schema_diag.json').write_text(json.dumps(stock_diag, ensure_ascii=False, indent=2), encoding='utf-8')
        test_merged = build_independent_market_features(test_merged, cfg)
        test_merged = build_v15_4_reward_addon(test_merged, cfg)
        del benchmark_df
        cleanup_memory()
    else:
        bench_context = pd.DataFrame()

    _write_feature_availability(test_merged, fold_dir)
    topn = int(getattr(cfg, 'reward_rerank_topn', 10))
    top10_seed = test_merged[test_merged['pred_rank'] <= topn].copy() if len(test_merged) else pd.DataFrame()

    daily_rows=[]; top_candidates=[]; role_map={}
    if len(top10_seed):
        iterator = top10_seed.groupby('date', sort=True)
        try:
            from tqdm import tqdm
            if getattr(cfg, 'visible_tqdm', True):
                iterator = tqdm(list(iterator), desc='V17 baseline vs v154 vs v17', leave=False)
        except Exception:
            pass

        for dt, g in iterator:
            g = g.sort_values(['pred_rank', 'baseline_score'], ascending=[True, False]).copy()
            g = build_v15_4_reward_score_within_topn(g, cfg)
            g = build_v17_scores_from_v154_top10(g, cfg)

            baseline_pick = g.sort_values(['baseline_score', 'pred_rank'], ascending=[False, True]).iloc[0]
            v154_pick = g.sort_values(['reward_score', 'pred_rank'], ascending=[False, True]).iloc[0]
            v17_pick = g.sort_values(['v17_score', 'pred_rank'], ascending=[False, True]).iloc[0]
            best_pick = g.sort_values(['true_max_up_5', 'pred_rank'], ascending=[False, True]).iloc[0]

            bench_row = None
            if len(bench_context):
                tmp = bench_context[bench_context['date'] == pd.Timestamp(dt)]
                if len(tmp):
                    bench_row = tmp.iloc[0]

            daily_rows.append(make_v17_compare_row(dt, baseline_pick, v154_pick, v17_pick, best_pick, bench_row))
            role_map[(str(pd.Timestamp(dt).date()), str(baseline_pick['symbol']))] = 'baseline_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(v154_pick['symbol']))] = 'v15_4_reward_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(v17_pick['symbol']))] = 'v17_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(best_pick['symbol']))] = 'best_top_pool'

            top10_v17 = g.sort_values(['v17_score', 'pred_rank'], ascending=[False, True]).head(min(topn, len(g))).copy()
            top10_v17['v17_rank'] = np.arange(1, len(top10_v17) + 1)
            top_candidates.append(top10_v17)
        cleanup_memory()

    daily_df = pd.DataFrame(daily_rows)
    top_candidates_df = pd.concat(top_candidates, ignore_index=True) if top_candidates else pd.DataFrame()
    rank_df = top_candidates_df.groupby('v17_rank', as_index=False).agg(
        count=('symbol', 'count'),
        avg_true_max_up_3=('true_max_up_3', 'mean'),
        avg_true_max_up_5=('true_max_up_5', 'mean'),
        avg_true_max_up_10=('true_max_up_10', 'mean'),
        hit8_rate_5=('hit_8_5', 'mean'),
        hit10_rate_5=('hit_10_5', 'mean'),
        close5_open_t_hit8=('hit_close5_open_t_8', 'mean'),
        close5_open_t_hit10=('hit_close5_open_t_10', 'mean'),
        close5_open_t1_hit8=('hit_close5_open_t1_8', 'mean'),
        close5_open_t1_hit10=('hit_close5_open_t1_10', 'mean'),
        avg_post_day1_ret=('post_day1_ret', 'mean'),
        avg_post_day2_ret=('post_day2_ret', 'mean'),
        avg_post_day3_ret=('post_day3_ret', 'mean'),
    ).rename(columns={'v17_rank':'pred_rank'}) if len(top_candidates_df) else pd.DataFrame()

    summary_df = summarize_v17_daily_compare(daily_df)
    kline_df = _build_kline_windows(top_candidates_df, raw_df, pre_days=int(getattr(cfg, 'kline_pre_days', 10)), post_days=int(getattr(cfg, 'kline_post_days', 10)), horizon=max(eval_h), role_map=role_map)
    top1_bench = daily_df[['date','v17_top1_code','benchmark_ret_1d','benchmark_ret_3d','benchmark_ret_5d','benchmark_is_down_day','benchmark_drawdown_3d','benchmark_drawdown_5d','v17_stock_vs_benchmark_spread_1d','v17_stock_vs_benchmark_spread_5d']].copy() if len(daily_df) else pd.DataFrame()
    heavy_loss = daily_df[(pd.to_numeric(daily_df.get('v17_top1_ret_close5_vs_open_t'), errors='coerce') <= -0.10) | (pd.to_numeric(daily_df.get('v17_top1_post_day1_ret'), errors='coerce') <= -0.07)].copy() if len(daily_df) else pd.DataFrame()

    top10_seed.to_csv(fold_dir/'test_pred_v17_top10_seed.csv', index=False, encoding='utf-8-sig')
    top_candidates_df.to_csv(fold_dir/'top_candidates_v17_compare.csv', index=False, encoding='utf-8-sig')
    daily_df.to_csv(fold_dir/'top1_baseline_vs_v15_4_v17_daily.csv', index=False, encoding='utf-8-sig')
    rank_df.to_csv(fold_dir/'top10_rank_stats_v17.csv', index=False, encoding='utf-8-sig')
    kline_df.to_csv(fold_dir/'candidate_kline_windows_v17.csv', index=False, encoding='utf-8-sig')
    summary_df.to_csv(fold_dir/'v17_eval_summary.csv', index=False, encoding='utf-8-sig')
    top1_bench.to_csv(fold_dir/'top1_with_benchmark_context.csv', index=False, encoding='utf-8-sig')
    heavy_loss.to_csv(fold_dir/'heavy_loss_with_benchmark_context.csv', index=False, encoding='utf-8-sig')

    diag = {'candidate_scope': 'v15_4_reward_top10_compare_candidates', 'label_scheme': 'close_quality_hit8_hit10', 'n_test_merged': int(len(test_merged)), 'n_top10_seed_rows': int(len(top10_seed)), 'n_top_candidates_v17': int(len(top_candidates_df)), 'n_daily_rows': int(len(daily_df))}
    (fold_dir/'v17_scope_diag.json').write_text(json.dumps(diag, ensure_ascii=False, indent=2), encoding='utf-8')
    cleanup_memory()
    return {'summary': summary_df}


def run_one_fold_v17(data: pd.DataFrame, feature_cols: List[str], cfg, fold_spec: Dict, fold_dir: Path, horizon: int):
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    train_df = data[data['date'].isin(fold_spec['train_dates'])].copy().sort_values(['symbol','date']).reset_index(drop=True)
    valid_df = v14._build_warmup_slice(data, fold_spec['valid_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['valid_dates'])].copy()
    test_df = v14._build_warmup_slice(data, fold_spec['test_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['test_dates'])].copy()
    fold_dir.mkdir(parents=True, exist_ok=True)
    try:
        log_time(f"fold={fold_spec['fold']} | 开始训练与预测")
        fit_res = v14.fit_and_predict_one_fold_ashare_v14(train_df=train_df, valid_df=valid_df, test_df=test_df, feature_cols=feature_cols, cfg=cfg, valid_trade_dates=fold_spec['valid_dates'], test_trade_dates=fold_spec['test_dates'])
        fit_res['test_pred'].to_csv(fold_dir/'test_pred.csv', index=False, encoding='utf-8-sig')
        fit_res['epoch_records'].to_csv(fold_dir/'epoch_records.csv', index=False, encoding='utf-8-sig')
        v17_res = run_v17_compare_outputs(fold_dir=fold_dir, valid_pred=fit_res['valid_pred'], test_pred=fit_res['test_pred'], raw_df=test_df, cfg=cfg, horizon=int(horizon))
        meta = {
            'fold': fold_spec['fold'],
            'fold_spec': {'train_start': fold_spec['train_start'], 'train_end': fold_spec['train_end'], 'valid_start': fold_spec['valid_start'], 'valid_end': fold_spec['valid_end'], 'test_start': fold_spec['test_start'], 'test_end': fold_spec['test_end']},
            'n_train_samples': fit_res['n_train_samples'],
            'n_valid_samples': fit_res['n_valid_samples'],
            'n_test_samples': fit_res['n_test_samples'],
            'study': 'V17 close quality from V15.4 reward top10 compare candidates',
        }
        (fold_dir/'fold_meta.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        (fold_dir/'done.json').write_text(json.dumps({'ok':True,'study':'V17 close quality from V15.4 reward top10 compare candidates'}, ensure_ascii=False, indent=2), encoding='utf-8')
        s = v17_res['summary'].iloc[0].to_dict() if len(v17_res['summary']) else {}
        row = {'fold': fold_spec['fold'], 'horizon': int(horizon), 'train_start': fold_spec['train_start'], 'train_end': fold_spec['train_end'], 'valid_start': fold_spec['valid_start'], 'valid_end': fold_spec['valid_end'], 'test_start': fold_spec['test_start'], 'test_end': fold_spec['test_end'], 'candidate_mode': 'v17_close_quality_from_v154_top10'}
        row.update(s)
        return row
    except Exception as e:
        err = {'error_type': type(e).__name__, 'error_message': str(e), 'traceback': traceback.format_exc()}
        (fold_dir/'v17_error.json').write_text(json.dumps(err, ensure_ascii=False, indent=2), encoding='utf-8')
        raise
    finally:
        cleanup_memory()
