V18 使用说明（关键）
1) 请把 DuckDB 数据库放到当前工程目录下的 data/ashare.duckdb
2) 也可以直接修改 conf/ashare_v18_base.yaml 里的 db_path
3) 本入口会自动把相对路径解析到当前 V18 工程目录

V18_S1_matrix16 完整工程包
=========================

定位
----
V18 = 从 V15.4A 主干演进出的矩阵实验平台，不再做 top10 二阶段重排，
而是直接从训练标签与持有周期入手，目标让模型本身更偏向把满足目标收益的票推进 top10。

第一轮矩阵
--------
- Stage: S1 粗选
- 实验数: 16 组
- 周期: W120_20_20 / W180_20_20
- 持有期: H2 / H3 / H4 / H5
- 目标阈值: T16 / T20
  - T16 = future hold return >= 1.6%
  - T20 = future hold return >= 2.0%

配置结构
--------
- conf/ashare_v18_base.yaml
- conf/v18_s1_matrix16.csv
- conf/v18_runner.yaml

入口
----
- run_v18_s1_matrix16.py
- run_v18_s1_matrix16.bat

结果目录
--------
runs/V18_S1_matrix16/

每个实验目录输出
----------------
- summary_by_fold.csv
- summary_overall.csv
- top10_daily_predictions.csv
- top10_hit_stats.csv
- rank_hit_distribution.csv
- config_resolved.yaml
- experiment_done.json

总表输出
--------
- matrix16_leaderboard.csv
- matrix16_best_configs.csv
- matrix16_all_folds.csv
- overview.json

内存与缓存策略
--------------
- 每个 hold_days 先单独 prepare_full_dataset 并缓存到 runs/V18_S1_matrix16/cache/
- 每跑完一个 fold：
  1) 立刻写盘并删除 train/valid/test/fit_res/临时 DataFrame
  2) 显式 gc.collect()
  3) 显式 torch.cuda.empty_cache() / ipc_collect()
- 默认不在内存里长期保留所有实验结果的大表；汇总时按文件回读拼接

说明
----
- 训练目标已改为 future open-to-open hold return (label_ret_oo_h)
- target_cls 由 target_ret >= target_threshold 生成
- 保留时间日志与 tqdm 进度条
