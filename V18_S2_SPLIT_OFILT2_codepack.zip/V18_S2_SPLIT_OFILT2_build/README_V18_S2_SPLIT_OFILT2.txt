V18_S2_W120_20_20_H4_T16_SPLIT_OFILT2
===================================

这是一个单独的 V18_S2 专用代码包，只针对：
  V18_S2_W120_20_20_H4_T16_SPLIT

本包不改训练主干，只在“预测输出端”增加无未来函数过滤规则：

1) 去掉创业板输出候选
   - 代码前缀 300 / 301 在最终 rank 中直接剔除
   - 训练样本不删，只影响最终 top10 / top1 输出

2) 只保留 T-1 五日平均成交额 >= 20 亿 的股票
   - 使用字段：avg_amount_5_t1
   - 计算方式：截至 T-1 的最近 5 个交易日 amount 均值

3) 用 T-1 成交额 / 截至 T-1 的 5 日平均成交额 做输出端排序加权
   - amount_ratio_t1_5 = amount_t1 / avg_amount_5_t1
   - 最终排序分数：score_ofilt = pred_ret * clip(amount_ratio_t1_5, 0.50, 2.50)
   - 只影响最终排序，不影响训练

注意：
- 这里的 date 是 T-1，entry_date 是 T，因此没有使用 T 日未来数据。
- raw amount 使用的是原始日线 amount 字段，请确保 DuckDB 中该字段单位为“元”或自行调整阈值。

运行方式：
  python run_v18_s2_split_ofilt.py

目录要求：
  V18_S2_SPLIT_OFILT2_build/
  ├─ data/ashare.duckdb
  ├─ conf/
  ├─ run_v18_s2_split_ofilt.py
  └─ ...

主输出目录：
  runs/V18_S2_W120_20_20_H4_T16_SPLIT_OFILT2/V18_S2_W120_20_20_H4_T16_SPLIT_OFILT2/

每个 fold 会同时保存：
- 原始未过滤结果：
  - summary_overall_raw.csv
  - top10_daily_predictions_raw.csv
  - top10_hit_stats_raw.csv
  - rank_hit_distribution_raw.csv
  - test_pred_v18_full_raw.csv

- 过滤后主结果（默认看这些）：
  - summary_overall.csv
  - top10_daily_predictions.csv
  - top10_hit_stats.csv
  - rank_hit_distribution.csv
  - test_pred_v18_full.csv

内存处理：
- 每个 fold 结束后释放 train_df / valid_df / test_df / fit_res
- 执行 gc.collect() / torch.cuda.empty_cache() / torch.cuda.ipc_collect()
- 不降低 num_workers / batch_size / prefetch_factor 配置


修复说明（fix2）
- 入口脚本会把 YAML 中的自定义字段（如 exp_name、min_avg_amount_5_t1、exclude_chinext_in_output、use_amount_ratio_output_weight）附加到 cfg。
- 解决 AshareV14FoldConfig 无 exp_name 属性导致的启动报错。
