@echo off
python run_v18_s2_split_ofilt2.py
pause
