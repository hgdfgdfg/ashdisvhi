@echo off
python run_v18_s1_matrix16.py
pause
