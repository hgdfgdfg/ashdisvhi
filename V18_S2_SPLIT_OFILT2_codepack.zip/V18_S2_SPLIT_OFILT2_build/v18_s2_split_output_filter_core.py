from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import yaml

import ashare_v14_fold as v14
from ashare_backtest import prepare_prediction_table_for_backtest
from experiment_common_v14_fold import log_time, cleanup_memory

CORE_DONE_FILES = [
    'done.json',
    'fold_meta.json',
    'summary_overall.csv',
    'top10_daily_predictions.csv',
    'top10_hit_stats.csv',
    'rank_hit_distribution.csv',
]


def is_fold_complete(fold_dir: Path) -> bool:
    return fold_dir.exists() and all((fold_dir / n).exists() for n in CORE_DONE_FILES)


def _safe_mean(df: pd.DataFrame, col: str) -> float:
    if df is None or df.empty or col not in df.columns:
        return float('nan')
    return float(pd.to_numeric(df[col], errors='coerce').mean())


def _ensure_daily_pred_rank(df: pd.DataFrame, score_col: str = 'pred_ret', rank_col: str = 'pred_rank') -> pd.DataFrame:
    out = df.copy()
    out['date'] = pd.to_datetime(out['date'])
    if score_col not in out.columns:
        out[score_col] = pd.to_numeric(out.get('pred_ret', np.nan), errors='coerce')
    out = out.sort_values(['date', score_col, 'pred_prob_pos'], ascending=[True, False, False]).reset_index(drop=True)
    out[rank_col] = out.groupby('date').cumcount() + 1
    return out


def _attach_t1_amount_features(raw_df: pd.DataFrame, merged: pd.DataFrame, amount_ratio_window: int = 5) -> pd.DataFrame:
    cols = ['symbol', 'date', 'amount']
    tmp = raw_df[cols].copy()
    tmp['date'] = pd.to_datetime(tmp['date'])
    tmp['amount'] = pd.to_numeric(tmp['amount'], errors='coerce')
    tmp = tmp.sort_values(['symbol', 'date']).reset_index(drop=True)
    tmp['avg_amount_5_t1'] = (
        tmp.groupby('symbol', group_keys=False)['amount']
        .rolling(window=int(amount_ratio_window), min_periods=int(amount_ratio_window))
        .mean()
        .reset_index(level=0, drop=True)
    )
    tmp['amount_ratio_t1_5'] = tmp['amount'] / tmp['avg_amount_5_t1']
    out = merged.merge(tmp[['symbol', 'date', 'avg_amount_5_t1', 'amount_ratio_t1_5']], on=['symbol', 'date'], how='left')
    return out


def build_v18_eval_table(test_pred: pd.DataFrame, raw_df: pd.DataFrame, hold_days: int, target_ret_thres: float, amount_ratio_window: int = 5) -> pd.DataFrame:
    merged = prepare_prediction_table_for_backtest(test_pred, raw_df, horizon=int(hold_days))
    if merged is None or merged.empty:
        return pd.DataFrame()
    merged = _ensure_daily_pred_rank(merged)
    merged = _attach_t1_amount_features(raw_df=raw_df, merged=merged, amount_ratio_window=amount_ratio_window)
    merged['target_ret_thres'] = float(target_ret_thres)
    merged['hit_target'] = (pd.to_numeric(merged['real_trade_ret'], errors='coerce') >= float(target_ret_thres)).astype(int)
    merged['score'] = pd.to_numeric(merged['pred_ret'], errors='coerce')
    merged['code'] = merged['code'].astype(str).str.zfill(6)
    return merged


def apply_output_filter(merged: pd.DataFrame, cfg) -> pd.DataFrame:
    if merged is None or merged.empty:
        return pd.DataFrame()
    out = merged.copy()
    out['is_chinext'] = out['code'].astype(str).str.startswith(('300', '301'))
    out['avg_amount_5_t1'] = pd.to_numeric(out['avg_amount_5_t1'], errors='coerce')
    out['amount_ratio_t1_5'] = pd.to_numeric(out['amount_ratio_t1_5'], errors='coerce')
    out['score_base'] = pd.to_numeric(out['score'], errors='coerce')

    if bool(getattr(cfg, 'exclude_chinext_in_output', True)):
        out = out[~out['is_chinext']].copy()

    min_avg_amount = float(getattr(cfg, 'min_avg_amount_5_t1', 1_000_000_000.0))
    out = out[out['avg_amount_5_t1'].fillna(-np.inf) >= min_avg_amount].copy()

    if bool(getattr(cfg, 'use_amount_ratio_output_adjustment', True)):
        lo = float(getattr(cfg, 'amount_ratio_clip_low', 0.80))
        hi = float(getattr(cfg, 'amount_ratio_clip_high', 1.50))
        alpha = float(getattr(cfg, 'amount_ratio_adjustment_alpha', 0.08))
        out['amount_ratio_adj'] = out['amount_ratio_t1_5'].clip(lower=lo, upper=hi).fillna(1.0)
        out['amount_ratio_bonus'] = alpha * (out['amount_ratio_adj'] - 1.0)
    else:
        out['amount_ratio_adj'] = 1.0
        out['amount_ratio_bonus'] = 0.0

    out['score_ofilt'] = out['score_base'] + out['amount_ratio_bonus']
    out['amount_ratio_weight'] = out['amount_ratio_adj']
    out = _ensure_daily_pred_rank(out.rename(columns={'pred_rank': 'pred_rank_raw'}), score_col='score_ofilt', rank_col='pred_rank')
    return out


def _build_outputs_from_table(fold_dir: Path, merged: pd.DataFrame, hold_days: int, target_ret_thres: float, save_suffix: str = '', save_test_pred_full: bool = True) -> Dict:
    suf = save_suffix
    if merged.empty:
        empty = pd.DataFrame()
        for name in [f'summary_by_fold{suf}.csv', f'summary_overall{suf}.csv', f'top10_daily_predictions{suf}.csv', f'top10_hit_stats{suf}.csv', f'rank_hit_distribution{suf}.csv']:
            empty.to_csv(fold_dir / name, index=False, encoding='utf-8-sig')
        return {'summary': pd.DataFrame([{'sample_days': 0}])}

    top10 = merged[merged['pred_rank'] <= 10].copy()
    daily = top10.groupby('date', as_index=False).agg(
        top10_count=('symbol', 'count'),
        top10_hit_count=('hit_target', 'sum'),
        top10_hit_rate=('hit_target', 'mean'),
        top10_avg_ret=('real_trade_ret', 'mean'),
    )
    top10_sorted = top10.sort_values(['date', 'pred_rank']).copy()
    for k in [1, 3, 5]:
        sub = top10_sorted[top10_sorted['pred_rank'] <= k].groupby('date', as_index=False).agg(**{f'top{k}_avg_ret': ('real_trade_ret', 'mean')})
        daily = daily.merge(sub, on='date', how='left')
    rank_hit = top10.groupby('pred_rank', as_index=False).agg(
        count=('symbol', 'count'),
        hit_target_rate=('hit_target', 'mean'),
        avg_ret=('real_trade_ret', 'mean'),
        avg_pred_ret=('pred_ret', 'mean'),
        avg_pred_prob_pos=('pred_prob_pos', 'mean'),
        avg_score_ofilt=('score_ofilt', 'mean') if 'score_ofilt' in top10.columns else ('pred_ret', 'mean'),
        avg_amount_t1=('amount', 'mean'),
        avg_amount_5_t1=('avg_amount_5_t1', 'mean'),
        avg_amount_ratio_t1_5=('amount_ratio_t1_5', 'mean'),
    ).sort_values('pred_rank').reset_index(drop=True)

    keep_cols = [c for c in ['date', 'symbol', 'code', 'pred_rank', 'pred_rank_raw', 'pred_ret', 'pred_prob_pos', 'score_ofilt', 'amount', 'avg_amount_5_t1', 'amount_ratio_t1_5', 'real_trade_ret', 'hit_target', 'entry_date', 'exit_date', 'entry_open', 'exit_open'] if c in top10.columns]
    top10_daily = top10[keep_cols].copy()
    top10_daily['date'] = pd.to_datetime(top10_daily['date']).dt.strftime('%Y-%m-%d')
    if save_test_pred_full:
        merged.to_csv(fold_dir / f'test_pred_v18_full{suf}.csv', index=False, encoding='utf-8-sig')
    top10_daily.to_csv(fold_dir / f'top10_daily_predictions{suf}.csv', index=False, encoding='utf-8-sig')
    daily.to_csv(fold_dir / f'top10_hit_stats{suf}.csv', index=False, encoding='utf-8-sig')
    rank_hit.to_csv(fold_dir / f'rank_hit_distribution{suf}.csv', index=False, encoding='utf-8-sig')

    summary = {
        'hold_days': int(hold_days),
        'target_ret_thres': float(target_ret_thres),
        'sample_days': int(daily['date'].nunique()),
        'top10_hit_rate_mean': _safe_mean(daily, 'top10_hit_rate'),
        'top10_avg_ret_mean': _safe_mean(daily, 'top10_avg_ret'),
        'top5_avg_ret_mean': _safe_mean(daily, 'top5_avg_ret'),
        'top3_avg_ret_mean': _safe_mean(daily, 'top3_avg_ret'),
        'top1_avg_ret_mean': _safe_mean(daily, 'top1_avg_ret'),
        'top10_hit_count_mean': _safe_mean(daily, 'top10_hit_count'),
        'rank1_hit_rate': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'hit_target_rate'),
        'rank1_avg_ret': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'avg_ret'),
        'test_positive_rate': float(pd.to_numeric(merged['hit_target'], errors='coerce').mean()),
        'avg_amount_5_t1_rank1': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'avg_amount_5_t1'),
        'avg_amount_ratio_t1_5_rank1': _safe_mean(rank_hit[rank_hit['pred_rank'] == 1], 'avg_amount_ratio_t1_5'),
    }
    pd.DataFrame([summary]).to_csv(fold_dir / f'summary_overall{suf}.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([summary]).to_csv(fold_dir / f'summary_by_fold{suf}.csv', index=False, encoding='utf-8-sig')
    return {'summary': pd.DataFrame([summary])}


def build_v18_outputs(fold_dir: Path, test_pred: pd.DataFrame, raw_df: pd.DataFrame, hold_days: int, target_ret_thres: float, cfg, save_test_pred_full: bool = True, save_raw_outputs: bool = True) -> Dict:
    log_time(f'V18_S2_SPLIT_OFILT 评估开始 | hold_days={hold_days} | target_ret_thres={target_ret_thres:.4f}')
    merged_raw = build_v18_eval_table(test_pred=test_pred, raw_df=raw_df, hold_days=hold_days, target_ret_thres=target_ret_thres, amount_ratio_window=int(getattr(cfg, 'amount_ratio_window', 5)))
    if merged_raw.empty:
        return _build_outputs_from_table(fold_dir=fold_dir, merged=merged_raw, hold_days=hold_days, target_ret_thres=target_ret_thres, save_suffix='')

    if save_raw_outputs:
        _build_outputs_from_table(fold_dir=fold_dir, merged=merged_raw, hold_days=hold_days, target_ret_thres=target_ret_thres, save_suffix='_raw', save_test_pred_full=save_test_pred_full)

    merged = apply_output_filter(merged_raw, cfg=cfg)
    res = _build_outputs_from_table(fold_dir=fold_dir, merged=merged, hold_days=hold_days, target_ret_thres=target_ret_thres, save_suffix='', save_test_pred_full=save_test_pred_full)
    return res


def save_resolved_config(fold_dir: Path, cfg_obj) -> None:
    obj = {k: getattr(cfg_obj, k) for k in dir(cfg_obj) if not k.startswith('_') and not callable(getattr(cfg_obj, k))}
    with open(fold_dir / 'config_resolved.yaml', 'w', encoding='utf-8') as f:
        yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=True)


def run_one_fold_v18_split_ofilt(data: pd.DataFrame, feature_cols: List[str], cfg, fold_spec: Dict, fold_dir: Path, save_raw_outputs: bool = True) -> Dict:
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    train_df = data[data['date'].isin(fold_spec['train_dates'])].copy().sort_values(['symbol', 'date']).reset_index(drop=True)
    valid_df = v14._build_warmup_slice(data, fold_spec['valid_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['valid_dates'])].copy()
    test_df = v14._build_warmup_slice(data, fold_spec['test_dates'], all_dates, cfg.warmup_days) if hasattr(v14, '_build_warmup_slice') else data[data['date'].isin(fold_spec['test_dates'])].copy()
    fold_dir.mkdir(parents=True, exist_ok=True)
    save_resolved_config(fold_dir, cfg)
    fit_res = None
    try:
        log_time(f"V18_S2_SPLIT_OFILT fold={fold_spec['fold']} | 开始训练与预测")
        fit_res = v14.fit_and_predict_one_fold_ashare_v14(
            train_df=train_df,
            valid_df=valid_df,
            test_df=test_df,
            feature_cols=feature_cols,
            cfg=cfg,
            valid_trade_dates=fold_spec['valid_dates'],
            test_trade_dates=fold_spec['test_dates'],
        )
        if fit_res.get('test_pred') is not None:
            fit_res['test_pred'].to_csv(fold_dir / 'test_pred.csv', index=False, encoding='utf-8-sig')
        if fit_res.get('epoch_records') is not None:
            fit_res['epoch_records'].to_csv(fold_dir / 'epoch_records.csv', index=False, encoding='utf-8-sig')
        res = build_v18_outputs(
            fold_dir=fold_dir,
            test_pred=fit_res['test_pred'],
            raw_df=test_df,
            hold_days=int(cfg.horizon_candidates[0]),
            target_ret_thres=float(cfg.target_ret_threshold),
            cfg=cfg,
            save_test_pred_full=True,
            save_raw_outputs=save_raw_outputs,
        )
        meta = {
            'fold': int(fold_spec['fold']),
            'fold_spec': {k: fold_spec[k] for k in ['train_start', 'train_end', 'valid_start', 'valid_end', 'test_start', 'test_end']},
            'n_train_samples': int(fit_res.get('n_train_samples', 0)),
            'n_valid_samples': int(fit_res.get('n_valid_samples', 0)),
            'n_test_samples': int(fit_res.get('n_test_samples', 0)),
            'study': 'V18 S2 single split output-filter (T-1 only)',
            'hold_days': int(cfg.horizon_candidates[0]),
            'target_ret_threshold': float(cfg.target_ret_threshold),
            'min_avg_amount_5_t1': float(getattr(cfg, 'min_avg_amount_5_t1', 0.0)),
            'exclude_chinext_in_output': bool(getattr(cfg, 'exclude_chinext_in_output', True)),
        }
        (fold_dir / 'fold_meta.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        (fold_dir / 'done.json').write_text(json.dumps({'ok': True, 'study': meta['study']}, ensure_ascii=False, indent=2), encoding='utf-8')
        row = {'fold': int(fold_spec['fold']), **meta['fold_spec']}
        if len(res['summary']):
            row.update(res['summary'].iloc[0].to_dict())
        return row
    finally:
        del train_df, valid_df, test_df
        if fit_res is not None:
            try:
                for k in list(fit_res.keys()):
                    try:
                        del fit_res[k]
                    except Exception:
                        pass
            except Exception:
                pass
        del fit_res
        cleanup_memory()
