from __future__ import annotations

import copy
import json
from pathlib import Path

import pandas as pd
import yaml

import ashare_v14_fold as v14
from experiment_common_v14_fold import build_rolling_fold_specs, log_time, cleanup_memory
from v18_s2_split_output_filter_core import run_one_fold_v18_split_ofilt, is_fold_complete


def load_yaml(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def _resolve_project_path(project_root: Path, raw_path: str | None) -> str | None:
    if raw_path is None:
        return None
    s = str(raw_path).strip()
    if not s:
        return s
    p = Path(s)
    if p.is_absolute():
        return str(p)
    return str((project_root / p).resolve())


def _normalize_runtime_paths(cfg, project_root: Path):
    cfg.db_path = _resolve_project_path(project_root, getattr(cfg, 'db_path', None))
    cfg.out_dir = _resolve_project_path(project_root, getattr(cfg, 'out_dir', 'runs'))
    cfg.model_dir = _resolve_project_path(project_root, getattr(cfg, 'model_dir', 'runs/models'))
    cfg.export_dir = _resolve_project_path(project_root, getattr(cfg, 'export_dir', 'runs/exports'))
    return cfg


def _load_fold_row(fold_dir: Path, exp_name: str):
    meta_fp = fold_dir / 'fold_meta.json'
    summary_fp = fold_dir / 'summary_overall.csv'
    if not meta_fp.exists() or not summary_fp.exists():
        return None
    meta = json.loads(meta_fp.read_text(encoding='utf-8'))
    df = pd.read_csv(summary_fp)
    if df.empty:
        return None
    row = {'exp_name': exp_name, 'fold': int(meta.get('fold', 0)), **meta.get('fold_spec', {})}
    row.update(df.iloc[0].to_dict())
    return row


def _write_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def _write_experiment_summary(exp_dir: Path, exp_name: str):
    rows = []
    for fold_dir in sorted(exp_dir.glob('fold_*')):
        row = _load_fold_row(fold_dir, exp_name)
        if row is not None:
            rows.append(row)
    df = pd.DataFrame(rows).sort_values('fold').reset_index(drop=True) if rows else pd.DataFrame()
    df.to_csv(exp_dir / 'summary_by_fold.csv', index=False, encoding='utf-8-sig')
    if len(df):
        agg = {
            'exp_name': exp_name,
            'folds': int(len(df)),
            'top10_hit_rate_mean': float(pd.to_numeric(df['top10_hit_rate_mean'], errors='coerce').mean()),
            'top10_avg_ret_mean': float(pd.to_numeric(df['top10_avg_ret_mean'], errors='coerce').mean()),
            'top5_avg_ret_mean': float(pd.to_numeric(df['top5_avg_ret_mean'], errors='coerce').mean()),
            'top3_avg_ret_mean': float(pd.to_numeric(df['top3_avg_ret_mean'], errors='coerce').mean()),
            'top1_avg_ret_mean': float(pd.to_numeric(df['top1_avg_ret_mean'], errors='coerce').mean()),
            'rank1_hit_rate': float(pd.to_numeric(df['rank1_hit_rate'], errors='coerce').mean()),
            'test_positive_rate': float(pd.to_numeric(df['test_positive_rate'], errors='coerce').mean()),
            'hold_days': int(pd.to_numeric(df['hold_days'], errors='coerce').iloc[0]),
            'target_ret_thres': float(pd.to_numeric(df['target_ret_thres'], errors='coerce').iloc[0]),
            'avg_amount_5_t1_rank1': float(pd.to_numeric(df['avg_amount_5_t1_rank1'], errors='coerce').mean()),
            'avg_amount_ratio_t1_5_rank1': float(pd.to_numeric(df['avg_amount_ratio_t1_5_rank1'], errors='coerce').mean()),
        }
        pd.DataFrame([agg]).to_csv(exp_dir / 'summary_overall.csv', index=False, encoding='utf-8-sig')
        _write_json(exp_dir / 'experiment_done.json', agg)
    else:
        pd.DataFrame().to_csv(exp_dir / 'summary_overall.csv', index=False, encoding='utf-8-sig')
        _write_json(exp_dir / 'experiment_done.json', {'exp_name': exp_name, 'folds': 0})


def main():
    project_root = Path(__file__).resolve().parent
    runner_cfg = load_yaml(str(project_root / 'conf' / 'v18_s2_split_ofilt2_runner.yaml'))
    base_yaml = _resolve_project_path(project_root, str(runner_cfg['base_yaml']))
    out_subdir = str(runner_cfg.get('out_subdir', 'V18_S2_W120_20_20_H4_T16_SPLIT_OFILT2'))
    skip_completed = bool(runner_cfg.get('skip_completed', True))
    save_raw_outputs = bool(runner_cfg.get('save_raw_outputs', True))

    base_raw = load_yaml(base_yaml)
    cfg = v14.load_config_from_yaml(base_yaml)
    # attach custom yaml fields not present on AshareV14FoldConfig dataclass
    for k, v in base_raw.items():
        if not hasattr(cfg, k):
            setattr(cfg, k, v)
    cfg = _normalize_runtime_paths(cfg, project_root)
    cfg = v14.configure_torch_runtime(cfg)
    v14.seed_everything(cfg.seed)

    root_dir = Path(cfg.out_dir) / out_subdir
    root_dir.mkdir(parents=True, exist_ok=True)
    log_time(f'V18_S2_SPLIT_OFILT2 路径解析 | db_path={cfg.db_path}')
    log_time(f'V18_S2_SPLIT_OFILT2 输出过滤 | 去创业板={getattr(cfg, "exclude_chinext_in_output", True)} | min_avg_amount_5_t1={getattr(cfg, "min_avg_amount_5_t1", 0)} | use_amount_ratio_output_weight={getattr(cfg, "use_amount_ratio_output_weight", True)}')

    data, feature_cols, prep_meta = v14.prepare_full_dataset(cfg)
    if getattr(cfg, 'auto_drop_benchmark_from_training', True):
        bench = str(getattr(cfg, 'benchmark_symbol', 'sh000001')).zfill(6)
        before = len(data)
        data = data[data['symbol'].astype(str).str.zfill(6) != bench].copy()
        log_time(f'V18_S2_SPLIT_OFILT2 剔除 benchmark={bench} 训练样本 | rows {before} -> {len(data)}')

    fold_specs = build_rolling_fold_specs(data=data, cfg=cfg, num_folds=int(base_raw.get('num_folds', 10)), fold_stride_days=cfg.test_days)
    fold_specs = sorted(fold_specs, key=lambda x: int(x.get('fold', 0)))[-int(base_raw.get('recent_n_folds', 5)):]
    exp_name = str(getattr(cfg, 'exp_name', 'V18_S2_W120_20_20_H4_T16_SPLIT_OFILT2'))
    log_time(f'V18_S2_SPLIT_OFILT2 开始 | exp={exp_name} | recent_folds={[int(s.get("fold", 0)) for s in fold_specs]}')

    exp_dir = root_dir / exp_name
    exp_dir.mkdir(parents=True, exist_ok=True)
    for spec in fold_specs:
        fold_dir = exp_dir / f"fold_{int(spec['fold']):02d}"
        if skip_completed and is_fold_complete(fold_dir):
            log_time(f'V18_S2_SPLIT_OFILT2 跳过已完成 | fold={int(spec["fold"])}')
            continue
        row = run_one_fold_v18_split_ofilt(data=data, feature_cols=feature_cols, cfg=cfg, fold_spec=spec, fold_dir=fold_dir, save_raw_outputs=save_raw_outputs)
        del row
        cleanup_memory()

    _write_experiment_summary(exp_dir, exp_name)
    log_time(f'V18_S2_SPLIT_OFILT2 完成 | 结果目录: {exp_dir}')


if __name__ == '__main__':
    main()
