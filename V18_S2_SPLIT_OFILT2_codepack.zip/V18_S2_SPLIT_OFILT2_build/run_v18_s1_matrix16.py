from __future__ import annotations

import copy
import csv
import json
from pathlib import Path
import os

import pandas as pd
import yaml

import ashare_v14_fold as v14
from experiment_common_v14_fold import build_rolling_fold_specs, log_time, cleanup_memory
from v18_top10_matrix_core import run_one_fold_v18, is_fold_complete


def load_yaml(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def load_matrix_csv(path: str) -> list[dict]:
    out = []
    with open(path, 'r', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            if int(row.get('enable', '1')) != 1:
                continue
            row['train_days'] = int(row['train_days'])
            row['valid_days'] = int(row['valid_days'])
            row['test_days'] = int(row['test_days'])
            row['hold_days'] = int(row['hold_days'])
            row['target_ret_thres'] = float(row['target_ret_thres'])
            out.append(row)
    return out




def _resolve_project_path(project_root: Path, raw_path: str | None) -> str | None:
    if raw_path is None:
        return None
    s = str(raw_path).strip()
    if not s:
        return s
    p = Path(s)
    if p.is_absolute():
        return str(p)
    return str((project_root / p).resolve())


def _normalize_runtime_paths(cfg, project_root: Path):
    cfg.db_path = _resolve_project_path(project_root, getattr(cfg, 'db_path', None))
    cfg.out_dir = _resolve_project_path(project_root, getattr(cfg, 'out_dir', 'runs'))
    cfg.model_dir = _resolve_project_path(project_root, getattr(cfg, 'model_dir', 'runs/models'))
    cfg.export_dir = _resolve_project_path(project_root, getattr(cfg, 'export_dir', 'runs/exports'))
    return cfg

def _write_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def _load_fold_row(fold_dir: Path, exp_name: str):
    meta_fp = fold_dir / 'fold_meta.json'
    summary_fp = fold_dir / 'summary_overall.csv'
    if not meta_fp.exists() or not summary_fp.exists():
        return None
    meta = json.loads(meta_fp.read_text(encoding='utf-8'))
    df = pd.read_csv(summary_fp)
    if df.empty:
        return None
    row = {'exp_name': exp_name, 'fold': int(meta.get('fold', 0)), **meta.get('fold_spec', {})}
    row.update(df.iloc[0].to_dict())
    return row


def _write_experiment_summary(exp_dir: Path, exp_name: str):
    rows = []
    for fold_dir in sorted(exp_dir.glob('fold_*')):
        row = _load_fold_row(fold_dir, exp_name)
        if row is not None:
            rows.append(row)
    df = pd.DataFrame(rows).sort_values('fold').reset_index(drop=True) if rows else pd.DataFrame()
    df.to_csv(exp_dir / 'summary_by_fold.csv', index=False, encoding='utf-8-sig')
    if len(df):
        agg = {
            'exp_name': exp_name,
            'folds': int(len(df)),
            'top10_hit_rate_mean': float(pd.to_numeric(df['top10_hit_rate_mean'], errors='coerce').mean()),
            'top10_avg_ret_mean': float(pd.to_numeric(df['top10_avg_ret_mean'], errors='coerce').mean()),
            'top5_avg_ret_mean': float(pd.to_numeric(df['top5_avg_ret_mean'], errors='coerce').mean()),
            'top3_avg_ret_mean': float(pd.to_numeric(df['top3_avg_ret_mean'], errors='coerce').mean()),
            'top1_avg_ret_mean': float(pd.to_numeric(df['top1_avg_ret_mean'], errors='coerce').mean()),
            'rank1_hit_rate': float(pd.to_numeric(df['rank1_hit_rate'], errors='coerce').mean()),
            'test_positive_rate': float(pd.to_numeric(df['test_positive_rate'], errors='coerce').mean()),
            'hold_days': int(pd.to_numeric(df['hold_days'], errors='coerce').iloc[0]),
            'target_ret_thres': float(pd.to_numeric(df['target_ret_thres'], errors='coerce').iloc[0]),
        }
        pd.DataFrame([agg]).to_csv(exp_dir / 'summary_overall.csv', index=False, encoding='utf-8-sig')
        _write_json(exp_dir / 'experiment_done.json', agg)
    else:
        pd.DataFrame().to_csv(exp_dir / 'summary_overall.csv', index=False, encoding='utf-8-sig')
        _write_json(exp_dir / 'experiment_done.json', {'exp_name': exp_name, 'folds': 0})


def _build_global_summary(root_dir: Path):
    exp_rows = []
    fold_rows = []
    for exp_dir in sorted([p for p in root_dir.iterdir() if p.is_dir() and p.name.startswith('V18_')]):
        s_fp = exp_dir / 'summary_overall.csv'
        if s_fp.exists():
            df = pd.read_csv(s_fp)
            if len(df):
                exp_rows.append(df.assign(exp_name=exp_dir.name))
        f_fp = exp_dir / 'summary_by_fold.csv'
        if f_fp.exists():
            df = pd.read_csv(f_fp)
            if len(df):
                fold_rows.append(df.assign(exp_name=exp_dir.name))
    leaderboard = pd.concat(exp_rows, ignore_index=True) if exp_rows else pd.DataFrame()
    if len(leaderboard):
        leaderboard = leaderboard.sort_values(['top10_hit_rate_mean', 'top10_avg_ret_mean', 'top1_avg_ret_mean'], ascending=[False, False, False]).reset_index(drop=True)
        leaderboard.to_csv(root_dir / 'matrix16_leaderboard.csv', index=False, encoding='utf-8-sig')
        leaderboard.head(6).to_csv(root_dir / 'matrix16_best_configs.csv', index=False, encoding='utf-8-sig')
        _write_json(root_dir / 'overview.json', leaderboard.to_dict(orient='records'))
    else:
        pd.DataFrame().to_csv(root_dir / 'matrix16_leaderboard.csv', index=False, encoding='utf-8-sig')
        pd.DataFrame().to_csv(root_dir / 'matrix16_best_configs.csv', index=False, encoding='utf-8-sig')
        _write_json(root_dir / 'overview.json', [])
    all_folds = pd.concat(fold_rows, ignore_index=True) if fold_rows else pd.DataFrame()
    all_folds.to_csv(root_dir / 'matrix16_all_folds.csv', index=False, encoding='utf-8-sig')


def main():
    project_root = Path(__file__).resolve().parent
    runner_cfg = load_yaml(str(project_root / 'conf' / 'v18_runner.yaml'))
    base_yaml = _resolve_project_path(project_root, str(runner_cfg['base_yaml']))
    matrix_csv = _resolve_project_path(project_root, str(runner_cfg['matrix_csv']))
    out_subdir = str(runner_cfg.get('out_subdir', 'V18_S1_matrix16'))
    skip_completed = bool(runner_cfg.get('skip_completed', True))

    base_raw = load_yaml(base_yaml)
    base_cfg = v14.load_config_from_yaml(base_yaml)
    base_cfg = _normalize_runtime_paths(base_cfg, project_root)
    base_cfg = v14.configure_torch_runtime(base_cfg)
    v14.seed_everything(base_cfg.seed)

    root_dir = Path(base_cfg.out_dir) / out_subdir
    log_time(f'V18 路径解析 | db_path={base_cfg.db_path}')
    cache_dir = root_dir / 'cache'
    root_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)

    matrix = load_matrix_csv(matrix_csv)
    log_time(f'V18 S1 matrix16 开始 | 实验数={len(matrix)}')

    prep_cache = {}
    for exp in matrix:
        hold_days = int(exp['hold_days'])
        target_ret_thres = float(exp['target_ret_thres'])
        exp_name = str(exp['exp_name'])
        log_time(f'V18 准备实验 | {exp_name}')
        cfg = copy.deepcopy(base_cfg)
        cfg.train_days = int(exp['train_days'])
        cfg.valid_days = int(exp['valid_days'])
        cfg.test_days = int(exp['test_days'])
        cfg.horizon_candidates = (hold_days,)
        cfg.label_return_mode = 'hold_ret'
        cfg.target_ret_threshold = target_ret_thres
        cfg.breakout_success_threshold = target_ret_thres
        cfg.exp_name = exp_name
        exp_dir = root_dir / exp_name
        exp_dir.mkdir(parents=True, exist_ok=True)

        if hold_days not in prep_cache:
            log_time(f'V18 prepare_full_dataset | hold_days={hold_days}')
            data, feature_cols, prep_meta = v14.prepare_full_dataset(cfg)
            if getattr(cfg, 'auto_drop_benchmark_from_training', True):
                bench = str(getattr(cfg, 'benchmark_symbol', 'sh000001')).zfill(6)
                before = len(data)
                data = data[data['symbol'].astype(str).str.zfill(6) != bench].copy()
                log_time(f'V18 剔除 benchmark={bench} 训练样本 | rows {before} -> {len(data)}')
            prep_cache[hold_days] = (data, feature_cols)
            (cache_dir / f'prep_meta_H{hold_days}.json').write_text(json.dumps(prep_meta, ensure_ascii=False, indent=2), encoding='utf-8')
        data, feature_cols = prep_cache[hold_days]

        fold_specs = build_rolling_fold_specs(data=data, cfg=cfg, num_folds=int(base_raw.get('num_folds', 10)), fold_stride_days=cfg.test_days)
        fold_specs = sorted(fold_specs, key=lambda x: int(x.get('fold', 0)))[-int(base_raw.get('recent_n_folds', 5)):]
        print(f"[V18 recent folds] {exp_name}: {[int(s.get('fold', 0)) for s in fold_specs]}")

        for spec in fold_specs:
            fold_dir = exp_dir / f"fold_{int(spec['fold']):02d}"
            if skip_completed and is_fold_complete(fold_dir):
                log_time(f'V18 跳过已完成 | {exp_name} | fold={int(spec["fold"])}')
                continue
            row = run_one_fold_v18(data=data, feature_cols=feature_cols, cfg=cfg, fold_spec=spec, fold_dir=fold_dir)
            del row
            cleanup_memory()
        _write_experiment_summary(exp_dir, exp_name)
        cleanup_memory()

    _build_global_summary(root_dir)
    log_time(f'V18 S1 matrix16 完成 | 结果目录: {root_dir}')


if __name__ == '__main__':
    main()
