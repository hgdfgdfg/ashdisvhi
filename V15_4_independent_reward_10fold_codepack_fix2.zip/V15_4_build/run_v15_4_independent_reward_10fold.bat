@echo off
python run_v15_4_independent_reward_10fold.py
pause
