V15.4 independent reward 10fold codepack

版本目标：
1. 完全删除 lowrisk / confirm / overheat 相关逻辑与输出。
2. 保留原始 baseline top1 作为主线。
3. 新增 benchmark=sh000001 的独立行情奖励支线。
4. 输出 baseline vs reward 的严格并排对比。
5. 额外输出 5天后 close 相对 T 日 open / T+1 open 的 +8%/+10% 概率。
6. 保留进度条、时间日志，并在每个 fold 与大文件拼接后主动清缓存。

入口：
- python run_v15_4_independent_reward_10fold.py
- 或双击 run_v15_4_independent_reward_10fold.bat
