from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd


def add_listing_days(df: pd.DataFrame) -> pd.DataFrame:
    out = df.sort_values(["symbol", "date"]).copy()
    out["n_listed_days"] = out.groupby("symbol").cumcount() + 1
    return out


def add_gap_masks(
    df: pd.DataFrame,
    max_calendar_gap_for_training: int = 10,
) -> pd.DataFrame:
    """
    处理停牌/长间隔近似:
    - calendar_gap_days: 当前bar与前一bar之间自然日间隔
    - is_abnormal_gap_train: 过大则训练时过滤
    """
    out = df.sort_values(["symbol", "date"]).copy()

    gap = out.groupby("symbol")["date"].diff().dt.days
    out["calendar_gap_days"] = gap.fillna(1)

    out["is_abnormal_gap_train"] = (
        out["calendar_gap_days"] > max_calendar_gap_for_training
    ).astype(np.int8)

    return out


def add_buyability_masks(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """
    买入可行性:
    当前日开盘是否可以认为能买到

    第一版规则:
    - 若当日一字涨停，认为买不到
    - 否则认为可以买
    """
    out = df.copy()

    prev_close = out.groupby("symbol")["close"].shift(1)
    pct_chg = out["close"] / prev_close - 1.0

    one_word = (
        (out["open"] == out["high"]) &
        (out["high"] == out["low"]) &
        (out["low"] == out["close"])
    )

    out["one_word_limit_up"] = ((pct_chg >= 0.095) & one_word).astype(np.int8)
    out["one_word_limit_down"] = ((pct_chg <= -0.095) & one_word).astype(np.int8)

    out["tradable_buy"] = 1
    out.loc[out["one_word_limit_up"] == 1, "tradable_buy"] = 0

    # 你已经明确说“次日一定能卖掉”
    out["tradable_sell_next_open"] = 1

    return out


def add_basic_quality_filters(
    df: pd.DataFrame,
) -> pd.DataFrame:
    out = df.copy()

    out["valid_price"] = (
        (out["open"] > 0) &
        (out["high"] > 0) &
        (out["low"] > 0) &
        (out["close"] > 0)
    ).astype(np.int8)

    out["valid_volume"] = (out["volume"] >= 0).astype(np.int8)
    out["valid_amount"] = (out["amount"] >= 0).astype(np.int8)

    out["valid_row_basic"] = (
        (out["valid_price"] == 1) &
        (out["valid_volume"] == 1) &
        (out["valid_amount"] == 1)
    ).astype(np.int8)

    return out


def apply_training_filters(
    df: pd.DataFrame,
    min_list_days: int = 60,
    max_calendar_gap_for_training: int = 10,
) -> pd.DataFrame:
    """
    对训练集应用完整过滤。
    """
    out = df.copy()

    if "n_listed_days" not in out.columns:
        out = add_listing_days(out)

    out = add_gap_masks(out, max_calendar_gap_for_training=max_calendar_gap_for_training)
    out = add_buyability_masks(out)
    out = add_basic_quality_filters(out)

    out = out[out["n_listed_days"] >= min_list_days].copy()
    out = out[out["valid_row_basic"] == 1].copy()
    out = out[out["is_abnormal_gap_train"] == 0].copy()

    out = out.sort_values(["symbol", "date"]).reset_index(drop=True)
    return out


def summarize_filter_effect(
    before_df: pd.DataFrame,
    after_df: pd.DataFrame,
) -> Dict:
    return {
        "before_rows": int(len(before_df)),
        "after_rows": int(len(after_df)),
        "removed_rows": int(len(before_df) - len(after_df)),
        "before_symbols": int(before_df["symbol"].nunique()) if len(before_df) else 0,
        "after_symbols": int(after_df["symbol"].nunique()) if len(after_df) else 0,
        "before_min_date": str(before_df["date"].min()) if len(before_df) else None,
        "before_max_date": str(before_df["date"].max()) if len(before_df) else None,
        "after_min_date": str(after_df["date"].min()) if len(after_df) else None,
        "after_max_date": str(after_df["date"].max()) if len(after_df) else None,
    }