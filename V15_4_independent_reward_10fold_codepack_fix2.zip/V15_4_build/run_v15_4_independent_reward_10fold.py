from __future__ import annotations

import copy
import json
from pathlib import Path

import pandas as pd
import yaml

import ashare_v14_fold as v14
from experiment_common_v14_fold import build_rolling_fold_specs, run_one_fold, log_time, cleanup_memory


CORE_DONE_FILES = [
    'done.json',
    'fold_meta.json',
    'v15_4_eval_summary.csv',
    'top10_rank_stats.csv',
    'top1_baseline_vs_reward_daily.csv',
    'candidate_kline_windows.csv',
    'test_pred_v15_4.csv',
    'top_candidates_v15_4_compare.csv',
]


def load_yaml(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def is_fold_complete(fold_dir: Path) -> bool:
    return fold_dir.exists() and all((fold_dir / name).exists() for name in CORE_DONE_FILES)


def load_fold_row(fold_dir: Path, cycle_name: str, horizon: int) -> dict | None:
    meta_fp = fold_dir / 'fold_meta.json'
    eval_fp = fold_dir / 'v15_4_eval_summary.csv'
    if not meta_fp.exists() or not eval_fp.exists():
        return None
    meta = json.loads(meta_fp.read_text(encoding='utf-8'))
    eval_df = pd.read_csv(eval_fp)
    if eval_df.empty:
        return None
    s = eval_df.iloc[0].to_dict()
    spec = meta.get('fold_spec', {})
    return {
        'fold': int(meta.get('fold', int(fold_dir.name.split('_')[-1]))),
        'horizon': int(horizon),
        'cycle_name': cycle_name,
        'train_start': spec.get('train_start'),
        'train_end': spec.get('train_end'),
        'valid_start': spec.get('valid_start'),
        'valid_end': spec.get('valid_end'),
        'test_start': spec.get('test_start'),
        'test_end': spec.get('test_end'),
        'baseline_top1_avg_true_max_up_5': s.get('baseline_top1_avg_true_max_up_5'),
        'baseline_top1_hit8_rate_5': s.get('baseline_top1_hit8_rate_5'),
        'baseline_top1_hit10_rate_5': s.get('baseline_top1_hit10_rate_5'),
        'baseline_top1_close5_open_t_hit8': s.get('baseline_top1_close5_open_t_hit8'),
        'baseline_top1_close5_open_t_hit10': s.get('baseline_top1_close5_open_t_hit10'),
        'baseline_top1_close5_open_t1_hit8': s.get('baseline_top1_close5_open_t1_hit8'),
        'baseline_top1_close5_open_t1_hit10': s.get('baseline_top1_close5_open_t1_hit10'),
        'reward_top1_avg_true_max_up_5': s.get('reward_top1_avg_true_max_up_5'),
        'reward_top1_hit8_rate_5': s.get('reward_top1_hit8_rate_5'),
        'reward_top1_hit10_rate_5': s.get('reward_top1_hit10_rate_5'),
        'reward_top1_close5_open_t_hit8': s.get('reward_top1_close5_open_t_hit8'),
        'reward_top1_close5_open_t_hit10': s.get('reward_top1_close5_open_t_hit10'),
        'reward_top1_close5_open_t1_hit8': s.get('reward_top1_close5_open_t1_hit8'),
        'reward_top1_close5_open_t1_hit10': s.get('reward_top1_close5_open_t1_hit10'),
        'same_pick_rate': s.get('same_pick_rate'),
        'reward_better_maxup5_rate': s.get('reward_better_maxup5_rate'),
        'candidate_mode': 'original',
    }


def write_cycle_summary(exp_dir: Path, rows: list[dict], build_large_files: bool = False) -> None:
    summary_df = pd.DataFrame(rows).sort_values(['horizon', 'cycle_name', 'fold']).reset_index(drop=True) if rows else pd.DataFrame()
    summary_df.to_csv(exp_dir / 'all_fold_results.csv', index=False, encoding='utf-8-sig')
    if len(summary_df):
        agg = summary_df.groupby(['cycle_name', 'horizon'], as_index=False).agg(
            avg_baseline_top1_maxup5=('baseline_top1_avg_true_max_up_5', 'mean'),
            avg_baseline_top1_hit8=('baseline_top1_hit8_rate_5', 'mean'),
            avg_baseline_top1_hit10=('baseline_top1_hit10_rate_5', 'mean'),
            avg_baseline_close5_open_t_hit8=('baseline_top1_close5_open_t_hit8', 'mean'),
            avg_baseline_close5_open_t_hit10=('baseline_top1_close5_open_t_hit10', 'mean'),
            avg_baseline_close5_open_t1_hit8=('baseline_top1_close5_open_t1_hit8', 'mean'),
            avg_baseline_close5_open_t1_hit10=('baseline_top1_close5_open_t1_hit10', 'mean'),
            avg_reward_top1_maxup5=('reward_top1_avg_true_max_up_5', 'mean'),
            avg_reward_top1_hit8=('reward_top1_hit8_rate_5', 'mean'),
            avg_reward_top1_hit10=('reward_top1_hit10_rate_5', 'mean'),
            avg_reward_close5_open_t_hit8=('reward_top1_close5_open_t_hit8', 'mean'),
            avg_reward_close5_open_t_hit10=('reward_top1_close5_open_t_hit10', 'mean'),
            avg_reward_close5_open_t1_hit8=('reward_top1_close5_open_t1_hit8', 'mean'),
            avg_reward_close5_open_t1_hit10=('reward_top1_close5_open_t1_hit10', 'mean'),
            avg_same_pick_rate=('same_pick_rate', 'mean'),
            avg_reward_better_maxup5_rate=('reward_better_maxup5_rate', 'mean'),
            better_hit8_folds=('reward_top1_hit8_rate_5', lambda s: int((s > summary_df.loc[s.index, 'baseline_top1_hit8_rate_5']).sum())),
            better_hit10_folds=('reward_top1_hit10_rate_5', lambda s: int((s > summary_df.loc[s.index, 'baseline_top1_hit10_rate_5']).sum())),
            folds=('fold', 'count'),
        )
        agg['delta_hit8_5'] = agg['avg_reward_top1_hit8'] - agg['avg_baseline_top1_hit8']
        agg['delta_hit10_5'] = agg['avg_reward_top1_hit10'] - agg['avg_baseline_top1_hit10']
        agg['delta_close5_open_t_hit8'] = agg['avg_reward_close5_open_t_hit8'] - agg['avg_baseline_close5_open_t_hit8']
        agg['delta_close5_open_t_hit10'] = agg['avg_reward_close5_open_t_hit10'] - agg['avg_baseline_close5_open_t_hit10']
        agg['delta_close5_open_t1_hit8'] = agg['avg_reward_close5_open_t1_hit8'] - agg['avg_baseline_close5_open_t1_hit8']
        agg['delta_close5_open_t1_hit10'] = agg['avg_reward_close5_open_t1_hit10'] - agg['avg_baseline_close5_open_t1_hit10']
    else:
        agg = pd.DataFrame()
    agg.to_csv(exp_dir / 'v15_4_cycle_horizon_summary.csv', index=False, encoding='utf-8-sig')
    with open(exp_dir / 'overview.json', 'w', encoding='utf-8') as f:
        json.dump(agg.to_dict(orient='records'), f, ensure_ascii=False, indent=2)

    rank_rows = []
    daily_rows = []
    profile_rows = []
    kline_rows = []
    for hz_dir in sorted(exp_dir.glob('horizon_*')):
        for cycle_dir in sorted(hz_dir.iterdir()):
            if not cycle_dir.is_dir():
                continue
            for fold_dir in sorted(cycle_dir.glob('fold_*')):
                fold_no = int(fold_dir.name.split('_')[-1])
                for name, bucket in [
                    ('top10_rank_stats.csv', rank_rows),
                    ('top1_baseline_vs_reward_daily.csv', daily_rows),
                    ('reward_feature_profile_all.csv', profile_rows),
                ]:
                    fp = fold_dir / name
                    if fp.exists():
                        df = pd.read_csv(fp)
                        df.insert(0, 'fold', fold_no)
                        df.insert(0, 'cycle_name', cycle_dir.name)
                        df.insert(0, 'horizon', int(hz_dir.name.split('_')[-1]))
                        bucket.append(df)
                if build_large_files:
                    fp = fold_dir / 'candidate_kline_windows.csv'
                    if fp.exists():
                        df = pd.read_csv(fp)
                        df.insert(0, 'fold', fold_no)
                        df.insert(0, 'cycle_name', cycle_dir.name)
                        df.insert(0, 'horizon', int(hz_dir.name.split('_')[-1]))
                        kline_rows.append(df)
    if rank_rows:
        rank_all = pd.concat(rank_rows, ignore_index=True)
        rank_all.to_csv(exp_dir / 'top10_rank_stats_all.csv', index=False, encoding='utf-8-sig')
        rank_all.groupby(['pred_rank'], as_index=False).agg(
            count=('count', 'sum'),
            avg_true_max_up_3=('avg_true_max_up_3', 'mean'),
            avg_true_max_up_5=('avg_true_max_up_5', 'mean'),
            avg_true_max_up_10=('avg_true_max_up_10', 'mean'),
            hit8_rate_5=('hit8_rate_5', 'mean'),
            hit10_rate_5=('hit10_rate_5', 'mean'),
            close5_open_t_hit8=('close5_open_t_hit8', 'mean'),
            close5_open_t_hit10=('close5_open_t_hit10', 'mean'),
            close5_open_t1_hit8=('close5_open_t1_hit8', 'mean'),
            close5_open_t1_hit10=('close5_open_t1_hit10', 'mean'),
            avg_post_day1_ret=('avg_post_day1_ret', 'mean'),
            avg_post_day2_ret=('avg_post_day2_ret', 'mean'),
            avg_post_day3_ret=('avg_post_day3_ret', 'mean'),
        ).to_csv(exp_dir / 'top10_rank_aggregate.csv', index=False, encoding='utf-8-sig')
        del rank_all
        cleanup_memory()
    if daily_rows:
        pd.concat(daily_rows, ignore_index=True).to_csv(exp_dir / 'top1_baseline_vs_reward_daily_all.csv', index=False, encoding='utf-8-sig')
    if profile_rows:
        pd.concat(profile_rows, ignore_index=True).to_csv(exp_dir / 'reward_feature_profile_all.csv', index=False, encoding='utf-8-sig')
    if build_large_files and kline_rows:
        pd.concat(kline_rows, ignore_index=True).to_csv(exp_dir / 'candidate_kline_windows_all.csv', index=False, encoding='utf-8-sig')
    cleanup_memory()


def main() -> None:
    yaml_path = 'conf/ashare_v15_4_independent_reward_10fold.yaml'
    raw_cfg = load_yaml(yaml_path)
    cfg = v14.load_config_from_yaml(yaml_path)
    cfg = v14.configure_torch_runtime(cfg)
    cfg.reward_weights = raw_cfg.get('reward_weights', {})
    cfg.reward_rerank_topn = int(raw_cfg.get('reward_rerank_topn', 10))
    cfg.benchmark_symbol = str(raw_cfg.get('benchmark_symbol', 'sh000001'))
    cfg.benchmark_name = str(raw_cfg.get('benchmark_name', '上证指数'))
    cfg.index_down_th = float(raw_cfg.get('index_down_th', -0.005))
    cfg.stock_up_th = float(raw_cfg.get('stock_up_th', 0.01))
    cfg.relative_strength_cap_1d = float(raw_cfg.get('relative_strength_cap_1d', 0.05))
    cfg.relative_strength_cap_5d = float(raw_cfg.get('relative_strength_cap_5d', 0.10))
    cfg.enable_close5_prob_metrics = bool(raw_cfg.get('enable_close5_prob_metrics', True))
    cfg.maxup_eval_horizons = raw_cfg.get('maxup_eval_horizons', [3, 5, 10])
    cfg.kline_pre_days = int(raw_cfg.get('kline_pre_days', 10))
    cfg.kline_post_days = int(raw_cfg.get('kline_post_days', 10))
    cfg.auto_drop_benchmark_from_training = bool(raw_cfg.get('auto_drop_benchmark_from_training', True))
    v14.seed_everything(cfg.seed)

    cycle_presets = raw_cfg.get('cycle_presets', [])
    experiment_horizons = raw_cfg.get('experiment_horizons', list(getattr(cfg, 'horizon_candidates', [5]))) or [5]
    num_folds = int(raw_cfg.get('num_folds', 10))
    out_root = Path(cfg.out_dir) / 'V15_4_independent_reward_10fold_experiments'
    out_root.mkdir(parents=True, exist_ok=True)

    rows: list[dict] = []
    for horizon in experiment_horizons:
        cfg_h = copy.deepcopy(cfg)
        cfg_h.horizon_candidates = (int(horizon),)
        log_time(f'V15.4 | 准备数据 | horizon={horizon}')
        data, feature_cols, prep_meta = v14.prepare_full_dataset(cfg_h)
        if getattr(cfg_h, 'auto_drop_benchmark_from_training', True):
            bench = str(getattr(cfg_h, 'benchmark_symbol', 'sh000001')).zfill(6)
            before = len(data)
            data = data[data['symbol'].astype(str).str.zfill(6) != bench].copy()
            log_time(f'V15.4 | 剔除 benchmark={bench} 训练样本 | rows {before} -> {len(data)}')
        hz_dir = out_root / f'horizon_{int(horizon):02d}'
        hz_dir.mkdir(parents=True, exist_ok=True)
        with open(hz_dir / 'prep_meta.json', 'w', encoding='utf-8') as f:
            json.dump(prep_meta, f, ensure_ascii=False, indent=2)
        for preset in cycle_presets:
            cycle_name = str(preset['name'])
            cfg_c = copy.deepcopy(cfg_h)
            cfg_c.train_days = int(preset['train_days'])
            cfg_c.valid_days = int(preset['valid_days'])
            cfg_c.test_days = int(preset['test_days'])
            cfg_c.warmup_days = int(preset['warmup_days'])
            cycle_dir = hz_dir / cycle_name
            cycle_dir.mkdir(parents=True, exist_ok=True)
            fold_specs = build_rolling_fold_specs(data=data, cfg=cfg_c, num_folds=num_folds, fold_stride_days=cfg_c.test_days)
            for spec in fold_specs:
                fold_dir = cycle_dir / f"fold_{spec['fold']:02d}"
                if is_fold_complete(fold_dir):
                    print(f"[resume] 跳过已完成 fold={spec['fold']} | {cycle_name} | horizon={horizon}")
                    row = load_fold_row(fold_dir, cycle_name, int(horizon))
                    if row is not None:
                        rows = [r for r in rows if not (r['cycle_name'] == cycle_name and r['horizon'] == int(horizon) and r['fold'] == row['fold'])]
                        rows.append(row)
                    continue
                print('\n' + '=' * 60)
                print(f"[V15.4] {cycle_name} | horizon={horizon} | Fold {spec['fold']}")
                print(json.dumps({'train_start': spec['train_start'], 'train_end': spec['train_end'], 'valid_start': spec['valid_start'], 'valid_end': spec['valid_end'], 'test_start': spec['test_start'], 'test_end': spec['test_end']}, ensure_ascii=False, indent=2))
                print('=' * 60)
                row = run_one_fold(data=data, feature_cols=feature_cols, cfg=cfg_c, fold_spec=spec, fold_dir=fold_dir, horizon=int(horizon))
                row['cycle_name'] = cycle_name
                row['train_days'] = int(cfg_c.train_days)
                row['valid_days'] = int(cfg_c.valid_days)
                row['test_days'] = int(cfg_c.test_days)
                row['warmup_days'] = int(cfg_c.warmup_days)
                rows = [r for r in rows if not (r['cycle_name'] == cycle_name and r['horizon'] == int(horizon) and r['fold'] == row['fold'])]
                rows.append(row)
                write_cycle_summary(out_root, rows, build_large_files=False)
                cleanup_memory()
            try:
                del fold_specs
            except Exception:
                pass
            cleanup_memory()
        try:
            del data, feature_cols, prep_meta
        except Exception:
            pass
        cleanup_memory()
    final_rows = []
    for hz_dir in sorted(out_root.glob('horizon_*')):
        h = int(hz_dir.name.split('_')[-1])
        for cycle_dir in sorted(hz_dir.iterdir()):
            if not cycle_dir.is_dir():
                continue
            cycle_name = cycle_dir.name
            for fold_dir in sorted(cycle_dir.glob('fold_*')):
                row = load_fold_row(fold_dir, cycle_name, h)
                if row is not None:
                    final_rows.append(row)
    write_cycle_summary(out_root, final_rows, build_large_files=True)
    log_time(f'V15.4 independent reward 10fold 完成 | 结果目录: {out_root}')


if __name__ == '__main__':
    main()
