from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm


@dataclass
class BacktestConfig:
    initial_cash: float = 100000.0
    board_lot: int = 100
    max_entry_price: float = 40.0
    topk: int = 1
    threshold: float = 0.6
    full_position: bool = True
    horizon: int = 3
    max_positions: int = 3
    require_breakout_candidate: bool = True


def _calc_max_shares_by_cash(cash: float, open_price: float, board_lot: int = 100) -> int:
    if open_price <= 0:
        return 0
    lots = int(cash // (open_price * board_lot))
    return lots * board_lot


def prepare_prediction_table_for_backtest(pred_df: pd.DataFrame, raw_daily_df: pd.DataFrame, horizon: int = 3) -> pd.DataFrame:
    p = pred_df.copy()
    p["date"] = pd.to_datetime(p["date"])

    d = raw_daily_df.copy()
    d["date"] = pd.to_datetime(d["date"])
    d = d.sort_values(["symbol", "date"]).reset_index(drop=True)
    if "tradable_buy" not in d.columns:
        d["tradable_buy"] = 1

    d["entry_date"] = d.groupby("symbol")["date"].shift(-1)
    d["exit_date"] = d.groupby("symbol")["date"].shift(-(1 + horizon))
    d["entry_open"] = d.groupby("symbol")["open"].shift(-1)
    d["exit_open"] = d.groupby("symbol")["open"].shift(-(1 + horizon))
    d["entry_tradable_buy"] = d.groupby("symbol")["tradable_buy"].shift(-1)

    use_cols = [c for c in [
        "symbol", "code", "market", "date", "open", "high", "low", "close",
        "volume", "amount", "tradable_buy", "entry_date", "exit_date", "entry_open",
        "exit_open", "entry_tradable_buy",
    ] if c in d.columns]
    join_keys = [c for c in ["symbol", "code", "date"] if c in p.columns and c in d.columns]
    merged = p.merge(d[use_cols], on=join_keys, how="left", suffixes=("", "_raw"))
    merged["real_trade_ret"] = merged["exit_open"] / merged["entry_open"] - 1.0
    merged = merged.sort_values(["date", "pred_ret"], ascending=[True, False]).reset_index(drop=True)
    return merged


def _build_price_maps(raw_daily_df: pd.DataFrame) -> tuple[Dict[tuple, float], Dict[tuple, float]]:
    d = raw_daily_df.copy()
    d["date"] = pd.to_datetime(d["date"])
    open_map = {(str(r.symbol), pd.Timestamp(r.date)): float(r.open) for r in d.itertuples() if pd.notna(r.open)}
    close_map = {(str(r.symbol), pd.Timestamp(r.date)): float(r.close) for r in d.itertuples() if pd.notna(r.close)}
    return open_map, close_map


def build_backtest_cache(
    pred_df: pd.DataFrame,
    raw_daily_df: pd.DataFrame,
    backtest_cfg: BacktestConfig,
) -> Dict:
    merged = prepare_prediction_table_for_backtest(
        pred_df=pred_df,
        raw_daily_df=raw_daily_df,
        horizon=int(getattr(backtest_cfg, "horizon", 3)),
    )

    if getattr(backtest_cfg, "require_breakout_candidate", True) and "breakout_candidate" in merged.columns:
        merged = merged[merged["breakout_candidate"].fillna(0).astype(int) == 1].copy()

    merged = merged[merged["entry_open"].notna()].copy()
    if "entry_tradable_buy" in merged.columns:
        merged = merged[merged["entry_tradable_buy"].fillna(0) == 1].copy()
    if "entry_open" in merged.columns:
        merged = merged[merged["entry_open"] <= float(getattr(backtest_cfg, "max_entry_price", 40.0))].copy()

    entry_groups: Dict[pd.Timestamp, pd.DataFrame] = {}
    if len(merged):
        merged = merged.sort_values(["entry_date", "pred_ret", "pred_prob_pos"], ascending=[True, False, False]).reset_index(drop=True)
        for entry_dt, g in merged.groupby(pd.to_datetime(merged["entry_date"])):
            entry_groups[pd.Timestamp(entry_dt)] = g.reset_index(drop=True)

    raw_daily_df = raw_daily_df.copy()
    raw_daily_df["date"] = pd.to_datetime(raw_daily_df["date"])
    final_trade_dt = pd.Timestamp(raw_daily_df["date"].max()) if len(raw_daily_df) else pd.NaT

    if len(merged):
        merged = merged[merged["entry_date"].notna()].copy()
        merged = merged[merged["entry_date"] < final_trade_dt].copy()  # test 最后一天不能开仓
        min_signal_dt = pd.Timestamp(merged["date"].min()) if "date" in merged.columns and len(merged) else pd.Timestamp(raw_daily_df["date"].min())
        raw_daily_df = raw_daily_df[(raw_daily_df["date"] >= min_signal_dt) & (raw_daily_df["date"] <= final_trade_dt)].copy()

    all_dates = sorted(raw_daily_df["date"].drop_duplicates())
    open_map, close_map = _build_price_maps(raw_daily_df)
    return {
        "entry_groups": entry_groups,
        "all_dates": all_dates,
        "open_map": open_map,
        "close_map": close_map,
        "raw_daily_df": raw_daily_df,
        "final_trade_dt": final_trade_dt,
    }


def simulate_top1_open_to_next_open_strategy(
    pred_df: pd.DataFrame,
    raw_daily_df: pd.DataFrame,
    backtest_cfg: BacktestConfig,
    show_progress: bool = True,
    prepared_cache: Dict | None = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict]:
    cache = prepared_cache if prepared_cache is not None else build_backtest_cache(
        pred_df=pred_df,
        raw_daily_df=raw_daily_df,
        backtest_cfg=backtest_cfg,
    )

    base_entry_groups = cache["entry_groups"]
    all_dates = cache["all_dates"]
    open_map = cache["open_map"]
    close_map = cache["close_map"]
    final_trade_dt = cache.get("final_trade_dt", all_dates[-1] if len(all_dates) else pd.NaT)

    cash = float(backtest_cfg.initial_cash)
    max_positions = int(max(1, getattr(backtest_cfg, "max_positions", max(1, backtest_cfg.horizon))))
    open_positions: List[Dict] = []
    trade_rows: List[Dict] = []
    equity_curve: List[Dict] = []

    iterator = tqdm(all_dates, desc="Backtesting breakout fold") if show_progress else all_dates

    for dt in iterator:
        dt = pd.Timestamp(dt)

        # Exit at today's open
        remaining_positions = []
        realized_rets = []
        exited_symbols = []
        for pos in open_positions:
            if pd.Timestamp(pos["exit_date"]) == dt:
                exit_open = open_map.get((pos["symbol"], dt), float(pos["planned_exit_open"]))
                sell_value = pos["shares"] * exit_open
                pnl = sell_value - pos["buy_value"]
                cash += sell_value
                trade_ret = pnl / pos["buy_value"] if pos["buy_value"] > 0 else 0.0
                realized_rets.append(trade_ret)
                exited_symbols.append(pos["symbol"])
                trade_rows.append({
                    "signal_date": pd.Timestamp(pos["signal_date"]),
                    "entry_date": pd.Timestamp(pos["entry_date"]),
                    "exit_date": dt,
                    "symbol": pos["symbol"],
                    "code": pos.get("code"),
                    "buy_open": float(pos["buy_open"]),
                    "sell_open": float(exit_open),
                    "shares": int(pos["shares"]),
                    "buy_value": float(pos["buy_value"]),
                    "sell_value": float(sell_value),
                    "pred_ret": float(pos["pred_ret"]),
                    "pred_ret_raw": float(pos.get("pred_ret_raw", np.nan)),
                    "pred_prob_pos": float(pos.get("pred_prob_pos", np.nan)),
                    "pred_score_ret_rank": float(pos.get("pred_ret_rank", np.nan)),
                    "pred_score_prob_rank": float(pos.get("pred_breakout_rank", np.nan)),
                    "true_ret": float(pos.get("true_ret", np.nan)),
                    "true_cls": int(pos.get("true_cls", 0)),
                    "trade_ret": float(trade_ret),
                    "pnl": float(pnl),
                    "breakout_candidate": int(pos.get("breakout_candidate", 0)),
                    "target_breakout_success": int(pos.get("target_breakout_success", 0)),
                    "holding_days": int(pos.get("holding_days", backtest_cfg.horizon)),
                })
            else:
                remaining_positions.append(pos)
        open_positions = remaining_positions

        # Entries at today's open from yesterday's signals
        todays_entries = base_entry_groups.get(dt)
        entered_symbols = []
        if todays_entries is not None and len(todays_entries):
            todays_entries = todays_entries[todays_entries["pred_ret"] > float(backtest_cfg.threshold)].copy()
            if len(todays_entries):
                todays_entries = todays_entries.head(int(backtest_cfg.topk)).copy()
            capacity = max(0, max_positions - len(open_positions))
            if capacity > 0 and len(todays_entries):
                todays_entries = todays_entries.head(capacity).copy()
                per_trade_cash = cash / max(len(todays_entries), 1)
                for _, pick in todays_entries.iterrows():
                    symbol = str(pick.get("symbol"))
                    entry_open = open_map.get((symbol, dt), float(pick["entry_open"]))
                    shares = _calc_max_shares_by_cash(per_trade_cash, entry_open, backtest_cfg.board_lot)
                    if shares <= 0:
                        continue
                    buy_value = shares * entry_open
                    if buy_value > cash:
                        continue
                    cash -= buy_value
                    open_positions.append({
                        "signal_date": pd.Timestamp(pick["date"]),
                        "entry_date": dt,
                        "exit_date": pd.Timestamp(pick["exit_date"]),
                        "symbol": symbol,
                        "code": pick.get("code"),
                        "shares": int(shares),
                        "buy_open": float(entry_open),
                        "buy_value": float(buy_value),
                        "planned_exit_open": float(pick["exit_open"]),
                        "pred_ret": float(pick["pred_ret"]),
                        "pred_ret_raw": float(pick.get("pred_ret_raw", np.nan)),
                        "pred_prob_pos": float(pick.get("pred_prob_pos", np.nan)),
                        "pred_ret_rank": float(pick.get("pred_ret_rank", np.nan)),
                        "pred_breakout_rank": float(pick.get("pred_breakout_rank", np.nan)),
                        "true_ret": float(pick.get("real_trade_ret", np.nan)),
                        "true_cls": int(pick.get("true_cls", 0)),
                        "breakout_candidate": int(pick.get("breakout_candidate", 0)),
                        "target_breakout_success": int(pick.get("target_breakout_success", 0)),
                        "holding_days": int(backtest_cfg.horizon),
                    })
                    entered_symbols.append(symbol)

        # Mark-to-close equity
        mtm_value = 0.0
        for pos in open_positions:
            px = close_map.get((pos["symbol"], dt), pos["buy_open"])
            mtm_value += pos["shares"] * px

        equity = cash + mtm_value
        equity_curve.append({
            "date": dt,
            "cash": float(cash),
            "equity": float(equity),
            "position_value": float(mtm_value),
            "n_open_positions": int(len(open_positions)),
            "entered_symbols": ";".join(entered_symbols) if entered_symbols else None,
            "exited_symbols": ";".join(exited_symbols) if exited_symbols else None,
            "realized_ret": float(np.nanmean(realized_rets)) if realized_rets else 0.0,
            "trade_flag": int(bool(entered_symbols or exited_symbols)),
        })

    # test 阶段结束时若仍持仓，则按最后一天收盘强制卖出
    if len(open_positions):
        forced_rets = []
        forced_symbols = []
        for pos in open_positions:
            exit_px = close_map.get((pos["symbol"], pd.Timestamp(final_trade_dt)), pos["buy_open"])
            sell_value = pos["shares"] * exit_px
            pnl = sell_value - pos["buy_value"]
            cash += sell_value
            trade_ret = pnl / pos["buy_value"] if pos["buy_value"] > 0 else 0.0
            forced_rets.append(trade_ret)
            forced_symbols.append(pos["symbol"])
            trade_rows.append({
                "signal_date": pd.Timestamp(pos["signal_date"]),
                "entry_date": pd.Timestamp(pos["entry_date"]),
                "exit_date": pd.Timestamp(final_trade_dt),
                "symbol": pos["symbol"],
                "code": pos.get("code"),
                "buy_open": float(pos["buy_open"]),
                "sell_open": float(exit_px),
                "shares": int(pos["shares"]),
                "buy_value": float(pos["buy_value"]),
                "sell_value": float(sell_value),
                "pred_ret": float(pos["pred_ret"]),
                "pred_ret_raw": float(pos.get("pred_ret_raw", np.nan)),
                "pred_prob_pos": float(pos.get("pred_prob_pos", np.nan)),
                "pred_score_ret_rank": float(pos.get("pred_ret_rank", np.nan)),
                "pred_score_prob_rank": float(pos.get("pred_breakout_rank", np.nan)),
                "true_ret": float(pos.get("true_ret", np.nan)),
                "true_cls": int(pos.get("true_cls", 0)),
                "trade_ret": float(trade_ret),
                "pnl": float(pnl),
                "breakout_candidate": int(pos.get("breakout_candidate", 0)),
                "target_breakout_success": int(pos.get("target_breakout_success", 0)),
                "holding_days": int(pos.get("holding_days", backtest_cfg.horizon)),
                "forced_exit_end_of_test": 1,
            })
        open_positions = []
        equity_curve.append({
            "date": pd.Timestamp(final_trade_dt),
            "cash": float(cash),
            "equity": float(cash),
            "position_value": 0.0,
            "n_open_positions": 0,
            "entered_symbols": None,
            "exited_symbols": ";".join(forced_symbols) if forced_symbols else None,
            "realized_ret": float(np.nanmean(forced_rets)) if forced_rets else 0.0,
            "trade_flag": int(bool(forced_symbols)),
        })

    equity_df = pd.DataFrame(equity_curve)
    trades_df = pd.DataFrame(trade_rows)
    if len(equity_df):
        equity_df["cummax_equity"] = equity_df["equity"].cummax()
        equity_df["drawdown"] = equity_df["equity"] / equity_df["cummax_equity"] - 1.0
        equity_df["daily_equity_ret"] = equity_df["equity"].pct_change().fillna(0.0)
    else:
        equity_df = pd.DataFrame(columns=["date", "cash", "equity", "position_value", "n_open_positions", "entered_symbols", "exited_symbols", "realized_ret", "trade_flag", "cummax_equity", "drawdown", "daily_equity_ret"])

    stat = summarize_backtest_result(equity_df=equity_df, trades_df=trades_df, initial_cash=backtest_cfg.initial_cash)
    stat["horizon"] = int(getattr(backtest_cfg, "horizon", 3))
    stat["topk"] = int(backtest_cfg.topk)
    stat["threshold"] = float(backtest_cfg.threshold)
    stat["max_positions"] = int(max_positions)
    return equity_df, trades_df, stat


def summarize_backtest_result(equity_df: pd.DataFrame, trades_df: pd.DataFrame, initial_cash: float) -> Dict:
    if len(equity_df) == 0:
        return {"initial_cash": float(initial_cash), "final_equity": float(initial_cash), "total_return": 0.0, "max_drawdown": 0.0, "n_days": 0, "n_trades": 0, "win_rate": 0.0, "avg_trade_ret": 0.0, "sum_pnl": 0.0}
    final_equity = float(equity_df["equity"].iloc[-1])
    total_return = final_equity / initial_cash - 1.0
    max_drawdown = float(equity_df["drawdown"].min()) if "drawdown" in equity_df.columns else 0.0
    if len(trades_df) > 0:
        win_rate = float((trades_df["trade_ret"] > 0).mean())
        avg_trade_ret = float(trades_df["trade_ret"].mean())
        sum_pnl = float(trades_df["pnl"].sum())
    else:
        win_rate = 0.0
        avg_trade_ret = 0.0
        sum_pnl = 0.0
    return {"initial_cash": float(initial_cash), "final_equity": final_equity, "total_return": float(total_return), "max_drawdown": float(max_drawdown), "n_days": int(len(equity_df)), "n_trades": int(len(trades_df)), "win_rate": float(win_rate), "avg_trade_ret": float(avg_trade_ret), "sum_pnl": float(sum_pnl)}


def evaluate_topk_signal_quality(pred_df: pd.DataFrame, topk: int = 1, threshold: float = 0.6) -> Dict:
    df = pred_df.copy()
    df["date"] = pd.to_datetime(df["date"])
    if "breakout_candidate" in df.columns:
        df = df[df["breakout_candidate"].fillna(0).astype(int) == 1].copy()
    df = df[df["pred_ret"] > float(threshold)].copy()
    picks = []
    for _, g in df.groupby("date"):
        picks.append(g.sort_values("pred_ret", ascending=False).head(topk))
    if not picks:
        return {
            "n_days": 0, "n_picks": 0, "avg_true_ret": 0.0, "win_rate": 0.0,
            "sum_true_ret": 0.0, "hit_rate": 0.0, "avg_true_ret_success_only": 0.0,
        }
    out = pd.concat(picks, axis=0, ignore_index=True)
    true_col = "true_ret" if "true_ret" in out.columns else "pred_ret"
    cls_col = "true_cls" if "true_cls" in out.columns else None
    hit_rate = float(out[cls_col].mean()) if cls_col is not None and len(out) else 0.0
    success_only = out.loc[out[true_col] > 0, true_col]
    return {
        "n_days": int(out["date"].nunique()),
        "n_picks": int(len(out)),
        "avg_true_ret": float(out[true_col].mean()),
        "win_rate": float((out[true_col] > 0).mean()),
        "sum_true_ret": float(out[true_col].sum()),
        "hit_rate": hit_rate,
        "avg_true_ret_success_only": float(success_only.mean()) if len(success_only) else 0.0,
    }
