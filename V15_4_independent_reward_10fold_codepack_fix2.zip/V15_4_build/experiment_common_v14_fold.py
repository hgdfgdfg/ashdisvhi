from __future__ import annotations

import gc
import json
import math
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

import ashare_v14_fold as v14

try:
    import torch
except Exception:
    torch = None

from ashare_backtest import prepare_prediction_table_for_backtest


def log_time(msg: str) -> None:
    print(f"[time] {time.strftime('%Y-%m-%d %H:%M:%S')} | {msg}")


def cleanup_memory() -> None:
    gc.collect()
    if torch is not None and getattr(torch, 'cuda', None) is not None and torch.cuda.is_available():
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def build_rolling_fold_specs(data: pd.DataFrame, cfg, num_folds: int = 10, fold_stride_days: int | None = None) -> List[Dict]:
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    fold_stride_days = int(fold_stride_days or cfg.test_days)
    need = int(cfg.train_days + cfg.valid_days + cfg.test_days)
    if len(all_dates) < need:
        raise RuntimeError(f'可用交易日不足，当前={len(all_dates)}, 需要至少={need}')
    specs = []
    end_exclusive = len(all_dates)
    for i in range(num_folds):
        start_idx = end_exclusive - need
        if start_idx < 0:
            break
        fold_dates = all_dates[start_idx:end_exclusive]
        train_dates = fold_dates[: cfg.train_days]
        valid_dates = fold_dates[cfg.train_days : cfg.train_days + cfg.valid_days]
        test_dates = fold_dates[cfg.train_days + cfg.valid_days :]
        if len(train_dates) < cfg.train_days or len(valid_dates) < cfg.valid_days or len(test_dates) < cfg.test_days:
            break
        specs.append(
            {
                'fold': num_folds - i,
                'train_dates': train_dates,
                'valid_dates': valid_dates,
                'test_dates': test_dates,
                'train_start': str(min(train_dates).date()),
                'train_end': str(max(train_dates).date()),
                'valid_start': str(min(valid_dates).date()),
                'valid_end': str(max(valid_dates).date()),
                'test_start': str(min(test_dates).date()),
                'test_end': str(max(test_dates).date()),
            }
        )
        end_exclusive -= fold_stride_days
    specs.reverse()
    for i, spec in enumerate(specs, start=1):
        spec['fold'] = i
    return specs


def _build_warmup_slice(data: pd.DataFrame, target_dates: List[pd.Timestamp], all_dates: List[pd.Timestamp], warmup_days: int) -> pd.DataFrame:
    if len(target_dates) == 0:
        return data.iloc[0:0].copy()
    first_dt = pd.Timestamp(min(target_dates))
    first_idx = all_dates.index(first_dt)
    start_idx = max(0, first_idx - int(warmup_days))
    use_dates = all_dates[start_idx:first_idx] + list(target_dates)
    out = data[data['date'].isin(use_dates)].copy()
    return out.sort_values(['symbol', 'date']).reset_index(drop=True)


def _add_v15_future_stats(merged: pd.DataFrame, raw_df: pd.DataFrame, horizons=(3, 5, 10), early_days=(1, 2, 3)) -> pd.DataFrame:
    if merged is None or merged.empty:
        return pd.DataFrame()
    raw = raw_df.copy()
    raw['date'] = pd.to_datetime(raw['date'])
    raw = raw.sort_values(['symbol', 'date']).reset_index(drop=True)
    cal = {str(sym): g.reset_index(drop=True) for sym, g in raw.groupby('symbol', sort=False)}
    out = merged.copy()
    out['date'] = pd.to_datetime(out['date'])
    out['entry_date'] = pd.to_datetime(out['entry_date'])
    for h in horizons:
        maxups = []
        maxdowns = []
        dayofmax = []
        for r in out.itertuples(index=False):
            sym = str(r.symbol)
            ent = pd.Timestamp(r.entry_date)
            g = cal.get(sym)
            if g is None or g.empty or pd.isna(ent):
                maxups.append(np.nan); maxdowns.append(np.nan); dayofmax.append(np.nan); continue
            idxs = g.index[g['date'] == ent].tolist()
            if not idxs:
                maxups.append(np.nan); maxdowns.append(np.nan); dayofmax.append(np.nan); continue
            i0 = idxs[0]
            win = g.iloc[i0 : i0 + h].copy()
            entry_open = float(getattr(r, 'entry_open', np.nan)) if pd.notna(getattr(r, 'entry_open', np.nan)) else np.nan
            if win.empty or not np.isfinite(entry_open) or entry_open <= 0:
                maxups.append(np.nan); maxdowns.append(np.nan); dayofmax.append(np.nan); continue
            rel_high = pd.to_numeric(win['high'], errors='coerce') / entry_open - 1.0
            rel_low = pd.to_numeric(win['low'], errors='coerce') / entry_open - 1.0
            maxups.append(float(rel_high.max()))
            maxdowns.append(float(rel_low.min()))
            try:
                dayofmax.append(int(rel_high.values.argmax()) + 1)
            except Exception:
                dayofmax.append(np.nan)
        out[f'true_max_up_{h}'] = maxups
        out[f'true_max_down_{h}'] = maxdowns
        out[f'day_of_max_up_{h}'] = dayofmax
        for th in (0.05, 0.08, 0.10):
            key = int(round(th * 100))
            out[f'hit_{key}_{h}'] = (pd.to_numeric(out[f'true_max_up_{h}'], errors='coerce') >= th).astype(int)
    # 买后 1~3 天强反馈
    for d in early_days:
        rets = []
        maxups = []
        maxdowns = []
        for r in out.itertuples(index=False):
            sym = str(r.symbol)
            ent = pd.Timestamp(r.entry_date)
            g = cal.get(sym)
            if g is None or g.empty or pd.isna(ent):
                rets.append(np.nan); maxups.append(np.nan); maxdowns.append(np.nan); continue
            idxs = g.index[g['date'] == ent].tolist()
            if not idxs:
                rets.append(np.nan); maxups.append(np.nan); maxdowns.append(np.nan); continue
            i0 = idxs[0]
            win = g.iloc[i0 : i0 + d].copy()
            entry_open = float(getattr(r, 'entry_open', np.nan)) if pd.notna(getattr(r, 'entry_open', np.nan)) else np.nan
            if win.empty or not np.isfinite(entry_open) or entry_open <= 0:
                rets.append(np.nan); maxups.append(np.nan); maxdowns.append(np.nan); continue
            close_d = float(pd.to_numeric(win['close'], errors='coerce').iloc[-1])
            rets.append(close_d / entry_open - 1.0 if np.isfinite(close_d) else np.nan)
            maxups.append(float((pd.to_numeric(win['high'], errors='coerce') / entry_open - 1.0).max()))
            maxdowns.append(float((pd.to_numeric(win['low'], errors='coerce') / entry_open - 1.0).min()))
        out[f'post_day{d}_ret'] = rets
        out[f'post_{d}d_max_up'] = maxups
        out[f'post_{d}d_max_down'] = maxdowns
    return out


def _add_pretrade_features(merged: pd.DataFrame, raw_df: pd.DataFrame) -> pd.DataFrame:
    if merged is None or merged.empty:
        return pd.DataFrame()
    raw = raw_df.copy()
    raw['date'] = pd.to_datetime(raw['date'])
    raw = raw.sort_values(['symbol', 'date']).reset_index(drop=True)
    cal = {str(sym): g.reset_index(drop=True) for sym, g in raw.groupby('symbol', sort=False)}
    out = merged.copy()
    out['entry_date'] = pd.to_datetime(out['entry_date'])
    pre3 = []; pre5 = []; pre10 = []; pre5vol = []; gap = []; prev_close_list = []
    for r in out.itertuples(index=False):
        sym = str(r.symbol)
        ent = pd.Timestamp(r.entry_date)
        g = cal.get(sym)
        if g is None or g.empty or pd.isna(ent):
            pre3.append(np.nan); pre5.append(np.nan); pre10.append(np.nan); pre5vol.append(np.nan); gap.append(np.nan); prev_close_list.append(np.nan); continue
        idxs = g.index[g['date'] == ent].tolist()
        if not idxs:
            pre3.append(np.nan); pre5.append(np.nan); pre10.append(np.nan); pre5vol.append(np.nan); gap.append(np.nan); prev_close_list.append(np.nan); continue
        i0 = idxs[0]
        prev_i = i0 - 1
        if prev_i < 0:
            pre3.append(np.nan); pre5.append(np.nan); pre10.append(np.nan); pre5vol.append(np.nan); gap.append(np.nan); prev_close_list.append(np.nan); continue
        prev_close = float(pd.to_numeric(g.loc[prev_i, 'close'], errors='coerce'))
        prev_close_list.append(prev_close)
        entry_open = float(getattr(r, 'entry_open', np.nan)) if pd.notna(getattr(r, 'entry_open', np.nan)) else np.nan
        gap.append(entry_open / prev_close - 1.0 if np.isfinite(entry_open) and np.isfinite(prev_close) and prev_close > 0 else np.nan)
        def _ret(n: int):
            start_i = max(0, i0 - n)
            base_close = float(pd.to_numeric(g.loc[start_i, 'close'], errors='coerce'))
            return prev_close / base_close - 1.0 if np.isfinite(base_close) and base_close > 0 else np.nan
        pre3.append(_ret(3)); pre5.append(_ret(5)); pre10.append(_ret(10))
        closes = pd.to_numeric(g.loc[max(0, i0 - 5):prev_i, 'close'], errors='coerce')
        if len(closes) >= 2:
            pre5vol.append(float(closes.pct_change().std()))
        else:
            pre5vol.append(np.nan)
    out['pre_3d_ret'] = pre3
    out['pre_5d_ret'] = pre5
    out['pre_10d_ret'] = pre10
    out['pre_5d_volatility'] = pre5vol
    out['entry_gap_vs_prev_close'] = gap
    out['prev_close'] = prev_close_list
    return out



def _build_kline_windows(top_df: pd.DataFrame, raw_df: pd.DataFrame, pre_days: int = 10, post_days: int = 10, horizon: int = 10, role_map: dict | None = None) -> pd.DataFrame:
    if top_df is None or top_df.empty:
        return pd.DataFrame()
    raw = raw_df.copy()
    raw['date'] = pd.to_datetime(raw['date'])
    raw = raw.sort_values(['symbol', 'date']).reset_index(drop=True)
    cal = {str(sym): g.reset_index(drop=True) for sym, g in raw.groupby('symbol', sort=False)}
    rows = []
    role_map = role_map or {}
    for r in top_df.itertuples(index=False):
        sym = str(r.symbol)
        g = cal.get(sym)
        if g is None or g.empty:
            continue
        ent = pd.Timestamp(r.entry_date)
        idxs = g.index[g['date'] == ent].tolist()
        if not idxs:
            continue
        i0 = idxs[0]
        start = max(0, i0 - pre_days)
        end = min(len(g), i0 + horizon + post_days)
        window = g.iloc[start:end].copy().reset_index(drop=True)
        entry_open = float(getattr(r, 'entry_open', np.nan)) if pd.notna(getattr(r, 'entry_open', np.nan)) else np.nan
        key = (str(pd.Timestamp(getattr(r, 'date')).date()), sym)
        role = role_map.get(key, 'top10')
        for j, rr in window.iterrows():
            rel = int(j - (i0 - start))
            phase = 'pre' if rel < 0 else ('hold' if rel < horizon else 'post')
            rows.append({
                'symbol': sym,
                'code': getattr(r, 'code', ''),
                'signal_date': getattr(r, 'date', pd.NaT),
                'entry_date': ent,
                'phase': phase,
                'window_date': rr['date'],
                'rel_day_to_entry': rel,
                'open': rr.get('open'),
                'high': rr.get('high'),
                'low': rr.get('low'),
                'close': rr.get('close'),
                'volume': rr.get('volume'),
                'amount': rr.get('amount'),
                'is_entry_day': int(pd.Timestamp(rr['date']) == ent),
                'ret_vs_entry_open': float(rr['close'] / entry_open - 1.0) if pd.notna(entry_open) and entry_open > 0 and pd.notna(rr['close']) else np.nan,
                'pred_rank': getattr(r, 'pred_rank', np.nan),
                'rerank_rank': getattr(r, 'rerank_rank', np.nan),
                'pred_ret': getattr(r, 'pred_ret', np.nan),
                'pred_prob_pos': getattr(r, 'pred_prob_pos', np.nan),
                'true_max_up_5': getattr(r, 'true_max_up_5', np.nan),
                'role': role,
            })
    return pd.DataFrame(rows)




import duckdb
from tqdm import tqdm


def _normalize_symbol(x) -> str:
    s = str(x)
    m = ''.join(ch for ch in s if ch.isdigit())
    return m.zfill(6) if m else s.strip()


def load_benchmark_daily_from_duckdb(cfg) -> pd.DataFrame:
    log_time(f"读取 benchmark 开始 | symbol={getattr(cfg, 'benchmark_symbol', 'sh000001')}")
    con = duckdb.connect(cfg.db_path)
    try:
        schema_name, target, cols = v14._choose_best_relation(con, cfg)
        rel = v14._safe_ident(schema_name, target)
        exprs = v14._build_required_exprs(cols)
        symbol_expr = exprs['symbol'].split(' AS symbol')[0]
        sql = f"""
            SELECT
                {exprs['date']},
                {exprs['open']},
                {exprs['high']},
                {exprs['low']},
                {exprs['close']},
                {exprs['volume']},
                {symbol_expr} AS bench_symbol
            FROM {rel}
            ORDER BY 1
        """
        df = con.execute(sql).fetchdf()
    finally:
        con.close()
    df['date'] = pd.to_datetime(df['date'])
    df['bench_symbol'] = df['bench_symbol'].astype(str).map(_normalize_symbol)
    target_symbol = _normalize_symbol(getattr(cfg, 'benchmark_symbol', 'sh000001'))
    df = df[df['bench_symbol'] == target_symbol].copy()
    if df.empty:
        raise RuntimeError(f"DuckDB 中未找到 benchmark_symbol={target_symbol} 的日线数据")
    for c in ['open', 'high', 'low', 'close', 'volume']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.dropna(subset=['date', 'open', 'high', 'low', 'close']).sort_values('date').reset_index(drop=True)
    df['benchmark_prev_close'] = df['close'].shift(1)
    df['benchmark_ret_1d'] = df['close'] / df['benchmark_prev_close'] - 1.0
    df['benchmark_ret_3d'] = df['close'] / df['close'].shift(3) - 1.0
    df['benchmark_ret_5d'] = df['close'] / df['close'].shift(5) - 1.0
    df = df.rename(columns={
        'open': 'benchmark_open',
        'high': 'benchmark_high',
        'low': 'benchmark_low',
        'close': 'benchmark_close',
        'volume': 'benchmark_volume',
    })
    keep = ['date', 'benchmark_open', 'benchmark_high', 'benchmark_low', 'benchmark_close', 'benchmark_volume', 'benchmark_prev_close', 'benchmark_ret_1d', 'benchmark_ret_3d', 'benchmark_ret_5d']
    log_time(f"读取 benchmark 完成 | rows={len(df)}")
    return df[keep].copy()


def attach_benchmark_features(stock_df: pd.DataFrame, benchmark_df: pd.DataFrame) -> pd.DataFrame:
    log_time('合并 benchmark 特征 开始')
    out = stock_df.merge(benchmark_df, on='date', how='left')
    miss = float(out['benchmark_close'].isna().mean()) if 'benchmark_close' in out.columns and len(out) else 0.0
    log_time(f'合并 benchmark 特征 完成 | missing_ratio={miss:.6f}')
    return out


def build_independent_market_features(df: pd.DataFrame, cfg) -> pd.DataFrame:
    log_time('构建独立行情特征 开始')
    out = df.copy()
    out = out.sort_values(['symbol', 'date']).reset_index(drop=True)
    g = out.groupby('symbol', sort=False)
    out['stock_ret_1d'] = pd.to_numeric(out['close'], errors='coerce') / g['close'].shift(1) - 1.0
    out['stock_ret_3d'] = pd.to_numeric(out['close'], errors='coerce') / g['close'].shift(3) - 1.0
    out['stock_ret_5d'] = pd.to_numeric(out['close'], errors='coerce') / g['close'].shift(5) - 1.0
    out['excess_ret_1d'] = pd.to_numeric(out['stock_ret_1d'], errors='coerce') - pd.to_numeric(out['benchmark_ret_1d'], errors='coerce')
    out['excess_ret_3d'] = pd.to_numeric(out['stock_ret_3d'], errors='coerce') - pd.to_numeric(out['benchmark_ret_3d'], errors='coerce')
    out['excess_ret_5d'] = pd.to_numeric(out['stock_ret_5d'], errors='coerce') - pd.to_numeric(out['benchmark_ret_5d'], errors='coerce')
    out['indep_up_vs_down'] = (
        (pd.to_numeric(out['benchmark_ret_1d'], errors='coerce') <= float(getattr(cfg, 'index_down_th', -0.005))) &
        (pd.to_numeric(out['stock_ret_1d'], errors='coerce') >= float(getattr(cfg, 'stock_up_th', 0.01)))
    ).astype(int)
    out['indep_days_3'] = g['indep_up_vs_down'].transform(lambda s: s.rolling(3, min_periods=1).sum())
    cap1 = max(float(getattr(cfg, 'relative_strength_cap_1d', 0.05)), 1e-6)
    cap5 = max(float(getattr(cfg, 'relative_strength_cap_5d', 0.10)), 1e-6)
    out['excess_ret_1d_clip'] = pd.to_numeric(out['excess_ret_1d'], errors='coerce').clip(lower=0.0, upper=cap1) / cap1
    out['excess_ret_5d_clip'] = pd.to_numeric(out['excess_ret_5d'], errors='coerce').clip(lower=0.0, upper=cap5) / cap5
    out['indep_days_3_norm'] = pd.to_numeric(out['indep_days_3'], errors='coerce').fillna(0.0).clip(lower=0.0, upper=3.0) / 3.0
    log_time('构建独立行情特征 完成')
    return out


def build_close5_prob_metrics(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = out.sort_values(['symbol', 'date']).reset_index(drop=True)
    g = out.groupby('symbol', sort=False)
    out['close_t_plus_5'] = g['close'].shift(-5)
    out['open_t_plus_1'] = g['open'].shift(-1)
    out['ret_close5_vs_open_t'] = pd.to_numeric(out['close_t_plus_5'], errors='coerce') / pd.to_numeric(out['open'], errors='coerce') - 1.0
    out['ret_close5_vs_open_t1'] = pd.to_numeric(out['close_t_plus_5'], errors='coerce') / pd.to_numeric(out['open_t_plus_1'], errors='coerce') - 1.0
    out['hit_close5_open_t_8'] = (pd.to_numeric(out['ret_close5_vs_open_t'], errors='coerce') >= 0.08).astype(int)
    out['hit_close5_open_t_10'] = (pd.to_numeric(out['ret_close5_vs_open_t'], errors='coerce') >= 0.10).astype(int)
    out['hit_close5_open_t1_8'] = (pd.to_numeric(out['ret_close5_vs_open_t1'], errors='coerce') >= 0.08).astype(int)
    out['hit_close5_open_t1_10'] = (pd.to_numeric(out['ret_close5_vs_open_t1'], errors='coerce') >= 0.10).astype(int)
    return out


def build_v15_4_reward_addon(df: pd.DataFrame, cfg) -> pd.DataFrame:
    w = getattr(cfg, 'reward_weights', {}) or {}
    out = df.copy()
    out['reward_addon'] = (
        float(w.get('indep_up_vs_down', 0.03)) * pd.to_numeric(out['indep_up_vs_down'], errors='coerce').fillna(0.0)
        + float(w.get('excess_ret_1d', 0.04)) * pd.to_numeric(out['excess_ret_1d_clip'], errors='coerce').fillna(0.0)
        + float(w.get('indep_days_3', 0.03)) * pd.to_numeric(out['indep_days_3_norm'], errors='coerce').fillna(0.0)
        + float(w.get('excess_ret_5', 0.04)) * pd.to_numeric(out['excess_ret_5d_clip'], errors='coerce').fillna(0.0)
    )
    return out


def build_v15_4_reward_score_within_topn(day_df: pd.DataFrame, cfg) -> pd.DataFrame:
    out = day_df.sort_values(['baseline_score', 'pred_rank'], ascending=[False, True]).copy()
    out['reward_score'] = pd.to_numeric(out['baseline_score'], errors='coerce')
    topn = min(int(getattr(cfg, 'reward_rerank_topn', 10)), len(out))
    if topn > 0:
        idx = out.index[:topn]
        out.loc[idx, 'reward_score'] = pd.to_numeric(out.loc[idx, 'baseline_score'], errors='coerce').fillna(0.0) + pd.to_numeric(out.loc[idx, 'reward_addon'], errors='coerce').fillna(0.0)
    out['reward_rank'] = out['reward_score'].rank(method='first', ascending=False)
    out['reward_selected'] = (out['reward_rank'] == 1).astype(int)
    return out.sort_values(['reward_rank', 'pred_rank'])


def _extract_pick_metrics(rec: pd.Series, prefix: str) -> dict:
    return {
        f'{prefix}_symbol': rec.get('symbol'),
        f'{prefix}_code': rec.get('code'),
        f'{prefix}_pred_rank': rec.get('pred_rank'),
        f'{prefix}_pred_ret': rec.get('pred_ret'),
        f'{prefix}_pred_prob_pos': rec.get('pred_prob_pos'),
        f'{prefix}_baseline_score': rec.get('baseline_score'),
        f'{prefix}_reward_addon': rec.get('reward_addon'),
        f'{prefix}_reward_score': rec.get('reward_score'),
        f'{prefix}_true_max_up_5': rec.get('true_max_up_5'),
        f'{prefix}_hit8_5': rec.get('hit_8_5'),
        f'{prefix}_hit10_5': rec.get('hit_10_5'),
        f'{prefix}_post_day1_ret': rec.get('post_day1_ret'),
        f'{prefix}_post_day2_ret': rec.get('post_day2_ret'),
        f'{prefix}_post_day3_ret': rec.get('post_day3_ret'),
        f'{prefix}_ret_close5_vs_open_t': rec.get('ret_close5_vs_open_t'),
        f'{prefix}_hit_close5_open_t_8': rec.get('hit_close5_open_t_8'),
        f'{prefix}_hit_close5_open_t_10': rec.get('hit_close5_open_t_10'),
        f'{prefix}_ret_close5_vs_open_t1': rec.get('ret_close5_vs_open_t1'),
        f'{prefix}_hit_close5_open_t1_8': rec.get('hit_close5_open_t1_8'),
        f'{prefix}_hit_close5_open_t1_10': rec.get('hit_close5_open_t1_10'),
        f'{prefix}_indep_up_vs_down': rec.get('indep_up_vs_down'),
        f'{prefix}_excess_ret_1d': rec.get('excess_ret_1d'),
        f'{prefix}_excess_ret_5d': rec.get('excess_ret_5d'),
        f'{prefix}_indep_days_3': rec.get('indep_days_3'),
    }


def _ensure_daily_pred_rank(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return df.copy() if isinstance(df, pd.DataFrame) else pd.DataFrame()
    out = df.copy()
    if 'baseline_score' not in out.columns:
        if 'pred_ret' in out.columns:
            out['baseline_score'] = pd.to_numeric(out['pred_ret'], errors='coerce')
        else:
            out['baseline_score'] = np.nan
    if 'date' not in out.columns:
        return out
    if 'pred_rank' not in out.columns:
        out['pred_rank'] = out.groupby('date')['baseline_score'].rank(method='first', ascending=False)
    else:
        miss = out['pred_rank'].isna()
        if miss.any():
            out.loc[miss, 'pred_rank'] = out.loc[miss].groupby('date')['baseline_score'].rank(method='first', ascending=False)
    out['pred_rank'] = pd.to_numeric(out['pred_rank'], errors='coerce').astype('Int64')
    return out


def make_v15_4_compare_row(trade_date, baseline_pick: pd.Series, reward_pick: pd.Series, best_pick: pd.Series, day_df: pd.DataFrame) -> dict:
    row = {
        'signal_date': trade_date,
        'topn_pool_size': int(len(day_df)),
        'benchmark_ret_1d': baseline_pick.get('benchmark_ret_1d', np.nan),
        'same_pick_flag': int(str(baseline_pick.get('symbol')) == str(reward_pick.get('symbol'))),
        'reward_better_than_baseline_maxup5': int(pd.notna(reward_pick.get('true_max_up_5')) and pd.notna(baseline_pick.get('true_max_up_5')) and float(reward_pick.get('true_max_up_5')) > float(baseline_pick.get('true_max_up_5'))),
        'best_symbol_in_top_pool': best_pick.get('symbol'),
        'best_true_max_up_5_in_pool': best_pick.get('true_max_up_5'),
    }
    row.update(_extract_pick_metrics(baseline_pick, 'baseline_top1'))
    row.update(_extract_pick_metrics(reward_pick, 'reward_top1'))
    return row


def _safe_mean(df: pd.DataFrame, col: str):
    if df is None or df.empty or col not in df.columns:
        return np.nan
    return float(pd.to_numeric(df[col], errors='coerce').mean())


def summarize_v15_4_daily_compare(daily_df: pd.DataFrame) -> pd.DataFrame:
    if daily_df is None or daily_df.empty:
        return pd.DataFrame([{}])
    s = {
        'baseline_top1_avg_true_max_up_5': _safe_mean(daily_df, 'baseline_top1_true_max_up_5'),
        'baseline_top1_hit8_rate_5': _safe_mean(daily_df, 'baseline_top1_hit8_5'),
        'baseline_top1_hit10_rate_5': _safe_mean(daily_df, 'baseline_top1_hit10_5'),
        'baseline_top1_close5_open_t_hit8': _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t_8'),
        'baseline_top1_close5_open_t_hit10': _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t_10'),
        'baseline_top1_close5_open_t1_hit8': _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t1_8'),
        'baseline_top1_close5_open_t1_hit10': _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t1_10'),
        'reward_top1_avg_true_max_up_5': _safe_mean(daily_df, 'reward_top1_true_max_up_5'),
        'reward_top1_hit8_rate_5': _safe_mean(daily_df, 'reward_top1_hit8_5'),
        'reward_top1_hit10_rate_5': _safe_mean(daily_df, 'reward_top1_hit10_5'),
        'reward_top1_close5_open_t_hit8': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t_8'),
        'reward_top1_close5_open_t_hit10': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t_10'),
        'reward_top1_close5_open_t1_hit8': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t1_8'),
        'reward_top1_close5_open_t1_hit10': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t1_10'),
        'same_pick_rate': _safe_mean(daily_df, 'same_pick_flag'),
        'reward_better_maxup5_rate': _safe_mean(daily_df, 'reward_better_than_baseline_maxup5'),
        'delta_hit8_5': _safe_mean(daily_df, 'reward_top1_hit8_5') - _safe_mean(daily_df, 'baseline_top1_hit8_5'),
        'delta_hit10_5': _safe_mean(daily_df, 'reward_top1_hit10_5') - _safe_mean(daily_df, 'baseline_top1_hit10_5'),
        'delta_close5_open_t_hit8': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t_8') - _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t_8'),
        'delta_close5_open_t_hit10': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t_10') - _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t_10'),
        'delta_close5_open_t1_hit8': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t1_8') - _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t1_8'),
        'delta_close5_open_t1_hit10': _safe_mean(daily_df, 'reward_top1_hit_close5_open_t1_10') - _safe_mean(daily_df, 'baseline_top1_hit_close5_open_t1_10'),
        'avg_baseline_post_day1_ret': _safe_mean(daily_df, 'baseline_top1_post_day1_ret'),
        'avg_reward_post_day1_ret': _safe_mean(daily_df, 'reward_top1_post_day1_ret'),
        'avg_baseline_post_day3_ret': _safe_mean(daily_df, 'baseline_top1_post_day3_ret'),
        'avg_reward_post_day3_ret': _safe_mean(daily_df, 'reward_top1_post_day3_ret'),
        'sample_days': int(len(daily_df)),
    }
    return pd.DataFrame([s])


def _build_top10_rank_stats(top10: pd.DataFrame) -> pd.DataFrame:
    if top10 is None or top10.empty:
        return pd.DataFrame()
    rank_df = top10.groupby('pred_rank', as_index=False).agg(
        count=('symbol', 'count'),
        avg_true_max_up_3=('true_max_up_3', 'mean'),
        avg_true_max_up_5=('true_max_up_5', 'mean'),
        avg_true_max_up_10=('true_max_up_10', 'mean'),
        hit8_rate_5=('hit_8_5', 'mean'),
        hit10_rate_5=('hit_10_5', 'mean'),
        close5_open_t_hit8=('hit_close5_open_t_8', 'mean'),
        close5_open_t_hit10=('hit_close5_open_t_10', 'mean'),
        close5_open_t1_hit8=('hit_close5_open_t1_8', 'mean'),
        close5_open_t1_hit10=('hit_close5_open_t1_10', 'mean'),
        avg_post_day1_ret=('post_day1_ret', 'mean'),
        avg_post_day2_ret=('post_day2_ret', 'mean'),
        avg_post_day3_ret=('post_day3_ret', 'mean'),
    )
    return rank_df.sort_values('pred_rank').reset_index(drop=True)


def run_v15_4_compare_outputs(fold_dir: Path, valid_pred: pd.DataFrame, test_pred: pd.DataFrame, raw_df: pd.DataFrame, cfg, horizon: int = 5):
    eval_h = tuple(sorted(set([3, int(horizon), 10])))
    log_time('V15.4 评估开始 | 合并回测字段')
    valid_merged = prepare_prediction_table_for_backtest(valid_pred, raw_df, horizon=horizon)
    test_merged = prepare_prediction_table_for_backtest(test_pred, raw_df, horizon=horizon)
    if len(valid_merged):
        valid_merged = _add_v15_future_stats(valid_merged, raw_df, horizons=eval_h, early_days=(1, 2, 3))
        valid_merged = _add_pretrade_features(valid_merged, raw_df)
        valid_merged = build_close5_prob_metrics(valid_merged)
        valid_merged['baseline_score'] = pd.to_numeric(valid_merged['pred_ret'], errors='coerce')
        valid_merged = _ensure_daily_pred_rank(valid_merged)
    if len(test_merged):
        test_merged = _add_v15_future_stats(test_merged, raw_df, horizons=eval_h, early_days=(1, 2, 3))
        test_merged = _add_pretrade_features(test_merged, raw_df)
        test_merged = build_close5_prob_metrics(test_merged)
        test_merged['baseline_score'] = pd.to_numeric(test_merged['pred_ret'], errors='coerce')
        test_merged = _ensure_daily_pred_rank(test_merged)
        benchmark_df = load_benchmark_daily_from_duckdb(cfg)
        test_merged = attach_benchmark_features(test_merged, benchmark_df)
        test_merged = build_independent_market_features(test_merged, cfg)
        test_merged = build_v15_4_reward_addon(test_merged, cfg)
        del benchmark_df
        cleanup_memory()
    topn = int(getattr(cfg, 'reward_rerank_topn', 10))
    top10 = test_merged[test_merged['pred_rank'] <= topn].copy() if len(test_merged) else pd.DataFrame()
    daily_rows = []
    top_candidates = []
    reward_profile_rows = []
    role_map = {}
    if len(top10):
        iterator = top10.groupby('date', sort=True)
        if getattr(cfg, 'visible_tqdm', True):
            iterator = tqdm(list(iterator), desc='V15.4 baseline vs reward', leave=False)
        for dt, g in iterator:
            g = g.sort_values(['pred_rank', 'baseline_score'], ascending=[True, False]).copy()
            g = build_v15_4_reward_score_within_topn(g, cfg)
            baseline_pick = g.sort_values(['baseline_score', 'pred_rank'], ascending=[False, True]).iloc[0]
            reward_pick = g.sort_values(['reward_score', 'pred_rank'], ascending=[False, True]).iloc[0]
            best_pick = g.sort_values(['true_max_up_5', 'pred_rank'], ascending=[False, True]).iloc[0]
            row = make_v15_4_compare_row(dt, baseline_pick, reward_pick, best_pick, g)
            daily_rows.append(row)
            role_map[(str(pd.Timestamp(dt).date()), str(baseline_pick['symbol']))] = 'baseline_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(reward_pick['symbol']))] = 'reward_top1'
            role_map[(str(pd.Timestamp(dt).date()), str(best_pick['symbol']))] = 'best_top_pool'
            top_candidates.append(g.copy())
            reward_profile_rows.append(g[['date', 'symbol', 'code', 'pred_rank', 'pred_ret', 'pred_prob_pos', 'baseline_score', 'reward_addon', 'reward_score', 'reward_rank', 'indep_up_vs_down', 'excess_ret_1d', 'excess_ret_5d', 'indep_days_3', 'benchmark_ret_1d', 'stock_ret_1d', 'stock_ret_5d', 'true_max_up_5', 'hit_8_5', 'hit_10_5', 'ret_close5_vs_open_t', 'ret_close5_vs_open_t1']].copy())
            del g
        cleanup_memory()
    daily_df = pd.DataFrame(daily_rows)
    rank_df = _build_top10_rank_stats(top10)
    summary_df = summarize_v15_4_daily_compare(daily_df)
    top_candidates_df = pd.concat(top_candidates, ignore_index=True) if top_candidates else pd.DataFrame()
    reward_profile_df = pd.concat(reward_profile_rows, ignore_index=True) if reward_profile_rows else pd.DataFrame()
    kline_df = _build_kline_windows(top10, raw_df, pre_days=int(getattr(cfg, 'kline_pre_days', 10)), post_days=int(getattr(cfg, 'kline_post_days', 10)), horizon=max(eval_h), role_map=role_map)

    valid_merged.to_csv(fold_dir/'valid_pred_v15_4.csv', index=False, encoding='utf-8-sig')
    test_merged.to_csv(fold_dir/'test_pred_v15_4.csv', index=False, encoding='utf-8-sig')
    top10.to_csv(fold_dir/'top_candidates_v15_4_basepool.csv', index=False, encoding='utf-8-sig')
    top_candidates_df.to_csv(fold_dir/'top_candidates_v15_4_compare.csv', index=False, encoding='utf-8-sig')
    daily_df.to_csv(fold_dir/'top1_baseline_vs_reward_daily.csv', index=False, encoding='utf-8-sig')
    rank_df.to_csv(fold_dir/'top10_rank_stats.csv', index=False, encoding='utf-8-sig')
    reward_profile_df.to_csv(fold_dir/'reward_feature_profile_all.csv', index=False, encoding='utf-8-sig')
    kline_df.to_csv(fold_dir/'candidate_kline_windows.csv', index=False, encoding='utf-8-sig')
    summary_payload = {
        'baseline_top1_avg_true_max_up_5': summary_df.iloc[0].get('baseline_top1_avg_true_max_up_5') if len(summary_df) else np.nan,
        'baseline_top1_hit8_rate_5': summary_df.iloc[0].get('baseline_top1_hit8_rate_5') if len(summary_df) else np.nan,
        'baseline_top1_hit10_rate_5': summary_df.iloc[0].get('baseline_top1_hit10_rate_5') if len(summary_df) else np.nan,
        'baseline_top1_close5_open_t_hit8': summary_df.iloc[0].get('baseline_top1_close5_open_t_hit8') if len(summary_df) else np.nan,
        'baseline_top1_close5_open_t_hit10': summary_df.iloc[0].get('baseline_top1_close5_open_t_hit10') if len(summary_df) else np.nan,
        'baseline_top1_close5_open_t1_hit8': summary_df.iloc[0].get('baseline_top1_close5_open_t1_hit8') if len(summary_df) else np.nan,
        'baseline_top1_close5_open_t1_hit10': summary_df.iloc[0].get('baseline_top1_close5_open_t1_hit10') if len(summary_df) else np.nan,
        'reward_top1_avg_true_max_up_5': summary_df.iloc[0].get('reward_top1_avg_true_max_up_5') if len(summary_df) else np.nan,
        'reward_top1_hit8_rate_5': summary_df.iloc[0].get('reward_top1_hit8_rate_5') if len(summary_df) else np.nan,
        'reward_top1_hit10_rate_5': summary_df.iloc[0].get('reward_top1_hit10_rate_5') if len(summary_df) else np.nan,
        'reward_top1_close5_open_t_hit8': summary_df.iloc[0].get('reward_top1_close5_open_t_hit8') if len(summary_df) else np.nan,
        'reward_top1_close5_open_t_hit10': summary_df.iloc[0].get('reward_top1_close5_open_t_hit10') if len(summary_df) else np.nan,
        'reward_top1_close5_open_t1_hit8': summary_df.iloc[0].get('reward_top1_close5_open_t1_hit8') if len(summary_df) else np.nan,
        'reward_top1_close5_open_t1_hit10': summary_df.iloc[0].get('reward_top1_close5_open_t1_hit10') if len(summary_df) else np.nan,
        'same_pick_rate': summary_df.iloc[0].get('same_pick_rate') if len(summary_df) else np.nan,
        'reward_better_maxup5_rate': summary_df.iloc[0].get('reward_better_maxup5_rate') if len(summary_df) else np.nan,
        'delta_hit8_5': summary_df.iloc[0].get('delta_hit8_5') if len(summary_df) else np.nan,
        'delta_hit10_5': summary_df.iloc[0].get('delta_hit10_5') if len(summary_df) else np.nan,
        'delta_close5_open_t_hit8': summary_df.iloc[0].get('delta_close5_open_t_hit8') if len(summary_df) else np.nan,
        'delta_close5_open_t_hit10': summary_df.iloc[0].get('delta_close5_open_t_hit10') if len(summary_df) else np.nan,
        'delta_close5_open_t1_hit8': summary_df.iloc[0].get('delta_close5_open_t1_hit8') if len(summary_df) else np.nan,
        'delta_close5_open_t1_hit10': summary_df.iloc[0].get('delta_close5_open_t1_hit10') if len(summary_df) else np.nan,
    }
    pd.DataFrame([summary_payload]).to_csv(fold_dir/'v15_4_eval_summary.csv', index=False, encoding='utf-8-sig')

    for obj_name in ['valid_merged', 'test_merged', 'top10', 'daily_df', 'rank_df', 'summary_df', 'top_candidates_df', 'reward_profile_df', 'kline_df']:
        try:
            del locals()[obj_name]
        except Exception:
            pass
    cleanup_memory()
    return {'summary': pd.DataFrame([summary_payload])}


def run_one_fold(data: pd.DataFrame, feature_cols: List[str], cfg, fold_spec: Dict, fold_dir: Path, horizon: int):
    all_dates = sorted(pd.to_datetime(data['date']).drop_duplicates().tolist())
    train_df = data[data['date'].isin(fold_spec['train_dates'])].copy().sort_values(['symbol', 'date']).reset_index(drop=True)
    valid_df = _build_warmup_slice(data, fold_spec['valid_dates'], all_dates, cfg.warmup_days)
    test_df = _build_warmup_slice(data, fold_spec['test_dates'], all_dates, cfg.warmup_days)
    fold_dir.mkdir(parents=True, exist_ok=True)
    fit_res = None
    v15_res = None
    try:
        log_time(f"fold={fold_spec['fold']} | 开始训练与预测")
        fit_res = v14.fit_and_predict_one_fold_ashare_v14(
            train_df=train_df,
            valid_df=valid_df,
            test_df=test_df,
            feature_cols=feature_cols,
            cfg=cfg,
            valid_trade_dates=fold_spec['valid_dates'],
            test_trade_dates=fold_spec['test_dates'],
        )
        fit_res['valid_pred'].to_csv(fold_dir / 'valid_pred.csv', index=False, encoding='utf-8-sig')
        fit_res['test_pred'].to_csv(fold_dir / 'test_pred.csv', index=False, encoding='utf-8-sig')
        fit_res['epoch_records'].to_csv(fold_dir / 'epoch_records.csv', index=False, encoding='utf-8-sig')
        v15_res = run_v15_4_compare_outputs(fold_dir=fold_dir, valid_pred=fit_res['valid_pred'], test_pred=fit_res['test_pred'], raw_df=test_df, cfg=cfg, horizon=int(horizon))
        meta = {
            'fold': fold_spec['fold'],
            'fold_spec': {
                'train_start': fold_spec['train_start'],
                'train_end': fold_spec['train_end'],
                'valid_start': fold_spec['valid_start'],
                'valid_end': fold_spec['valid_end'],
                'test_start': fold_spec['test_start'],
                'test_end': fold_spec['test_end'],
            },
            'n_train_samples': fit_res['n_train_samples'],
            'n_valid_samples': fit_res['n_valid_samples'],
            'n_test_samples': fit_res['n_test_samples'],
            'study': 'V15.4 baseline + independent market reward comparison',
        }
        with open(fold_dir / 'fold_meta.json', 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        s = v15_res['summary'].iloc[0].to_dict() if len(v15_res['summary']) else {}
        row = {
            'fold': fold_spec['fold'],
            'horizon': int(horizon),
            'train_start': fold_spec['train_start'],
            'train_end': fold_spec['train_end'],
            'valid_start': fold_spec['valid_start'],
            'valid_end': fold_spec['valid_end'],
            'test_start': fold_spec['test_start'],
            'test_end': fold_spec['test_end'],
            'baseline_top1_avg_true_max_up_5': s.get('baseline_top1_avg_true_max_up_5'),
            'baseline_top1_hit8_rate_5': s.get('baseline_top1_hit8_rate_5'),
            'baseline_top1_hit10_rate_5': s.get('baseline_top1_hit10_rate_5'),
            'baseline_top1_close5_open_t_hit8': np.nan,
            'baseline_top1_close5_open_t_hit10': np.nan,
            'baseline_top1_close5_open_t1_hit8': np.nan,
            'baseline_top1_close5_open_t1_hit10': np.nan,
            'reward_top1_avg_true_max_up_5': s.get('reward_top1_avg_true_max_up_5'),
            'reward_top1_hit8_rate_5': s.get('reward_top1_hit8_rate_5'),
            'reward_top1_hit10_rate_5': s.get('reward_top1_hit10_rate_5'),
            'reward_top1_close5_open_t_hit8': np.nan,
            'reward_top1_close5_open_t_hit10': np.nan,
            'reward_top1_close5_open_t1_hit8': np.nan,
            'reward_top1_close5_open_t1_hit10': np.nan,
            'same_pick_rate': s.get('same_pick_rate'),
            'reward_better_maxup5_rate': s.get('reward_better_maxup5_rate'),
            'candidate_mode': getattr(cfg, 'candidate_mode', 'original'),
        }
        try:
            full = pd.read_csv(fold_dir / 'top1_baseline_vs_reward_daily.csv')
            row['baseline_top1_close5_open_t_hit8'] = _safe_mean(full, 'baseline_top1_hit_close5_open_t_8')
            row['baseline_top1_close5_open_t_hit10'] = _safe_mean(full, 'baseline_top1_hit_close5_open_t_10')
            row['baseline_top1_close5_open_t1_hit8'] = _safe_mean(full, 'baseline_top1_hit_close5_open_t1_8')
            row['baseline_top1_close5_open_t1_hit10'] = _safe_mean(full, 'baseline_top1_hit_close5_open_t1_10')
            row['reward_top1_close5_open_t_hit8'] = _safe_mean(full, 'reward_top1_hit_close5_open_t_8')
            row['reward_top1_close5_open_t_hit10'] = _safe_mean(full, 'reward_top1_hit_close5_open_t_10')
            row['reward_top1_close5_open_t1_hit8'] = _safe_mean(full, 'reward_top1_hit_close5_open_t1_8')
            row['reward_top1_close5_open_t1_hit10'] = _safe_mean(full, 'reward_top1_hit_close5_open_t1_10')
            del full
        except Exception:
            pass
        with open(fold_dir / 'done.json', 'w', encoding='utf-8') as f:
            json.dump({'status': 'done', 'fold': fold_spec['fold']}, f, ensure_ascii=False, indent=2)
        cleanup_memory()
        return row
    finally:
        try:
            del train_df, valid_df, test_df, fit_res, v15_res
        except Exception:
            pass
        cleanup_memory()
