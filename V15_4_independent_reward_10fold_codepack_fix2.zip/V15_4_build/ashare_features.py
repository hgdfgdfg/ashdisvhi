from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm


def _safe_div(a: pd.Series, b: pd.Series) -> pd.Series:
    return a / b.replace(0, np.nan)


def build_features_for_one_stock(
    g: pd.DataFrame,
    use_amount: bool = True,
    shift_features: bool = True,
) -> Tuple[pd.DataFrame, List[str]]:
    """
    为单只股票构建仅使用 t 日收盘后可知信息的日线特征。
    如果 shift_features=True，所有特征整体 shift(1)，用于保证 t 日信号不会使用 t 日盘中未来数据。
    """
    g = g.sort_values("date").copy()

    for w in [1, 2, 3, 5, 10, 20, 30, 60]:
        g[f"ret_{w}"] = g["close"].pct_change(w)

    g["open_gap_prev_close"] = _safe_div(g["open"], g["close"].shift(1)) - 1.0

    for w in [3, 5, 10, 20, 30, 60]:
        g[f"ma_{w}"] = g["close"].rolling(w).mean()
        g[f"ema_{w}"] = g["close"].ewm(span=w, adjust=False).mean()

    for w in [3, 5, 10, 20, 30, 60]:
        g[f"close_ma{w}_ratio"] = _safe_div(g["close"], g[f"ma_{w}"]) - 1.0
        g[f"close_ema{w}_ratio"] = _safe_div(g["close"], g[f"ema_{w}"]) - 1.0

    g["ma3_ma10_ratio"] = _safe_div(g["ma_3"], g["ma_10"]) - 1.0
    g["ma5_ma20_ratio"] = _safe_div(g["ma_5"], g["ma_20"]) - 1.0
    g["ma10_ma20_ratio"] = _safe_div(g["ma_10"], g["ma_20"]) - 1.0
    g["ma20_ma60_ratio"] = _safe_div(g["ma_20"], g["ma_60"]) - 1.0

    g["slope_5"] = _safe_div(g["ma_5"], g["ma_5"].shift(5)) - 1.0
    g["slope_10"] = _safe_div(g["ma_10"], g["ma_10"].shift(10)) - 1.0
    g["slope_20"] = _safe_div(g["ma_20"], g["ma_20"].shift(20)) - 1.0

    g["amplitude"] = _safe_div(g["high"] - g["low"], g["close"])
    g["body_pct"] = _safe_div(g["close"] - g["open"], g["open"])
    oc_max = g[["open", "close"]].max(axis=1)
    oc_min = g[["open", "close"]].min(axis=1)
    g["upper_wick"] = _safe_div(g["high"] - oc_max, g["close"])
    g["lower_wick"] = _safe_div(oc_min - g["low"], g["close"])
    full_range = (g["high"] - g["low"]).replace(0, np.nan)
    g["body_to_range"] = (g["close"] - g["open"]).abs() / full_range
    g["close_near_high"] = _safe_div(g["close"] - g["low"], g["high"] - g["low"])
    g["close_near_low"] = _safe_div(g["high"] - g["close"], g["high"] - g["low"])

    prev_close = g["close"].shift(1)
    tr = pd.concat([
        g["high"] - g["low"],
        (g["high"] - prev_close).abs(),
        (g["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    g["tr"] = tr
    for w in [3, 5, 10, 20]:
        g[f"volatility_{w}"] = g["ret_1"].rolling(w).std()
        g[f"atr_{w}"] = tr.rolling(w).mean()
        g[f"atr_ratio_{w}"] = _safe_div(g[f"atr_{w}"], g["close"])

    for w in [3, 5, 10, 20, 60]:
        g[f"vol_ma_{w}"] = g["volume"].rolling(w).mean()
        g[f"vol_ratio_{w}"] = _safe_div(g["volume"], g[f"vol_ma_{w}"])

    if use_amount and "amount" in g.columns:
        for w in [3, 5, 10, 20, 60]:
            g[f"amt_ma_{w}"] = g["amount"].rolling(w).mean()
            g[f"amt_ratio_{w}"] = _safe_div(g["amount"], g[f"amt_ma_{w}"])

    delta = g["close"].diff()
    up = delta.clip(lower=0.0)
    down = (-delta).clip(lower=0.0)
    for w in [6, 12, 24]:
        rs = _safe_div(up.rolling(w).mean(), down.rolling(w).mean())
        g[f"rsi_{w}"] = 100.0 - 100.0 / (1.0 + rs)

    for w in [10, 20, 60]:
        roll_high = g["high"].rolling(w).max()
        roll_low = g["low"].rolling(w).min()
        g[f"break_high_{w}"] = _safe_div(g["close"], roll_high) - 1.0
        g[f"break_low_{w}"] = _safe_div(g["close"], roll_low) - 1.0

    feature_cols = [
        c for c in g.columns
        if c not in {
            "symbol", "code", "market", "date", "open", "high", "low", "close", "volume", "amount",
            "tradable_buy", "n_listed_days", "tr", "market_ret_1", "market_ret_5", "market_ret_20",
        }
    ]

    if shift_features:
        g[feature_cols] = g[feature_cols].shift(1)

    return g, feature_cols


def build_features_for_all_stocks(
    df_daily: pd.DataFrame,
    use_amount: bool = True,
    shift_features: bool = True,
    show_progress: bool = True,
) -> Tuple[pd.DataFrame, List[str]]:
    df = df_daily.sort_values(["symbol", "date"]).copy()

    parts = []
    feature_cols: List[str] | None = None
    symbols = list(df["symbol"].drop_duplicates())
    iterator = tqdm(symbols, desc="Building stock features") if show_progress else symbols

    for sym in iterator:
        g = df[df["symbol"] == sym].copy()
        gf, cols = build_features_for_one_stock(g, use_amount=use_amount, shift_features=shift_features)
        parts.append(gf)
        if feature_cols is None:
            feature_cols = cols

    out = pd.concat(parts, axis=0, ignore_index=True)
    out = out.sort_values(["date", "symbol"]).reset_index(drop=True)

    out["market_ret_1"] = out.groupby("date")["ret_1"].transform("mean")
    out["market_ret_5"] = out.groupby("date")["ret_5"].transform("mean")
    out["market_ret_20"] = out.groupby("date")["ret_20"].transform("mean")

    base_for_cs = [
        "ret_5", "ret_20", "ret_60", "slope_10", "slope_20",
        "close_ma20_ratio", "close_ma60_ratio", "atr_ratio_20",
        "vol_ratio_20", "amplitude", "body_pct", "rsi_12",
        "break_high_20", "break_low_20",
    ]
    base_for_cs = [c for c in base_for_cs if c in out.columns]

    def _zscore(x: pd.Series) -> pd.Series:
        mu = x.mean()
        sd = x.std()
        if pd.isna(sd) or sd == 0:
            return pd.Series(np.zeros(len(x)), index=x.index)
        return (x - mu) / sd

    cs_cols = []
    for c in base_for_cs:
        rank_col = f"cs_rank_{c}"
        z_col = f"cs_z_{c}"
        out[rank_col] = out.groupby("date")[c].rank(pct=True)
        out[z_col] = out.groupby("date")[c].transform(_zscore)
        cs_cols.extend([rank_col, z_col])

    if "volatility_20" in out.columns:
        out["cs_rank_lowvol_20"] = 1.0 - out.groupby("date")["volatility_20"].rank(pct=True)
        cs_cols.append("cs_rank_lowvol_20")

    out["market_trend_20"] = out.groupby("symbol")["market_ret_20"].transform(lambda s: s.rolling(20).mean())
    out["market_trend_5"] = out.groupby("symbol")["market_ret_5"].transform(lambda s: s.rolling(5).mean())

    feature_cols = list(feature_cols or []) + cs_cols + ["market_ret_1", "market_ret_5", "market_ret_20", "market_trend_5", "market_trend_20"]
    feature_cols = [c for c in dict.fromkeys(feature_cols) if c in out.columns]
    return out, feature_cols
