V16A_true_from_v154_top10_recent5fold 完整工程包
=========================================

定位
----
这是“对 V15.4 reward 每天 top10 compare 候选再筛一层”的正确 V16A。

不是全候选池重排，不依赖 V15.8 主链。
它直接对齐因子工厂验证过的样本口径：
- baseline top10 候选
- 先算 V15.4 reward
- 再在这 10 只里做 V16A 结构筛选

核心逻辑
--------
V16A = V15.4 reward 主干
     + runup_10 × price_pos_120d 轻量加分
     + independent quality 轻量加分
     - top1 过热降权

入口
----
- run_v16a_true_from_v154_top10_recent5fold.py
- run_v16a_true_from_v154_top10_recent5fold.bat

结果目录
--------
runs/V16A_true_from_v154_top10_recent5fold_experiments/

每个 fold 输出
------------
- v16a_eval_summary.csv
- top10_rank_stats_v16a.csv
- top1_baseline_vs_v15_4_v16a_daily.csv
- candidate_kline_windows_v16a.csv
- test_pred_v16a_top10_seed.csv
- top_candidates_v16a_compare.csv
- v16a_scope_diag.json
- v16a_feature_availability.json
- v16a_error.json (仅报错时)

总表输出
--------
- all_fold_results.csv
- v16a_cycle_horizon_summary.csv
- overview.json
- top1_baseline_vs_v15_4_v16a_daily_all.csv
- top_candidates_v16a_compare_all.csv
- top10_rank_stats_v16a_all.csv
- candidate_kline_windows_v16a_all.csv
