@echo off
python run_v16a_true_from_v154_top10_recent5fold.py
pause
